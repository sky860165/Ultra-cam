# UltraCam v3.1

## Build (GitHub Actions)
1. Folder GitHub repo me push kro
2. Actions → "Build UltraCam APK" → Artifacts se APK download
3. Agar build fail ho to error log bhej do, fix kar denge

## Modes (12)
AUTO · ULTRA (6-frame merge) · NIGHT (long shutter stack) · HDR (exposure fusion) · PORTRAIT (bokeh)
PRO (manual) · ASTRO (star stack) · TRAILS (star trails) · PANO · SCAN (document) · LAPSE (timelapse) · VIDEO

## v3 me naya
- Local (tile) alignment: haath hilne / halki motion par ghost kam
- Live histogram, focus peaking, zebra, horizon level (📊 button cycle karta hai)
- Auto scene: low light ya high contrast par NIGHT/HDR suggest (aur auto-switch)
- Lens picker 🔭 (ultra-wide/macro tabhi jab phone apps ko expose kare), ℹ Camera Info
- Portrait bokeh (ML Kit person segmentation), Watermark, Presets (3 slots)
- In-app Gallery: thumbnail dabao; long-press = Before/After compare (Settings me "Original save" ON)
- Video: 60fps, HDR10 toggles (device/CameraX support par depend)

## Jo nahi hai (aur kyu)
- GPU/NDK engine, AI super-res model, RAW/DNG, gyro-based EIS, video par color look:
  ye bina phone par test kiye safe nahi — alag step me
- Document scan me perspective correction nahi (sirf flatten + contrast)
- Geotag nahi (location permission chahiye)

## v3.1 (noise + detail + speed)
- Smart AUTO: ab AUTO me 3-6 frame ka quick burst (ISO ke hisaab se) merge hota hai -> noise bahut kam, real detail zyada. Settings > Smart me ON/OFF
- AI focus point: shutter se pehle preview me sabse detailed + well-exposed jagah pe AF/AE lock (tap kiya ho to wahi point)
- Noise-adaptive denoise: image ka noise level khud measure hota hai, shadows me zyada denoise, phir noise-floor ke upar ka real detail wapas add hota hai
- Shadow lift / local contrast ab noisy areas me kam boost karta hai, sharpening noise ko sharpen nahi karti
- Blurry (hath hilne wale) frames ko merge me kam weight
- Speed: frames parallel decode, bade strips (kam repeated JPEG decode), processing threads low priority (camera/UI smooth), AUTO/ULTRA me fast capture mode
- Note: phone ka aperture fixed hota hai (software se change nahi hota); "aperture" ki jagah exposure/ISO/focus auto-optimize hota hai

## v3.2 (native C++ engine)
- Naya `app/src/main/cpp/`: merge, local alignment, denoise, tone-map, sharpen aur look ab C++ me (multi-thread + SIMD-friendly). Alignment search bhi native.
- Merge weights me ab chroma difference bhi: haath/gaadi jaise colored moving objects ka ghost kam (test: ghost region 24.5 -> 38.1 dB)
- Local alignment penalty tune; scale>1 par bicubic resample (bilinear se sharp); sharpening par soft-limiter (halo kam); output par dither (banding kam)
- Naya "Enhance (Google Photos style)" slider (Settings > Image engine, default 50): histogram se levels stretch, contrast, vibrance, local detail aur shadows auto-adjust
- Agar .so load na ho ya native me error aaye to automatic purana Kotlin engine chalta hai
- `native_test/host_test.cpp`: PC par engine test/benchmark (optional)

## v3.3 (AI Director)
Settings me "AI Director" toggle (default ON). Preview ko dekh ke har shot ke liye ye khud decide karta hai:
- Light detection: ISO x shutter se BRIGHT / NORMAL / DIM / DARK; us hisaab se frames (3-6), denoise, sharpness, Enhance
- Shutter: hilta scene = FAST (short exposure, high fps range), still + dim/dark = LONG (lamba exposure), warna AUTO
- Exposure (EV): dark face/subject lift, blown highlights protect; high contrast par HDR
- Aperture: phone ka physical aperture/focal change nahi hota. Uska AI equivalent: person milne par hi background blur (software aperture); dark scene me off
- Focus: pehle wala AI focus point (sabse detailed + well-exposed jagah) lock
- Image enhancement: Enhance slider + scene ke hisaab se auto adjust
- Status bar me "AI • dim • steady → long exposure • 5 frames" jaisa reason dikhta hai
- Test: native_test/AiDirectorTest.kt (decision logic)

## v3.4 (sab back lenses)
- 🔭 LENS dabao: phone ke saare back sensors ki list (main / ultra-wide / macro / depth), focal mm, MP aur status ke saath. Jo ON ho sakta hai usse ek tap me switch.
- "📸 Shoot ALL lenses": har ON lens se ek-ek photo gallery me save (naam me lens role).
- Android sirf wahi lens apps ko deta hai jo phone (MIUI) expose kare. Chhupe hue sensors list me "phone ne chhupa rakha hai" dikhte hain; depth sensor photo nahi leta.

## v3.5 (RAW engine + halo fix)  — RAW images ab JPEG se behtar process hoti hain
**Naya RAW path** (AUTO / ULTRA / NIGHT / HDR me, jab lens RAW expose kare):
- Camera2 se RAW_SENSOR burst (5-8 frames). Merge Bayer domain me hota hai (JPEG ka detail-loss bypass).
- Pyramid tile alignment (4 levels, 16px tiles, neighbour-candidate search) + noise-model based ghost-safe merge (Wiener-style weights)
- Gyro blur check: shutter ke dauran hilne wale frames ka weight kam; handheld me chhota shutter + zyada frames, tripod me lamba shutter
- Develop: lens-shading map, black/white level, DNG-style colour calibration (forward matrix + illuminant interpolation), Hamilton-Adams demosaic
- Local tone map (edge-aware, joint-bilateral upsample => halo nahi), filmic curve, auto levels (dehaze), conservative colour-cast correction
- "Color pop": vibrance + sky-blue / foliage-green boost, skin natural; sqrt-domain noise reduction (luma + chroma guided filters)
- Richardson-Lucy deconvolution + cored unsharp + clarity (lens softness wapas)
- Settings > "RAW engine": ON/OFF, "DNG bhi save karo", "Color pop" slider
- Zoom > 1.05x, flash ON, ya MAX 64MP mode me purana JPEG path chalta hai. Agar lens RAW nahi deta to automatic JPEG path.

**JPEG path me HDR halo fix**: tone-map ka base map ab edge-aware (guided filter) hai — darwaze/khidki ke kinaro par bright halo gaya.

**Abhi nahi (alag step)**: on-device AI (TFLite) model — model file chahiye; true multi-frame super-res (sub-pixel) RAW path me; front camera RAW; Looks presets RAW path par.
PC test: `native_test/raw_gen.py` (fake RAW burst) + `native_test/raw_host_test.cpp`.

## v3.5.1
- Reference frame ab burst ke pehle 3 frames me se sabse sharp + sabse steady (gyro) chuna jata hai (pehle hamesha frame #1 tha)
- Hot pixel cleanup (sensor ke chamakte dots)
- Purple fringing / CA defringe (high-contrast edges par)
- Auto background blur ab default OFF (Settings > Smart me toggle); PORTRAIT mode me blur hamesha chalta hai
- Front camera bhi ab RAW path use karta hai (agar front RAW de; tumhare phone par YES)

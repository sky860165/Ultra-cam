# UltraCam v3

## Build (GitHub Actions)
1. Folder GitHub repo me push kro
2. Actions → "Build UltraCam APK" → Artifacts se APK download
3. Agar build fail ho to error log bhej do, fix kar denge

## Modes (12)
AUTO · ULTRA (6-frame merge) · NIGHT (long shutter stack) · HDR (exposure fusion) · PORTRAIT (bokeh)
PRO (manual) · ASTRO (star stack) · TRAILS (star trails) · PANO · SCAN (document) · LAPSE (timelapse) · VIDEO

## v3 me naya
- Local (tile) alignment: haath hilne / halki motion par ghost kam
- Live histogram, focus peaking, zebra, horizon level (📊 button cycle karta hai)
- Auto scene: low light ya high contrast par NIGHT/HDR suggest (aur auto-switch)
- Lens picker 🔭 (ultra-wide/macro tabhi jab phone apps ko expose kare), ℹ Camera Info
- Portrait bokeh (ML Kit person segmentation), Watermark, Presets (3 slots)
- In-app Gallery: thumbnail dabao; long-press = Before/After compare (Settings me "Original save" ON)
- Video: 60fps, HDR10 toggles (device/CameraX support par depend)

## Jo nahi hai (aur kyu)
- GPU/NDK engine, AI super-res model, RAW/DNG, gyro-based EIS, video par color look:
  ye bina phone par test kiye safe nahi — alag step me
- Document scan me perspective correction nahi (sirf flatten + contrast)
- Geotag nahi (location permission chahiye)

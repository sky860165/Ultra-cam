# UltraCam v3.8

## Build (GitHub Actions)
1. Folder GitHub repo me push kro
2. Actions → "Build UltraCam APK" → Artifacts se APK download
3. Agar build fail ho to error log bhej do, fix kar denge

## Modes (13)
AUTO · ULTRA (6-frame merge) · ULTRA-WIDE (main + ultra-wide fusion) · NIGHT (long shutter stack) · HDR (exposure fusion) · PORTRAIT (bokeh)
PRO (manual) · ASTRO (star stack) · TRAILS (star trails) · PANO · SCAN (document) · LAPSE (timelapse) · VIDEO

## v3 me naya
- Local (tile) alignment: haath hilne / halki motion par ghost kam
- Live histogram, focus peaking, zebra, horizon level (📊 button cycle karta hai)
- Auto scene: low light ya high contrast par NIGHT/HDR suggest (aur auto-switch)
- Lens picker 🔭 (ultra-wide/macro tabhi jab phone apps ko expose kare), ℹ Camera Info
- Portrait bokeh (ML Kit person segmentation), Watermark, Presets (3 slots)
- In-app Gallery: thumbnail dabao; long-press = Before/After compare (Settings me "Original save" ON)
- Video: 60fps, HDR10 toggles (device/CameraX support par depend)

## Jo nahi hai (aur kyu)
- GPU/NDK engine, AI super-res model, RAW/DNG, gyro-based EIS, video par color look:
  ye bina phone par test kiye safe nahi — alag step me
- Document scan me perspective correction nahi (sirf flatten + contrast)
- Geotag nahi (location permission chahiye)

## v3.1 (noise + detail + speed)
- Smart AUTO: ab AUTO me 3-6 frame ka quick burst (ISO ke hisaab se) merge hota hai -> noise bahut kam, real detail zyada. Settings > Smart me ON/OFF
- AI focus point: shutter se pehle preview me sabse detailed + well-exposed jagah pe AF/AE lock (tap kiya ho to wahi point)
- Noise-adaptive denoise: image ka noise level khud measure hota hai, shadows me zyada denoise, phir noise-floor ke upar ka real detail wapas add hota hai
- Shadow lift / local contrast ab noisy areas me kam boost karta hai, sharpening noise ko sharpen nahi karti
- Blurry (hath hilne wale) frames ko merge me kam weight
- Speed: frames parallel decode, bade strips (kam repeated JPEG decode), processing threads low priority (camera/UI smooth), AUTO/ULTRA me fast capture mode
- Note: phone ka aperture fixed hota hai (software se change nahi hota); "aperture" ki jagah exposure/ISO/focus auto-optimize hota hai

## v3.2 (native C++ engine)
- Naya `app/src/main/cpp/`: merge, local alignment, denoise, tone-map, sharpen aur look ab C++ me (multi-thread + SIMD-friendly). Alignment search bhi native.
- Merge weights me ab chroma difference bhi: haath/gaadi jaise colored moving objects ka ghost kam (test: ghost region 24.5 -> 38.1 dB)
- Local alignment penalty tune; scale>1 par bicubic resample (bilinear se sharp); sharpening par soft-limiter (halo kam); output par dither (banding kam)
- Naya "Enhance (Google Photos style)" slider (Settings > Image engine, default 50): histogram se levels stretch, contrast, vibrance, local detail aur shadows auto-adjust
- Agar .so load na ho ya native me error aaye to automatic purana Kotlin engine chalta hai
- `native_test/host_test.cpp`: PC par engine test/benchmark (optional)

## v3.3 (AI Director)
Settings me "AI Director" toggle (default ON). Preview ko dekh ke har shot ke liye ye khud decide karta hai:
- Light detection: ISO x shutter se BRIGHT / NORMAL / DIM / DARK; us hisaab se frames (3-6), denoise, sharpness, Enhance
- Shutter: hilta scene = FAST (short exposure, high fps range), still + dim/dark = LONG (lamba exposure), warna AUTO
- Exposure (EV): dark face/subject lift, blown highlights protect; high contrast par HDR
- Aperture: phone ka physical aperture/focal change nahi hota. Uska AI equivalent: person milne par hi background blur (software aperture); dark scene me off
- Focus: pehle wala AI focus point (sabse detailed + well-exposed jagah) lock
- Image enhancement: Enhance slider + scene ke hisaab se auto adjust
- Status bar me "AI • dim • steady → long exposure • 5 frames" jaisa reason dikhta hai
- Test: native_test/AiDirectorTest.kt (decision logic)

## v3.4 (sab back lenses)
- 🔭 LENS dabao: phone ke saare back sensors ki list (main / ultra-wide / macro / depth), focal mm, MP aur status ke saath. Jo ON ho sakta hai usse ek tap me switch.
- "📸 Shoot ALL lenses": har ON lens se ek-ek photo gallery me save (naam me lens role).
- Android sirf wahi lens apps ko deta hai jo phone (MIUI) expose kare. Chhupe hue sensors list me "phone ne chhupa rakha hai" dikhte hain; depth sensor photo nahi leta.

## v3.5 (RAW engine + halo fix)  — RAW images ab JPEG se behtar process hoti hain
**Naya RAW path** (AUTO / ULTRA / NIGHT / HDR me, jab lens RAW expose kare):
- Camera2 se RAW_SENSOR burst (5-8 frames). Merge Bayer domain me hota hai (JPEG ka detail-loss bypass).
- Pyramid tile alignment (4 levels, 16px tiles, neighbour-candidate search) + noise-model based ghost-safe merge (Wiener-style weights)
- Gyro blur check: shutter ke dauran hilne wale frames ka weight kam; handheld me chhota shutter + zyada frames, tripod me lamba shutter
- Develop: lens-shading map, black/white level, DNG-style colour calibration (forward matrix + illuminant interpolation), Hamilton-Adams demosaic
- Local tone map (edge-aware, joint-bilateral upsample => halo nahi), filmic curve, auto levels (dehaze), conservative colour-cast correction
- "Color pop": vibrance + sky-blue / foliage-green boost, skin natural; sqrt-domain noise reduction (luma + chroma guided filters)
- Richardson-Lucy deconvolution + cored unsharp + clarity (lens softness wapas)
- Settings > "RAW engine": ON/OFF, "DNG bhi save karo", "Color pop" slider
- Zoom > 1.05x, flash ON, ya MAX 64MP mode me purana JPEG path chalta hai. Agar lens RAW nahi deta to automatic JPEG path.

**JPEG path me HDR halo fix**: tone-map ka base map ab edge-aware (guided filter) hai — darwaze/khidki ke kinaro par bright halo gaya.

**Abhi nahi (alag step)**: on-device AI (TFLite) model — model file chahiye; true multi-frame super-res (sub-pixel) RAW path me; front camera RAW; Looks presets RAW path par.
PC test: `native_test/raw_gen.py` (fake RAW burst) + `native_test/raw_host_test.cpp`.

## v3.5.1
- Reference frame ab burst ke pehle 3 frames me se sabse sharp + sabse steady (gyro) chuna jata hai (pehle hamesha frame #1 tha)
- Hot pixel cleanup (sensor ke chamakte dots)
- Purple fringing / CA defringe (high-contrast edges par)
- Auto background blur ab default OFF (Settings > Smart me toggle); PORTRAIT mode me blur hamesha chalta hai
- Front camera bhi ab RAW path use karta hai (agar front RAW de; tumhare phone par YES)


## v3.6 (Beauty front+back + sub-pixel super-res)

### Beauty (front aur back camera ki settings alag alag)
- Top bar me **✨ BEAUTY** button: current camera (FRONT/BACK) ki beauty ON/OFF + poori settings. Settings (⚙) me bhi dono ke buttons hain.
- Har effect ka apna **ON/OFF + Amount slider**: Skin smoothing · Even skin tone (redness/patches) · Blemish/spot remover · Skin brighten+glow · Eyes bright + dark circles · Teeth whitening · Lip colour · Face slim · Eye enlarge
- **AI Auto-Beauty** (alag ON/OFF): har face ko measure karta hai (skin roughness, blotchiness, brightness) aur effect khud kam/zyada karta hai, taaki plastic look na aaye
- Default: Front master ON, Back master OFF. Slim / Eye enlarge / Lip default OFF
- Skin smoothing edge-preserving (guided filter) hai: aankh, bhaunh, hont, naak ke chhed, baal / dadhi ko nahi chhuti. Skin colour khud us face se sample hota hai (alag skin tones ke liye)
- Group photo me har face (max 6) par lagti hai. Face na mile to kuch nahi hota
- Beauty photo save hote waqt lagti hai (live preview me nahi dikhti). RAW aur JPEG dono path me chalti hai. Panorama / Scan / Astro me nahi
- Naya dependency: `com.google.mlkit:face-detection` (build.gradle). Resolve na ho to us line + Beauty.kt delete karke uske calls hata do

### Sub-pixel super-resolution (RAW path)
- Settings > RAW engine > "Sub-pixel super-res" (default ON)
- Har frame ka sub-pixel offset nikalta hai (tile Lucas-Kanade) aur sabhi frames ke green samples ek dense grid par jodta hai => demosaic se interpolate hone wale green ki jagah asli multi-frame green. Haath ki halki hilne se jo sub-pixel shift aata hai wahi extra detail deta hai
- Ghost safety: sirf wahin lagta hai jahan kai frames agree karein; demosaic se zyada door nahi jaata
- PC test (synthetic burst, 8 frames): 3.5px diagonal pattern ka correlation 0.46 -> 0.80, 4px 0.67 -> 0.89. Phone par asli gain scene aur haath ki hilne par depend karta hai
- Cost: ~8 byte/pixel extra RAM (16MP par ~130MB) aur merge me kuch second zyada. Dikkat ho to OFF kar do
- Sirf RAW path me (JPEG fallback me nahi)

### Abhi bhi nahi
- Beauty ka live preview, skin-tone lightening presets, makeup (eyeshadow / blush) - alag step
- RAW path me super-res sirf green plane par hai (R/B ab bhi demosaic se)

## v3.7 (ultra-wide fusion, Ultra Natural, Focus blur, Auto Details)
- **ULTRA-WIDE mode**: pehle main lens se burst, phir ultra-wide lens se burst. Dono alag merge hote hain, phir main ki image ultra-wide ke upar sahi jagah (scale + position khud dhundh ke) native detail me chipak jaati hai; kinare ultra-wide se aate hain. Seam feathered, ultra-wide ka colour main se match hota hai.
  - Ultra-wide lens agar phone CameraX ko deta hai to wahi se; warna app hidden camera id ko Camera2 se seedha kholne ka try karti hai (UwCapture.kt). Phone ne mana kiya to normal main-lens merge save hota hai aur toast aata hai.
  - Dono image match na hon (score kam) to main + ultra-wide alag alag save hoti hain.
- **Ultra Natural look** (Looks me "Natural" ke baad): colour pop / vibrance / Enhance / dehaze sab band, saturation 1.0, halka contrast, shadow lift kam, AWB halka -> asli rang. Purana "Natural" waisa hi hai.
- **🌫 BLUR (Focus blur)**: top bar me. ON/OFF, Blur % slider, mode: Person (AI) / Focus point (tap). Sab photo modes + RAW me; photo save hote waqt lagta hai.
- **🔍 DETAILS (Auto Details)**: top bar me. ISO x shutter se light naapta hai: tez roshni = zyada detail + sharpness, halka denoise; low light = detail kam, denoise zyada (noise sharp na ho). "Level" slider se bias (0 smooth, 50 balanced, 100 max detail; low light me asar khud kam).
- **Beauty**: front aur back dono camera me hai (alag settings); ab back camera me bhi default ON (sirf tab lagti hai jab face mile).

## v3.8 (ULTRA NIGHT, full screen, front flash fix)
- **ULTRA NIGHT mode**: bahut andhere ke liye — zyada frames (RAW 12 / JPEG 10), lambi exposure, strong brightening, colour-cast (purple/yellow) fix, zyada noise suppression. Bahut dark scene par app khud suggest / auto-switch karta hai.
- **NIGHT mode fix**: behtar gain + white balance (purple cast kam), merged frames me detail/clarity zyada rakhi jaati hai.
- **Front flash fix**: ab soft neutral screen light (Settings > Front flash %), exposure -1 EV, aur sirf tab jab flash AUTO/ON ho. Beauty ka tone/glow bhi face ko peela ya shiny nahi karta (shine control add).
- **⛶ FULL (full screen)**: top bar me FULL dabao — preview poori screen par, photo screen ke shape me crop hoke save hoti hai (front + back). Default OFF.

## v3.9 (RAW sab modes me, flash sab modes me, Beauty strong)
**RAW pipeline ab in modes me**: AUTO · ULTRA · ULTRA-WIDE · NIGHT · ULTRA NIGHT · HDR · PORTRAIT · PRO · ASTRO · SCAN
- Pehle flash ON, zoom > 1.05x ya in modes me JPEG chalta tha — ab nahi. Sirf ye JPEG par hain: MAX-res (64MP) capture, TRAILS, PANO, LAPSE, VIDEO (inhe lagataar camera session chahiye, har frame par RAW session kholna possible nahi).
- **Flash (⚡ OFF/AUTO/ON) sab modes me**: back camera = LED torch poore burst me ON (frames same light me merge hote hain), RAW capture me AWB bhi torch ke under settle hone ka wait + flash ke liye thoda cooler/neutral develop (peela cast kam). Front = soft screen flash. AUTO = sirf andhere me.
- **Zoom + RAW**: sirf center window develop hoti hai (native crop), phir screen size tak upscale.
- **PRO + RAW**: tumhari manual ISO / shutter / focus / AWB RAW burst me lagti hai. Lambi shutter (>=0.5s) par 1 frame, 0.125s+ par 2, warna 4-6 frames merge.
- **ASTRO + RAW**: 8 frames x 4s, ISO 1600 (sub-pixel SR band: tare move karte hain).
- **PORTRAIT + RAW**: 5 RAW frames merge -> person-segment bokeh.
- **SCAN + RAW**: RAW develop (neutral) -> document filter.
- **ULTRA-WIDE + RAW**: main + ultra-wide dono RAW burst (ultra-wide Camera2 se seedha). Memory bachane ke liye is mode me SR band.
- Beauty: **Beauty POWER** slider (Beauty dialog ke upar, default 135%). Smoothing/tone/blemish/glow/eyes/teeth ke default amount zyada, smoothing ki max strength badhi + strong setting par dusra wide edge-preserving pass. Purani saved values par bhi POWER multiplier lagta hai.

## v3.9 — post processing (PC par measure kiya hua)
- **Naya demosaic** (`app/src/main/cpp/demosaic.hpp`): soft-weighted directional green + guided-filter residual interpolation (R/B) + ek green refinement pass. 4 real photos (noise-free re-mosaic, sRGB CPSNR): purana Hamilton-Adams **32.1 dB -> 35.0 dB**. Noisy data par bhi behtar: noise S=0.0005 par 32.3 -> 34.5, 0.002 par 29.5 -> 31.7, 0.008 par 25.3 -> 27.0. Sub-pixel super-res green isi ke upar chalta hai.
- Pura pipeline production flags (-O3 -ffast-math -fno-rtti) me compile + chalaya: warning nahi, strip seams nahi, output purane se match + saaf. Cost: develop ~2x slower (16MP par phone me kuch second zyada).
- **Zoom upscale ab Lanczos-3** (`Upscale.kt`): bilinear se 2x upscale par +1.7 dB (PIL Lanczos se match 66 dB).
- PC test: `native_test/demosaic_test.cpp` + `demosaic_bench.py` (+ `demosaic_ref.py`): `g++ -O2 -o demosaic_test demosaic_test.cpp && python3 demosaic_bench.py` (scikit-image chahiye).

## v3.9b — beauty blur + grain fix (user ki selfies par test kiya)
- **Beauty ab face ko mush nahi karti**: smoothing me asli skin texture ka 45% hamesha bachta hai, dusra wide pass hata diya, mask ka edge soft (cheek par border nahi), aur **beard / stubble / hair** (cheek se bahut dark pixels) smoothing se protect hain. Defaults wapas balanced; Beauty POWER default 100%.
- **Naya NLM denoise** (`nlm.hpp`, `Denoise.kt`): final photo par luma grain hatata hai, edges/beard/aankhein bachti hain. Noise level photo se khud naapta hai (3 strips ka median, seam nahi). Beauty se PEHLE chalta hai taaki beauty ko grain chhupane ke liye face blur na karna pade. Noise Clean settings ka "luma" slider control karta hai (0 = band). Clean photos (RAW develop ke baad) ko skip karta hai.
- PC test: synthetic noisy photo par 40.7 dB -> 42.3 dB (cv2 NLM 42.3 ke barabar); `native_test/nlm_test.cpp`. 3.7MP selfie ~2 s (PC), phone par kuch second zyada, background me.

## v3.9c — frames kam, RAW har jagah
- **Frames**: sab modes max **4 frames** (16 MP each): AUTO / ULTRA / NIGHT / HDR / PORTRAIT / PRO = 4, **ULTRA NIGHT = 8**, ASTRO = 6. JPEG fallback me bhi (ULTRA 4, NIGHT 4 (tripod 3), ULTRA NIGHT 8, AUTO max 4). Time lagbhag aadha.
- **RAW PANO / LAPSE / TRAILS**: Camera2 RAW session ek baar khulta hai (`RawCapture.capture(shots=…)`), har shot ek RAW frame, background me (max 2 ek saath, RAM bounded) alag develop hokar JPEG banta hai. PANO: 12 RAW frames, exposure + WB pehle frame se lock; LAPSE: har frame RAW develop -> gallery; TRAILS: 20 x 3 s RAW bina gap, phir lighten-stack. Chalte waqt live preview band rehta hai (status text dikhta hai). Settings me "RAW PANO / LAPSE / TRAILS" toggle se band kar sakte ho. RAW fail ho to purana JPEG path chalta hai.
- **Front camera RAW**: ab support check dheela (kuch phones capability flag nahi dete par RAW sizes dete hain). Agar phone ka front sensor Camera2 RAW deta hi nahi, to app force nahi kar sakti — tab JPEG path + naya NLM denoise.
- VIDEO RAW nahi (video RAW nahi hota).

- **Camera Info me RAW report**: har camera id (BACK / FRONT) par "RAW sizes" aur "UltraCam RAW engine: USABLE / not available" dikhta hai. Front RAW hai ya nahi, isse seedha pata chalega.

## v3.9 (highlight pink/magenta fix)
- Front/JPEG path me safed deewar/pillar ke clipped highlights pink/magenta aa rahe the (G channel pehle clip hota hai). Ab finish stage me near-clip pixels par G wapas pull hota hai, to white neutral rehta hai. Gehre pink/magenta objects (phool, kapde) par asar nahi.

## v3.10 (speed)
Settings > "Speed" (default ⚡ Fast / Balanced / Quality):
- Fast: capture me max 3 frame, focus wait 0.6s (pehle 1.5s), EV settle 0.2s, extra NLM denoise pass skip, RAW path me sub-pixel super-res band + max 3 frame
- Balanced: 4 frame, focus wait 1s, NLM ON, SR (Settings wale toggle ke hisaab se)
- Quality: pehle jaisa (v3.9)
- Logcat me "TIMING engine=...ms" aata hai (merge kitna time laga) — slow rahe to ye line bhej dena

## v3.11 (Beauty speed)
- Beauty skin-effects ab Speed ke hisaab se chhote working size par chalte hain (Fast 768px / Balanced 1024 / Quality 1536) aur full-res detail wapas add hota hai -> Fast me ~4-5x kam pixels
- Face detector Fast me FAST mode + 640px
- Blur ke liye har baar 2 badi memory arrays banana band (ek shared scratch) -> kam GC / kam RAM
- Logcat: "beauty applied on N face(s) in XXXms"

## v3.12 (timing + Fast = 8MP)
- Har photo ke baad notification + toast me: "total 3.2s: merge 1.4s • 4fr 1932x2576 native • clean 0.6s • beauty 0.5s • save 0.4s" (Settings > Speed me ON/OFF)
  "KOTLIN-fallback" dikhe to native engine load nahi hua (bahut slow path) — ye line bhej do
- (v3.13 me Fast ka 8MP wala cut hata diya)

## v3.13 (16MP default)
- Photo resolution ab default 16MP (4608x3456). Settings me 12MP / 16MP / MAX 64MP badal sakte ho
- Speed (Fast/Balanced/Quality) ab resolution nahi badalta, sirf frames / focus wait / extra denoise / beauty size control karta hai
- Front camera 13MP hai, wahan jo sabse bada size milta hai wahi use hoga

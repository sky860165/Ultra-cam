# UltraCam v3.1

## Build (GitHub Actions)
1. Folder GitHub repo me push kro
2. Actions → "Build UltraCam APK" → Artifacts se APK download
3. Agar build fail ho to error log bhej do, fix kar denge

## Modes (12)
AUTO · ULTRA (6-frame merge) · NIGHT (long shutter stack) · HDR (exposure fusion) · PORTRAIT (bokeh)
PRO (manual) · ASTRO (star stack) · TRAILS (star trails) · PANO · SCAN (document) · LAPSE (timelapse) · VIDEO

## v3 me naya
- Local (tile) alignment: haath hilne / halki motion par ghost kam
- Live histogram, focus peaking, zebra, horizon level (📊 button cycle karta hai)
- Auto scene: low light ya high contrast par NIGHT/HDR suggest (aur auto-switch)
- Lens picker 🔭 (ultra-wide/macro tabhi jab phone apps ko expose kare), ℹ Camera Info
- Portrait bokeh (ML Kit person segmentation), Watermark, Presets (3 slots)
- In-app Gallery: thumbnail dabao; long-press = Before/After compare (Settings me "Original save" ON)
- Video: 60fps, HDR10 toggles (device/CameraX support par depend)

## Jo nahi hai (aur kyu)
- GPU/NDK engine, AI super-res model, RAW/DNG, gyro-based EIS, video par color look:
  ye bina phone par test kiye safe nahi — alag step me
- Document scan me perspective correction nahi (sirf flatten + contrast)
- Geotag nahi (location permission chahiye)

## v3.1 (noise + detail + speed)
- Smart AUTO: ab AUTO me 3-6 frame ka quick burst (ISO ke hisaab se) merge hota hai -> noise bahut kam, real detail zyada. Settings > Smart me ON/OFF
- AI focus point: shutter se pehle preview me sabse detailed + well-exposed jagah pe AF/AE lock (tap kiya ho to wahi point)
- Noise-adaptive denoise: image ka noise level khud measure hota hai, shadows me zyada denoise, phir noise-floor ke upar ka real detail wapas add hota hai
- Shadow lift / local contrast ab noisy areas me kam boost karta hai, sharpening noise ko sharpen nahi karti
- Blurry (hath hilne wale) frames ko merge me kam weight
- Speed: frames parallel decode, bade strips (kam repeated JPEG decode), processing threads low priority (camera/UI smooth), AUTO/ULTRA me fast capture mode
- Note: phone ka aperture fixed hota hai (software se change nahi hota); "aperture" ki jagah exposure/ISO/focus auto-optimize hota hai

#include "../app/src/main/cpp/nlm.hpp"
#include <cstdio>
#include <chrono>
int main(int argc,char**argv){
  FILE*f=fopen(argv[1],"rb"); int w,h; if(fread(&w,4,1,f)!=1)return 1; if(fread(&h,4,1,f)!=1)return 1;
  std::vector<uint32_t> px((size_t)w*h); if(fread(px.data(),4,px.size(),f)!=px.size())return 1; fclose(f);
  float strength=atof(argv[3]), keep=atof(argv[4]); int R=atoi(argv[5]);
  float sg=0;
  auto t0=std::chrono::steady_clock::now();
  uc::nlm::denoiseArgb(px.data(),w,h,strength,R,keep);
  auto t1=std::chrono::steady_clock::now();
  fprintf(stderr,"%dx%d sigma=%.2f %d ms\n",w,h,sg,(int)std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count());
  f=fopen(argv[2],"wb"); fwrite(&w,4,1,f);fwrite(&h,4,1,f);fwrite(px.data(),4,px.size(),f);fclose(f);
}

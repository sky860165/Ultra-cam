// Host (PC) test + benchmark for the UltraCam native engine.
//   g++ -std=c++17 -O3 -ffast-math -pthread -I../app/src/main/cpp host_test.cpp -o host_test && ./host_test
//   (add -fsanitize=address,undefined -O1 -g for the memory-safety run)
#include "../app/src/main/cpp/engine.cpp"

#include <chrono>
#include <cstdio>
#include <random>
#include <string>

using namespace uc;
using Clock = std::chrono::steady_clock;
static double ms_since(Clock::time_point t) { return std::chrono::duration<double, std::milli>(Clock::now() - t).count(); }

// ------------------------------------------------------------------ synthetic scene
struct Img { int w, h; std::vector<uint32_t> px; };

static float scene(float x, float y, int w, int h, float t) {
    // returns luma-ish 0..255 plus we derive colour from it in the caller
    float u = x / w, v = y / h;
    float g = 60.f + 120.f * u * (1.f - 0.4f * v);                 // smooth gradient
    // rectangles (hard edges)
    if (u > 0.1f && u < 0.3f && v > 0.15f && v < 0.45f) g = 220.f;
    if (u > 0.55f && u < 0.85f && v > 0.5f && v < 0.8f) g = 30.f;
    // disc
    float dx = u - 0.5f, dy = v - 0.25f;
    if (dx * dx * (float)w * w + dy * dy * (float)h * h < 0.015f * w * (float)h) g = 245.f;
    // chirp texture (fine detail)
    if (v > 0.82f) g += 40.f * std::sin(x * x * 0.0006f + t) * std::sin(y * 0.9f);
    // fine line pattern
    if (u > 0.35f && u < 0.5f && v > 0.55f && v < 0.78f) g += (((int)x / 3) & 1) ? 45.f : -45.f;
    return clampf(g, 0.f, 255.f);
}

static Img makeClean(int w, int h) {
    Img im{w, h, std::vector<uint32_t>((size_t)w * h)};
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            float l = scene((float)x, (float)y, w, h, 0.f);
            float r = clampf(l * 1.05f + 8.f, 0.f, 255.f), g = l, b = clampf(l * 0.85f + 15.f * ((float)x / w), 0.f, 255.f);
            im.px[(size_t)y * w + x] = 0xFF000000u | ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
        }
    return im;
}

static Img shiftNoise(const Img& c, int dx, int dy, float sigma, uint32_t seed, int mvx0 = -1) {
    Img o = c;
    std::mt19937 rng(seed);
    std::normal_distribution<float> nd(0.f, 1.f);
    for (int y = 0; y < c.h; y++)
        for (int x = 0; x < c.w; x++) {
            int sx = clampi(x + dx, 0, c.w - 1), sy = clampi(y + dy, 0, c.h - 1);
            uint32_t p = c.px[(size_t)sy * c.w + sx];
            float r = (float)((p >> 16) & 255), g = (float)((p >> 8) & 255), b = (float)(p & 255);
            if (mvx0 >= 0 && x >= mvx0 && x < mvx0 + 60 && y > 100 && y < 160) { r = 250; g = 40; b = 40; }  // "moving" object
            float s = sigma;
            r += s * nd(rng); g += s * nd(rng); b += s * nd(rng);
            o.px[(size_t)y * c.w + x] = 0xFF000000u | ((uint32_t)clampf(r + 0.5f, 0, 255) << 16) | ((uint32_t)clampf(g + 0.5f, 0, 255) << 8) | (uint32_t)clampf(b + 0.5f, 0, 255);
        }
    return o;
}

// ------------------------------------------------------------------ driver (mirrors the Kotlin side)
struct Cfg {
    int mode = 1;  // 0 single 1 stack 2 hdr 3 trails 4 doc
    float scale = 1.f;
    float denoise = 0.5f, sharp = 0.5f, detail = 0.45f, lift = 0.35f;
    bool local = true;
        float mergeSigma = 14.f;
    bool night = false;
    float look[19] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1};   // natural
};

static std::vector<uint32_t> runPipeline(const std::vector<Img>& frames, const std::vector<std::pair<float, float>>& shifts,
                                         int ref, const Cfg& c, double* msOut = nullptr, int* outW = nullptr, int* outH = nullptr) {
    const int n = (int)frames.size();
    const int w = frames[0].w, h = frames[0].h;
    float s = c.scale;
    if (s < 1.02f) s = 1.f;
    const int wo = s == 1.f ? w : (int)std::lround(w * s);
    const int ho = s == 1.f ? h : (int)std::lround(h * s);
    const bool isHdr = c.mode == 2 && n >= 2, isTrails = c.mode == 3 && n >= 2, isDoc = c.mode == 4;
    const bool merge = n >= 2 && c.mode != 0 && !isHdr;
    const bool local = c.local && n >= 2 && c.mode == 1;
    const int MGN = 16;
    int hs = (int)((isHdr ? 900000 : 1800000) / wo) - 2 * MGN;
    hs = std::max(96, std::min(480, hs));
    const int maxNr = hs + 2 * MGN;

    // base map (1/4 scale, blurred luma of ref)
    const int bw = w / 4, bh = h / 4;
    std::vector<float> base((size_t)bw * bh), tmp((size_t)bw * bh);
    for (int y = 0; y < bh; y++)
        for (int x = 0; x < bw; x++) {
            float acc = 0;
            for (int j = 0; j < 4; j++)
                for (int i = 0; i < 4; i++) {
                    uint32_t p = frames[ref].px[(size_t)(y * 4 + j) * w + x * 4 + i];
                    acc += 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
                }
            base[(size_t)y * bw + x] = acc / 16.f;
        }
    for (int k = 0; k < 3; k++) boxBlur(base.data(), base.data(), tmp.data(), bw, bh, 8);
    std::vector<float> sorted = base;
    std::sort(sorted.begin(), sorted.end());
    float median = sorted[sorted.size() / 2];

    const float nf = c.night ? 1.5f : 1.f;
    const float frameFactor = n >= 4 ? 0.75f : (n >= 2 ? 0.9f : 1.15f);
    const float dn = clampf(c.denoise * nf * frameFactor, 0.f, 1.6f);
    const float sharpAmt = (0.30f + 1.2f * c.sharp) * (s > 1.f ? 1.2f : 1.f) * (isDoc ? 1.5f : 1.f);
    const int sharpR = s >= 1.5f ? 2 : 1;
    const float coreT = 2.5f + 6.f * dn;
    const float hdrK = isHdr ? 0.6f : 1.f;
    const float midAmt = 0.45f * c.detail * hdrK;
    const int midR = std::max(3, (int)std::lround(4 * s));
    const float detailB = 1.f + 0.55f * c.detail * hdrK;
    const float lift = c.lift * hdrK;
    const float med = std::max(median, 6.f);
    const float gain = isHdr ? 1.f : (c.night ? clampf(0.34f * 255.f / med, 1.f, 3.2f) : clampf(0.27f * 255.f / med, 1.f, 1.35f));
    const int nSlots = (isHdr || (merge && !isTrails)) ? n : 1;

    int flags = (isHdr ? 1 : 0) | (isTrails ? 2 : 0) | (isDoc ? 4 : 0) | (merge ? 8 : 0) | (local ? 16 : 0);
    int ci[13] = {w, h, wo, ho, n, ref, maxNr, flags, sharpR, midR, bw, bh, nSlots};
    float cf[11] = {s, dn, sharpAmt, coreT, midAmt, detailB, lift, 1.f, 1.f, gain, 0.f};
    std::vector<float> sigma(n, c.mergeSigma), fw(n, 1.f);
    Pipe* p = pipe_create(ci, 13, cf, 11, base.data(), (int)base.size(), c.look, 19, sigma.data(), fw.data(), n);
    if (!p) { std::printf("pipe_create failed\n"); std::exit(2); }

    std::vector<uint32_t> out((size_t)wo * ho);
    std::vector<uint32_t> strip((size_t)hs * wo);
    const int srcRowsCap = (int)std::ceil(maxNr / s) + 10;
    std::vector<uint32_t> src((size_t)srcRowsCap * w);

    auto sampleF = [&](int f, int slot, int r0, int nr) {
        float dx = shifts[f].first, dy = shifts[f].second;
        auto readRows = [&](int yStart, int rows) {
            for (int r = 0; r < rows; r++) {
                int yy = clampi(yStart + r, 0, h - 1);
                std::memcpy(&src[(size_t)r * w], &frames[f].px[(size_t)yy * w], (size_t)w * 4);
            }
        };
        if (s == 1.f) {
            int idy = (int)std::floor(dy + 0.5f);
            readRows(r0 + idy, nr);
            pipe_sample(p, slot, src.data(), (long long)src.size(), nr, 0, dx, dy, r0, nr);
        } else {
            float invS = 1.f / s;
            int yTop = (int)std::floor(r0 * invS + dy) - 1;
            int yBot = (int)std::ceil((r0 + nr - 1) * invS + dy) + 2;
            int rows = yBot - yTop + 1;
            readRows(yTop, rows);
            pipe_sample(p, slot, src.data(), (long long)src.size(), rows, yTop, dx, dy, r0, nr);
        }
    };

    auto t0 = Clock::now();
    int y0 = 0;
    while (y0 < ho) {
        int y1 = std::min(ho, y0 + hs);
        int r0 = std::max(0, y0 - MGN), r1 = std::min(ho, y1 + MGN);
        int nr = r1 - r0;
        if (isHdr) { for (int f = 0; f < n; f++) sampleF(f, f, r0, nr); pipe_merge(p, 2, nr, 0); }
        else if (isTrails) { for (int f = 0; f < n; f++) { sampleF(f, 0, r0, nr); pipe_merge(p, 3, nr, f == 0 ? 1 : 0); } }
        else if (merge) { for (int f = 0; f < n; f++) sampleF(f, f, r0, nr); pipe_merge(p, 1, nr, 0); }
        else { sampleF(ref, 0, r0, nr); pipe_merge(p, 0, nr, 0); }
        pipe_post(p, r0, nr);
        pipe_finish(p, r0, y0, y1, strip.data(), (long long)strip.size());
        std::memcpy(&out[(size_t)y0 * wo], strip.data(), (size_t)(y1 - y0) * wo * 4);
        y0 = y1;
    }
    if (msOut) *msOut = ms_since(t0);
    if (outW) *outW = wo;
    if (outH) *outH = ho;
    pipe_destroy(p);
    return out;
}

static double psnr(const std::vector<uint32_t>& a, const std::vector<uint32_t>& b, int w, int h, int x0 = 0, int y0 = 0, int x1 = -1, int y1 = -1) {
    if (x1 < 0) x1 = w;
    if (y1 < 0) y1 = h;
    double se = 0;
    long long n = 0;
    for (int y = y0; y < y1; y++)
        for (int x = x0; x < x1; x++) {
            uint32_t p = a[(size_t)y * w + x], q = b[(size_t)y * w + x];
            for (int sft = 0; sft <= 16; sft += 8) { double d = (double)((p >> sft) & 255) - (double)((q >> sft) & 255); se += d * d; }
            n += 3;
        }
    double mse = se / (double)n;
    return mse < 1e-9 ? 99.0 : 10.0 * std::log10(255.0 * 255.0 / mse);
}

static int fails = 0;
#define CHECK(cond, msg)                                              \
    do {                                                              \
        if (!(cond)) { std::printf("  FAIL: %s\n", msg); fails++; }    \
        else std::printf("  ok:   %s\n", msg);                        \
    } while (0)

int main(int argc, char** argv) {
    bool bench = argc > 1 && std::string(argv[1]) == "bench";
    bool asanRun = argc > 1 && std::string(argv[1]) == "asan";

    std::printf("== fast math\n");
    {
        double maxE = 0, maxL = 0;
        for (float x = -30.f; x < 30.f; x += 0.0137f) { double e = std::fabs(fast_exp2(x) / std::exp2((double)x) - 1.0); maxE = std::max(maxE, e); }
        for (float x = 0.01f; x < 40.f; x *= 1.0071f) { double e = std::fabs(fast_log2(x) - std::log2((double)x)); maxL = std::max(maxL, e); }
        std::printf("  exp2 max rel err %.2e, log2 max abs err %.2e\n", maxE, maxL);
        CHECK(maxE < 2e-6, "fast_exp2 accuracy");
        CHECK(maxL < 2e-5, "fast_log2 accuracy");
        float t[4]; catmull(0.37f, t);
        CHECK(std::fabs(t[0] + t[1] + t[2] + t[3] - 1.f) < 1e-6f, "catmull weights sum to 1");
    }

    std::printf("== ncc_search\n");
    {
        const int w = 200, h = 150;
        std::vector<float> a(w * h), b(w * h);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) a[y * w + x] = 128 + 60 * std::sin(x * 0.21f) * std::cos(y * 0.17f) + 25 * std::sin(x * 0.7f + y * 0.3f);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) b[y * w + x] = a[clampi(y - 3, 0, h - 1) * w + clampi(x + 5, 0, w - 1)];
        int win[4] = {30, 30, 120, 80}, res[2];
        ncc_search(a.data(), b.data(), w, h, win, 0, 0, 8, 1, res);
        // b(x,y)=a(x+5,y-3)  => a pixel (x,y) is found at b(x-5, y+3)
        CHECK(res[0] == -5 && res[1] == 3, "finds a known shift (-5,+3)");
        ncc_search(a.data(), b.data(), w, h, win, 0, 0, 8, 2, res);
        CHECK(res[0] == -5 && res[1] == 3, "same with step 2");
    }

    // sizes chosen to be awkward (not multiples of 4 / 32) to stress edge handling
    const int W = 523, H = 389;
    Img clean = makeClean(W, H);

    std::printf("== robustness (all modes, scales, odd sizes)\n");
    {
        struct T { const char* name; int mode; float scale; bool local; int nf; };
        T ts[] = {{"single s1", 0, 1.f, false, 1}, {"single s1.5", 0, 1.5f, false, 1}, {"single s2", 0, 2.f, false, 1},
                  {"stack local s1", 1, 1.f, true, 4}, {"stack nolocal s1", 1, 1.f, false, 3}, {"stack s1.5", 1, 1.5f, true, 3},
                  {"stack s2", 1, 2.f, true, 5}, {"hdr s1", 2, 1.f, false, 3}, {"hdr s2", 2, 2.f, false, 3},
                  {"trails s1", 3, 1.f, false, 4}, {"doc s1", 4, 1.f, false, 1}, {"doc s2", 4, 2.f, false, 1}};
        for (auto& t : ts) {
            std::vector<Img> fr;
            std::vector<std::pair<float, float>> sh;
            for (int f = 0; f < t.nf; f++) {
                int dx = (f * 3) % 7 - 3, dy = (f * 5) % 5 - 2;
                if (f == 0) dx = dy = 0;
                fr.push_back(shiftNoise(clean, dx, dy, 6.f, 100 + f));
                sh.push_back({(float)-dx, (float)-dy});
            }
            Cfg c; c.mode = t.mode; c.scale = t.scale; c.local = t.local;
            for (int lk = 0; lk < 2; lk++) {
                if (lk) { float l2[19] = {1.2f, 0.3f, 0.3f, 0.4f, 0.f, -8, 4, 14, 14, 5, -10, 1.1f, 1.f, 0.9f, 0.3f, 1.2f, 0.03f, 6.f, 1.08f}; std::memcpy(c.look, l2, sizeof l2); }
                int ow, oh;
                auto out = runPipeline(fr, sh, 0, c, nullptr, &ow, &oh);
                bool ok = (int)out.size() == ow * oh;
                for (uint32_t p : out) if ((p >> 24) != 255) { ok = false; break; }
                char msg[120]; std::snprintf(msg, sizeof msg, "%s%s -> %dx%d, alpha=255", t.name, lk ? " +look" : "", ow, oh);
                CHECK(ok, msg);
            }
        }
    }
    if (asanRun) { std::printf("\n%s (%d failures)\n", fails ? "SOME CHECKS FAILED" : "ALL OK", fails); return fails ? 1 : 0; }

    std::printf("== quality: 5-frame merge vs single frame (noise sigma 10), PSNR vs same pipeline on clean input\n");
    {
        Cfg c0; c0.mode = 0;
        std::vector<Img> cleanOnly{clean};
        auto ref = runPipeline(cleanOnly, {{0, 0}}, 0, c0);
        auto sh = [&](int f, bool moving) { int dx = f == 0 ? 0 : (f * 3) % 7 - 3, dy = f == 0 ? 0 : (f * 5) % 5 - 2; return std::make_tuple(dx, dy, moving); };
        for (float sigma : {6.f, 10.f, 16.f}) {
            std::vector<Img> fr;
            std::vector<std::pair<float, float>> sf;
            for (int f = 0; f < 5; f++) {
                auto [dx, dy, mv] = sh(f, false);
                (void)mv;
                fr.push_back(shiftNoise(clean, dx, dy, sigma, 7 + f));
                sf.push_back({(float)-dx, (float)-dy});
            }
            Cfg a; a.mode = 0;
            auto outA = runPipeline({fr[0]}, {{0, 0}}, 0, a);
            const float msig = clampf(6.f + 1.97f * sigma, 8.f, 50.f);   // same formula the Kotlin aligner uses
            Cfg d; d.mode = 1; d.mergeSigma = msig;
            auto outD = runPipeline(fr, sf, 0, d);
            Cfg e; e.mode = 1; e.mergeSigma = msig; e.local = false;
            auto outE = runPipeline(fr, sf, 0, e);
            double pa = psnr(outA, ref, W, H), pd = psnr(outD, ref, W, H), pe = psnr(outE, ref, W, H);
            std::printf("  sigma %4.1f : single %.2f dB | 5-frame merge %.2f dB (no local align: %.2f dB)\n", sigma, pa, pd, pe);
            CHECK(pd > pa + 2.5, "5-frame merge beats single frame by >2.5 dB");
        }
    }
    std::printf("== local alignment recovers a wrong global shift (+-2 px)\n");
    {
        Cfg c0; c0.mode = 0; auto ref = runPipeline({clean}, {{0, 0}}, 0, c0);
        std::vector<Img> fr; std::vector<std::pair<float, float>> bad;
        for (int f = 0; f < 4; f++) { int dx = f ? (f % 2 ? 2 : -2) : 0, dy = f ? (f > 1 ? 1 : -1) : 0; fr.push_back(shiftNoise(clean, dx, dy, 8.f, 30 + f)); bad.push_back({0.f, 0.f}); }
        Cfg l; l.mode = 1; l.mergeSigma = 21.f; l.local = true;  double pl = psnr(runPipeline(fr, bad, 0, l), ref, W, H);
        Cfg n; n.mode = 1; n.mergeSigma = 21.f; n.local = false; double pn = psnr(runPipeline(fr, bad, 0, n), ref, W, H);
        Cfg a; a.mode = 0; double pa = psnr(runPipeline({fr[0]}, {{0.f, 0.f}}, 0, a), ref, W, H);
        std::printf("  single %.2f dB | merge without local align %.2f dB | merge with local align %.2f dB\n", pa, pn, pl);
        CHECK(pl > pn + 1.0, "local alignment clearly helps when global alignment is off");
    }
    std::printf("== ghosting: moving red box in frames 2..4 (must not leak into result)\n");
    {
        Cfg c0; c0.mode = 0;
        auto ref = runPipeline({clean}, {{0, 0}}, 0, c0);
        std::vector<Img> fr;
        std::vector<std::pair<float, float>> sf;
        for (int f = 0; f < 5; f++) { fr.push_back(shiftNoise(clean, 0, 0, 8.f, 50 + f, f == 0 ? -1 : 100 + f * 40)); sf.push_back({0.f, 0.f}); }
        // box region union of the moving positions (excluding frame 0, which has none)
        const float msig = clampf(6.f + 1.97f * 8.f, 8.f, 50.f);
        auto region = [&](const std::vector<uint32_t>& o, double& leak) {
            leak = 0; long long cnt = 0;
            for (int y = 100; y < 160; y++) for (int x = 120; x < 330; x++) { uint32_t q = o[(size_t)y * W + x], r0 = ref[(size_t)y * W + x]; leak += std::max(0, (int)((q >> 16) & 255) - (int)((r0 >> 16) & 255)); cnt++; }
            leak /= cnt;
            return psnr(o, ref, W, H, 120, 100, 330, 160);
        };
        Cfg d; d.mode = 1; d.mergeSigma = msig;
        double leak0, leak1;
        g_chromaK = 0.f;   auto outL = runPipeline(fr, sf, 0, d); double pL = region(outL, leak0);
        g_chromaK = 0.25f; auto outC = runPipeline(fr, sf, 0, d); double pC = region(outC, leak1);
        std::printf("  object region: luma-only weights %.2f dB (red leakage %.1f levels) | luma+chroma weights %.2f dB (leakage %.1f)\n", pL, leak0, pC, leak1);
        CHECK(pC > pL + 4.0, "chroma-aware weights remove most of the ghost");
        // and they must not cost noise averaging in static scenes
        std::vector<Img> st; std::vector<std::pair<float, float>> ss;
        for (int f = 0; f < 5; f++) { st.push_back(shiftNoise(clean, 0, 0, 10.f, 70 + f)); ss.push_back({0.f, 0.f}); }
        Cfg e; e.mode = 1; e.mergeSigma = clampf(6.f + 1.97f * 10.f, 8.f, 50.f);
        g_chromaK = 0.f;   double sL = psnr(runPipeline(st, ss, 0, e), ref, W, H);
        g_chromaK = 0.25f; double sC = psnr(runPipeline(st, ss, 0, e), ref, W, H);
        std::printf("  static scene (noise only): luma-only %.2f dB | luma+chroma %.2f dB\n", sL, sC);
        CHECK(sC > sL - 0.4, "no real loss of noise averaging in static scenes");
    }

    if (bench) {
        std::printf("== benchmark (this PC: %d threads)\n", Pool::get().threads());
        const int BW = 3000, BH = 2250;   // 6.75 MP
        Img big = makeClean(BW, BH);
        std::vector<Img> fr;
        std::vector<std::pair<float, float>> sf;
        for (int f = 0; f < 4; f++) { int dx = f ? f * 2 - 3 : 0, dy = f ? 2 - f : 0; fr.push_back(shiftNoise(big, dx, dy, 9.f, 1 + f)); sf.push_back({(float)-dx, (float)-dy}); }
        for (int sc = 0; sc < 2; sc++) {
            Cfg d; d.mode = 1; d.scale = sc ? 1.5f : 1.f;
            double ms = 0; int ow, oh;
            runPipeline(fr, sf, 0, d, &ms, &ow, &oh);
            std::printf("  4-frame stack %dx%d -> %dx%d : %.0f ms  (%.0f ms per output MP)\n", BW, BH, ow, oh, ms, ms / (ow * (double)oh / 1e6));
        }
        Cfg s1; s1.mode = 0; double ms = 0; int ow, oh;
        runPipeline({fr[0]}, {{0, 0}}, 0, s1, &ms, &ow, &oh);
        std::printf("  single frame  %dx%d : %.0f ms  (%.0f ms per MP)\n", ow, oh, ms, ms / (ow * (double)oh / 1e6));
    }
    std::printf("\n%s (%d failures)\n", fails ? "SOME CHECKS FAILED" : "ALL OK", fails);
    return fails ? 1 : 0;
}

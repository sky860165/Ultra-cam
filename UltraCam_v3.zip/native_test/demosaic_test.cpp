#include "../app/src/main/cpp/demosaic.hpp"
#include <cstdio>
#include <chrono>
int main(int argc,char**argv){
  int iters=argc>3?atoi(argv[3]):1;
  FILE*f=fopen(argv[1],"rb"); int w,h; fread(&w,4,1,f); fread(&h,4,1,f);
  std::vector<float> M((size_t)w*h); fread(M.data(),4,M.size(),f); fclose(f);
  std::vector<uint8_t> col((size_t)w*h);
  for(int y=0;y<h;y++)for(int x=0;x<w;x++){ col[(size_t)y*w+x]= ((y&1)==0&&(x&1)==0)?0: ((y&1)&&(x&1))?2:1; }
  std::vector<float> R,G,B;
  auto t0=std::chrono::steady_clock::now();
  uc::dm::demosaic(M.data(),w,h,col.data(),R,G,B,nullptr,iters);
  auto t1=std::chrono::steady_clock::now();
  fprintf(stderr,"%dx%d %d ms\n",w,h,(int)std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count());
  f=fopen(argv[2],"wb"); fwrite(R.data(),4,R.size(),f);fwrite(G.data(),4,G.size(),f);fwrite(B.data(),4,B.size(),f);fclose(f);
}

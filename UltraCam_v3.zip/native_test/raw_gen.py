# make synthetic RAW burst (RGGB, 12-bit-ish, black 64 white 1023) from a JPEG: linearise, mosaic, shift, Poisson-Gauss noise
import numpy as np, sys
from PIL import Image
src = sys.argv[1]; n = int(sys.argv[2]); outp = sys.argv[3]
im = Image.open(src).convert('RGB')
im = im.resize((1200, 1600)) if im.size[1] > im.size[0] else im.resize((1600, 1200))
a = np.asarray(im).astype(np.float32)/255.
lin = np.where(a<=0.04045, a/12.92, ((a+0.055)/1.055)**2.4)
# fake camera: scale so image is a bit dark (typical raw), sensor colour = sRGB * simple matrix (so ccm is its inverse)
cam = np.array([[0.62,0.30,0.08],[0.12,0.78,0.10],[0.05,0.20,0.75]],dtype=np.float32)
camimg = lin @ cam.T
wbg = np.array([0.50,1.0,0.62],dtype=np.float32)  # neutral
camimg = camimg*wbg*0.35
H,W,_ = camimg.shape; H-=H%2; W-=W%2
S,O = 0.0009, 4e-6
rng = np.random.default_rng(1)
black, white = 64., 1023.
frames=[]
for k in range(n):
    dx,dy = (0,0) if k==0 else (rng.integers(-6,7)*2*0+rng.integers(-5,6), rng.integers(-5,6))
    sh = np.roll(np.roll(camimg, dy, axis=0), dx, axis=1)[:H,:W]
    mos = np.zeros((H,W),np.float32)
    mos[0::2,0::2]=sh[0::2,0::2,0]; mos[0::2,1::2]=sh[0::2,1::2,1]; mos[1::2,0::2]=sh[1::2,0::2,1]; mos[1::2,1::2]=sh[1::2,1::2,2]
    mos = np.clip(mos,0,1)
    var = S*mos+O
    noisy = mos + rng.normal(size=mos.shape)*np.sqrt(var)
    raw = np.clip(noisy*(white-black)+black,0,white).astype(np.uint16)
    frames.append(raw)
np.stack(frames).tofile(outp)
open(outp+'.meta','w').write(f"{W} {H} {n} {S} {O} {wbg[0]} {wbg[1]} {wbg[2]}\n")
np.savetxt(outp+'.cam', cam)
print(W,H,n)

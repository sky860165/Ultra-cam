import numpy as np
from skimage import data
from scipy.ndimage import uniform_filter, convolve

def load_images():
    ims=[]
    for f in ['astronaut','chelsea','coffee','rocket']:
        try:
            a=getattr(data,f)()
            if a.ndim==3: ims.append(a[:,:,:3].astype(np.float32)/255.)
        except Exception as e: print('skip',f,e)
    return ims

def to_lin(a): return np.where(a<=0.04045,a/12.92,((a+0.055)/1.055)**2.4).astype(np.float32)
def to_srgb(a):
    a=np.clip(a,0,1); return np.where(a<=0.0031308,a*12.92,1.055*a**(1/2.4)-0.055)

def mosaic(img):
    H,W,_=img.shape; H-=H%2; W-=W%2; img=img[:H,:W]
    m=np.zeros((H,W),np.float32)
    m[0::2,0::2]=img[0::2,0::2,0]; m[0::2,1::2]=img[0::2,1::2,1]
    m[1::2,0::2]=img[1::2,0::2,1]; m[1::2,1::2]=img[1::2,1::2,2]
    return img,m

def sh(a,dy,dx):  # a shifted so out[y,x]=a[y+dy,x+dx] (mirror pad)
    p=max(abs(dy),abs(dx))
    ap=np.pad(a,p,mode='reflect')
    H,W=a.shape
    return ap[p+dy:p+dy+H,p+dx:p+dx+W]

def masks(H,W):
    y,x=np.mgrid[0:H,0:W]
    R=((y&1)==0)&((x&1)==0); B=((y&1)==1)&((x&1)==1); G=~(R|B)
    return R,G,B

def demosaic_ha(M):
    H,W=M.shape; R,Gm,B=masks(H,W)
    c=M
    gh=np.abs(sh(M,0,-1)-sh(M,0,1))+np.abs(2*c-sh(M,0,-2)-sh(M,0,2))
    gv=np.abs(sh(M,-1,0)-sh(M,1,0))+np.abs(2*c-sh(M,-2,0)-sh(M,2,0))
    eh=(sh(M,0,-1)+sh(M,0,1))*.5+(2*c-sh(M,0,-2)-sh(M,0,2))*.25
    ev=(sh(M,-1,0)+sh(M,1,0))*.5+(2*c-sh(M,-2,0)-sh(M,2,0))*.25
    g=np.where(gh<gv,eh,np.where(gv<gh,ev,.5*(eh+ev)))
    G=np.where(Gm,M,np.maximum(g,0))
    return finish_rb(M,G,Gm,R,B)

def finish_rb(M,G,Gm,R,B,diag_w=None):
    d=M-G  # colour difference known at R/B sites
    # at G sites: horizontal/vertical neighbours
    Hh=(sh(M,0,-1)-sh(G,0,-1)+sh(M,0,1)-sh(G,0,1))*.5
    Vv=(sh(M,-1,0)-sh(G,-1,0)+sh(M,1,0)-sh(G,1,0))*.5
    # G on red row (row even): horizontal neighbours are R
    H_,W_=M.shape
    y,x=np.mgrid[0:H_,0:W_]
    redrow=((y&1)==0)
    Rv=np.where(Gm,np.where(redrow,Hh,Vv),0)
    Bv=np.where(Gm,np.where(redrow,Vv,Hh),0)
    # at R/B sites: diagonals
    d1=np.abs(sh(M,-1,-1)-sh(M,1,1)); d2=np.abs(sh(M,-1,1)-sh(M,1,-1))
    e1=.5*((sh(M,-1,-1)-sh(G,-1,-1))+(sh(M,1,1)-sh(G,1,1)))
    e2=.5*((sh(M,-1,1)-sh(G,-1,1))+(sh(M,1,-1)-sh(G,1,-1)))
    e=np.where(d1<d2,e1,np.where(d2<d1,e2,.5*(e1+e2)))
    out=np.zeros(M.shape+(3,),np.float32)
    out[...,1]=G
    out[...,0]=np.where(R,M,np.where(B,G+e,G+Rv))
    out[...,2]=np.where(B,M,np.where(R,G+e,G+Bv))
    return np.maximum(out,0)

def cpsnr(a,b,crop=8):
    a=a[crop:-crop,crop:-crop]; b=b[crop:-crop,crop:-crop]
    mse=np.mean((to_srgb(a)-to_srgb(b))**2)
    return 10*np.log10(1/mse)

if __name__=='__main__':
    ims=load_images()
    tot=[]
    for im in ims:
        lin=to_lin(im); t,M=mosaic(lin)
        out=demosaic_ha(M)
        v=cpsnr(out,t); tot.append(v); print('HA',im.shape,round(v,2))
    print('mean',np.mean(tot))

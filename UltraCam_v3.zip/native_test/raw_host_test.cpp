#include "../app/src/main/cpp/raw.hpp"
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <chrono>
#include <cmath>
using namespace uc;
int main(int argc, char** argv) {
    int W, H, n; double S, O, wr, wg, wbb;
    FILE* m = fopen("burst.raw.meta", "r"); fscanf(m, "%d %d %d %lf %lf %lf %lf %lf", &W, &H, &n, &S, &O, &wr, &wg, &wbb); fclose(m);
    int use = argc > 1 ? atoi(argv[1]) : n;
    const char* outName = argc > 2 ? argv[2] : "out.ppm";
    std::vector<uint16_t> data((size_t)W * H * n);
    FILE* f = fopen("burst.raw", "rb"); fread(data.data(), 2, data.size(), f); fclose(f);
    float cam[9]; { FILE* c = fopen("burst.raw.cam", "r"); for (int i = 0; i < 9; i++) { double v; fscanf(c, "%lf", &v); cam[i] = (float)v; } fclose(c); }
    // forward matrix = sRGB->XYZ(D50) * inv(cam)
    const float s2x[9] = {0.4360747f, 0.3850649f, 0.1430804f, 0.2225045f, 0.7168786f, 0.0606169f, 0.0139322f, 0.0971045f, 0.7141733f};
    // inverse of cam
    double a = cam[0], b = cam[1], c = cam[2], d = cam[3], e = cam[4], ff = cam[5], g = cam[6], h = cam[7], i = cam[8];
    double det = a * (e * i - ff * h) - b * (d * i - ff * g) + c * (d * h - e * g);
    float ic[9] = {(float)((e * i - ff * h) / det), (float)((c * h - b * i) / det), (float)((b * ff - c * e) / det),
                   (float)((ff * g - d * i) / det), (float)((a * i - c * g) / det), (float)((c * d - a * ff) / det),
                   (float)((d * h - e * g) / det), (float)((b * g - a * h) / det), (float)((a * e - b * d) / det)};
    float fm[9];
    for (int r = 0; r < 3; r++) for (int cc = 0; cc < 3; cc++) fm[r * 3 + cc] = s2x[r * 3] * ic[cc] + s2x[r * 3 + 1] * ic[3 + cc] + s2x[r * 3 + 2] * ic[6 + cc];
    float neutral[3] = {(float)wr, (float)wg, (float)wbb}, wb[3], ccm[9], cct;
    int used = raw_color_calib(fm, fm, nullptr, nullptr, nullptr, nullptr, 21, 17, neutral, wb, ccm, &cct);
    printf("calib forward=%d wb=%.3f %.3f %.3f cct=%.0f ccm0=%.3f (expect %.3f)\n", used, wb[0], wb[1], wb[2], cct, ccm[0], ic[0]);
    RawInit in{}; in.w = W; in.h = H; in.cfa = 0; in.cropX = 0; in.cropY = 0; in.outW = W; in.outH = H;
    for (int k = 0; k < 4; k++) in.black[k] = 64.f; in.white = 1023.f;
    for (int k = 0; k < 3; k++) in.wb[k] = wb[k];
    for (int k = 0; k < 9; k++) in.ccm[k] = ccm[k];
    in.noiseS = (float)S; in.noiseO = (float)O;
    RawPipe* p = raw_create(in);
    if (!p) { printf("create failed\n"); return 1; }
    auto t0 = std::chrono::steady_clock::now();
    for (int k = 0; k < use; k++) { int r = raw_add_frame(p, data.data() + (size_t)W * H * k, W * 2, 1.f, 1.f, nullptr); if (r) printf("add %d -> %d\n", k, r); }
    auto t1 = std::chrono::steady_clock::now();
    float prm[RAW_P_COUNT] = {};
    prm[RAW_P_EV] = 0; prm[RAW_P_SHADOWS] = 0.5f; prm[RAW_P_HIGHLIGHTS] = 0.5f; prm[RAW_P_CONTRAST] = 0.35f; prm[RAW_P_VIBRANCE] = 0.4f; prm[RAW_P_SATURATION] = 1.08f;
    prm[RAW_P_HUEBOOST] = 0.5f; prm[RAW_P_AWB] = 0.5f; prm[RAW_P_NR_LUMA] = 0.6f; prm[RAW_P_NR_CHROMA] = 0.7f; prm[RAW_P_SHARPEN] = 0.5f; prm[RAW_P_DECONV] = 0.4f; prm[RAW_P_CLARITY] = 0.3f; prm[RAW_P_DEHAZE] = 0.6f;
    raw_prepare(p, prm, RAW_P_COUNT);
    auto t2 = std::chrono::steady_clock::now();
    printf("neff=%.2f g0=%.2f awb %.3f %.3f\n", raw_info(p, 0), raw_info(p, 1), raw_info(p, 2), raw_info(p, 3));
    std::vector<uint32_t> img((size_t)W * H);
    for (int y = 0; y < H; y += 96) raw_strip(p, y, std::min(H, y + 96), img.data() + (size_t)y * W);
    auto t3 = std::chrono::steady_clock::now();
    auto ms = [](auto a, auto b) { return (int)std::chrono::duration_cast<std::chrono::milliseconds>(b - a).count(); };
    printf("merge %d ms, prepare %d ms, develop %d ms (%d frames, %dx%d)\n", ms(t0, t1), ms(t1, t2), ms(t2, t3), use, W, H);
    FILE* o = fopen(outName, "wb"); fprintf(o, "P6\n%d %d\n255\n", W, H);
    for (size_t k = 0; k < img.size(); k++) { unsigned char px[3] = {(unsigned char)(img[k] >> 16), (unsigned char)(img[k] >> 8), (unsigned char)img[k]}; fwrite(px, 1, 3, o); }
    fclose(o);
    raw_destroy(p);
    return 0;
}

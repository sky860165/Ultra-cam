import com.ultracam.app.*
fun check(c: Boolean, m: String) { println((if (c) "ok:   " else "FAIL: ") + m); if (!c) System.exit(1) }
fun main() {
    fun st(iso: Int, expMs: Double, mean: Float, mo: Float, hi: Float = 1f, sh: Float = 2f, front: Boolean = false) =
        SceneStats(iso, (expMs * 1e6).toLong(), mean, mean, hi, sh, mo, front)
    val sun = AiDirector.plan(st(100, 2.0, 110f, 1f))
    check(sun.light == Light.BRIGHT && sun.frames == 3 && sun.shutter == ShutterBias.AUTO, "sunny scene -> BRIGHT, 3 frames")
    val indoor = AiDirector.plan(st(400, 33.0, 95f, 1f))
    check(indoor.light == Light.NORMAL && indoor.frames == 4, "indoor ISO400 1/30 -> NORMAL, 4 frames")
    val dimStill = AiDirector.plan(st(1600, 66.0, 50f, 1f))
    check(dimStill.light == Light.DIM && dimStill.shutter == ShutterBias.LONG && dimStill.frames == 5, "dim + still -> LONG shutter, 5 frames")
    val dimMoving = AiDirector.plan(st(1600, 66.0, 50f, 12f))
    check(dimMoving.shutter == ShutterBias.FAST && dimMoving.frames == 4, "dim + motion -> FAST shutter, fewer frames")
    val dark = AiDirector.plan(st(3200, 100.0, 30f, 1f))
    check(dark.light == Light.DARK && dark.night && dark.frames == 6 && dark.denoiseMul > 1.2f && dark.bokeh == 0f, "dark -> night, 6 frames, stronger denoise, no bokeh")
    val hdr = AiDirector.plan(st(100, 10.0, 100f, 1f, hi = 9f, sh = 20f))
    check(hdr.hdr && hdr.evBias < 0f, "high contrast -> HDR and negative EV")
    val selfie = AiDirector.plan(st(400, 33.0, 60f, 1f, front = true))
    check(selfie.frames == 5 && selfie.evBias > 0f && !selfie.hdr, "front: +1 frame, EV lift, no HDR")
    check(AiDirector.plan(st(100, 2.0, 110f, 1f), 0.8f).bokeh == 0.8f, "bokeh passes through in good light")
    val a = FloatArray(100) { 50f }; val b = FloatArray(100) { 50f + 10f }
    check(AiDirector.motionScore(a, a) == 0f && Math.abs(AiDirector.motionScore(a, b) - 10f) < 1e-3f, "motion score")
    check(AiDirector.plan(SceneStats(0, 0, 128f, 128f, 0f, 0f, 0f, false)).light == Light.NORMAL, "unknown metadata -> NORMAL")
    println("ALL OK")
}

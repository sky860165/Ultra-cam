import subprocess, numpy as np
from demosaic_ref import *
for iters in (0,1):
    tot=[]
    for k,im in enumerate(load_images()):
        lin=to_lin(im); t,M=mosaic(lin); H,W=M.shape
        with open('in.bin','wb') as f:
            np.array([W,H],np.int32).tofile(f); M.astype(np.float32).tofile(f)
        subprocess.run(['./demosaic_test','in.bin','out.bin',str(iters)],check=True)
        o=np.fromfile('out.bin',np.float32).reshape(3,H,W).transpose(1,2,0)
        tot.append(cpsnr(o,t))
    print('C++ iters',iters,round(float(np.mean(tot)),2),[round(float(x),1) for x in tot])

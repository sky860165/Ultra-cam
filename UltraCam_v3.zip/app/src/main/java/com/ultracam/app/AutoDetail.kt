package com.ultracam.app

import kotlin.math.ln
import kotlin.math.max

/** Result of the "Auto Details" balance: how hard to denoise / sharpen / pull detail for the light the sensor is seeing right now. */
data class DetailTune(
    val denoise: Float,   // 0..1
    val sharp: Float,     // 0..1
    val detail: Float,    // 0..1
    val noiseT: Float,    // 0 = very bright (clean), 1 = very dark (noisy)
    val label: String
)

/**
 * Auto Details: detail vs noise is a trade-off that depends on how much light reaches the sensor.
 * Bright light (low ISO, short shutter) = clean signal  -> push detail + sharpness, denoise lightly.
 * Low light (high ISO / long shutter)   = noisy signal  -> hold detail back, denoise harder, so noise is not sharpened.
 * The user's "Detail level" (0..100, 50 = balanced) only biases the curve, and the bias fades out as light drops.
 * Pure Kotlin (no Android) so it can be unit tested.
 */
object AutoDetail {

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    /** 0..1 from ISO x shutter ("exposure effort"): sunny ~0.2, shade ~1, bright indoor ~13, dim ~100, dark 300+. */
    fun noiseT(iso: Int, expNs: Long, front: Boolean): Float {
        if (iso <= 0 || expNs <= 0L) return if (front) 0.45f else 0.30f
        val effort = iso.toDouble() * (expNs / 1e9)
        var t = (ln(max(effort, 1e-3) / 0.3) / ln(1000.0)).toFloat()
        if (front) t += 0.12f                      // front sensors are smaller / noisier
        return t.coerceIn(0f, 1f)
    }

    /** frames = how many frames get merged (merging N frames cuts noise ~sqrt(N), so more detail can be kept). */
    fun tune(iso: Int, expNs: Long, front: Boolean, level: Int, frames: Int = 1): DetailTune {
        val fr = frames.coerceIn(1, 12)
        val t = (noiseT(iso, expNs, front) * (1f - 0.40f * (fr - 1) / 11f)).coerceIn(0f, 1f)
        val b = ((level - 50) / 50f).coerceIn(-1f, 1f)
        val k = 1f - 0.55f * t
        val dFloor = if (fr >= 5) 0.45f else 0.05f     // merged night frames: keep real clarity
        val sFloor = if (fr >= 5) 0.40f else 0.05f
        val detail = (lerp(0.72f, 0.30f, t) + 0.20f * b * k).coerceIn(dFloor, 1f)
        val sharp = (lerp(0.68f, 0.28f, t) + 0.16f * b * k).coerceIn(sFloor, 1f)
        val denoise = (lerp(0.22f, 0.82f, t) - 0.16f * b * (1f - 0.5f * t)).coerceIn(0.05f, 1f)
        val light = when {
            t < 0.20f -> "bright"
            t < 0.50f -> "normal"
            t < 0.80f -> "dim"
            else -> "dark"
        }
        return DetailTune(denoise, sharp, detail, t, light)
    }
}

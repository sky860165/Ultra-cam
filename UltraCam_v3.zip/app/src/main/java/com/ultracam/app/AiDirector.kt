package com.ultracam.app

import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/** What the camera sees right now (all cheap numbers from the live preview + Camera2 metadata). */
data class SceneStats(
    val iso: Int,
    val expNs: Long,
    val meanLuma: Float,        // 0..255, whole frame
    val centerLuma: Float,      // 0..255, centre area (faces / subject)
    val highPct: Float,         // % of pixels nearly blown
    val shadowPct: Float,       // % of pixels nearly black
    val motion: Float,          // mean |luma change| between two preview frames (0..255), subject + hand shake
    val front: Boolean
)

enum class Light { BRIGHT, NORMAL, DIM, DARK }

/** Shutter policy: FAST = freeze motion (short exposure), LONG = allow long exposure (still scene, dark), AUTO = camera default. */
enum class ShutterBias { FAST, AUTO, LONG }

data class AiPlan(
    val light: Light,
    val frames: Int,
    val evBias: Float,
    val shutter: ShutterBias,
    val hdr: Boolean,
    val night: Boolean,
    val denoiseMul: Float,
    val sharpMul: Float,
    val enhanceAdd: Float,
    val bokeh: Float,           // simulated aperture (portrait blur strength, applied only if a person is found)
    val reason: String
) {
    companion object {
        val NEUTRAL = AiPlan(Light.NORMAL, 4, 0f, ShutterBias.AUTO, false, false, 1f, 1f, 0f, 0f, "")
    }
}

/**
 * "AI director": decides light class, shutter policy, frame count, exposure bias and processing strengths for the next shot.
 * Pure Kotlin (no Android) so it can be unit tested. Aperture and focal length are fixed in phone hardware, so the
 * levers are shutter/ISO behaviour, frame count, and software aperture (portrait blur).
 */
object AiDirector {

    fun classify(s: SceneStats): Light {
        if (s.iso <= 0 || s.expNs <= 0L) return Light.NORMAL
        // exposure "effort" = ISO x shutter seconds: sunny ~0.2, shade ~1, bright indoor ~13, dim ~100, dark 300+
        val effort = s.iso * (s.expNs / 1e9)
        return when {
            effort < 0.8 -> Light.BRIGHT
            effort < 20.0 -> Light.NORMAL
            effort < 120.0 -> Light.DIM
            else -> Light.DARK
        }
    }

    fun plan(s: SceneStats, userBokeh: Float = 0f): AiPlan {
        val light = classify(s)
        val moving = s.motion > 7f
        val still = s.motion < 2.5f

        var frames = when (light) { Light.BRIGHT -> 3; Light.NORMAL -> 4; Light.DIM -> 5; Light.DARK -> 6 }
        if (s.front) frames += 1
        if (moving) frames = max(3, frames - 1)          // fewer frames while things move: less to reject / wait for

        val shutter = when {
            moving -> ShutterBias.FAST
            still && (light == Light.DIM || light == Light.DARK) -> ShutterBias.LONG
            else -> ShutterBias.AUTO
        }

        val hdr = !s.front && s.highPct > 4f && s.shadowPct > 8f && s.iso < 1600
        val night = light == Light.DARK || (s.meanLuma < 55f && s.iso > 800)

        // exposure bias (EV): lift dark subjects/faces, protect highlights
        val meanUsed = if (s.front) s.centerLuma else s.meanLuma
        val target = if (s.front) 112f else 105f
        var ev = (ln(target / max(meanUsed, 8f)) / ln(2f))
        if (!s.front && s.highPct > 5f) ev = min(ev, -(0.4f + min(s.highPct, 20f) / 20f * 0.9f))
        val maxUp = if (!s.front && s.highPct > 3f) 0.3f else if (s.front) 2.0f else 1.3f
        ev = ev.coerceIn(-1.3f, maxUp)
        if (kotlin.math.abs(ev) < 0.3f) ev = 0f

        val denoiseMul = when (light) { Light.BRIGHT -> 0.85f; Light.NORMAL -> 1f; Light.DIM -> 1.15f; Light.DARK -> 1.3f }
        var sharpMul = when (light) { Light.BRIGHT -> 1.1f; Light.NORMAL -> 1f; Light.DIM -> 0.92f; Light.DARK -> 0.85f }
        if (moving) sharpMul *= 0.92f
        var enh = 0f
        if (meanUsed < 70f) enh += 0.10f              // dim scenes gain most from tone lift
        if (s.highPct > 6f) enh -= 0.05f              // already hot: don't push contrast further
        if (light == Light.BRIGHT && s.shadowPct < 3f && s.highPct < 2f) enh += 0.05f   // flat daylight / haze

        val bokeh = when (light) {
            Light.BRIGHT, Light.NORMAL -> userBokeh
            Light.DIM -> userBokeh * 0.75f
            Light.DARK -> 0f                             // person mask is unreliable in noise
        }

        val why = StringBuilder()
        why.append(when (light) { Light.BRIGHT -> "bright"; Light.NORMAL -> "normal light"; Light.DIM -> "dim"; Light.DARK -> "dark" })
        if (moving) why.append(" • motion → fast shutter")
        else if (shutter == ShutterBias.LONG) why.append(" • steady → long exposure")
        if (hdr) why.append(" • HDR")
        if (ev != 0f) why.append(" • EV ").append(String.format(java.util.Locale.US, "%+.1f", ev))
        why.append(" • ").append(frames).append(" frames")
        return AiPlan(light, frames, ev, shutter, hdr, night, denoiseMul, sharpMul, enh, bokeh, why.toString())
    }

    /** Mean absolute luma change between two equally-sized luma planes, sampled sparsely (cheap enough for every preview tick). */
    fun motionScore(prev: FloatArray?, cur: FloatArray): Float {
        if (prev == null || prev.size != cur.size || cur.isEmpty()) return 0f
        var acc = 0f
        var n = 0
        var i = 0
        while (i < cur.size) { acc += kotlin.math.abs(cur[i] - prev[i]); n++; i += 3 }
        return if (n > 0) acc / n else 0f
    }
}

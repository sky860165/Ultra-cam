package com.ultracam.app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/** Records gyroscope magnitude (rad/s) so RAW frames shot while the phone was moving can be down-weighted. */
class GyroMeter(private val sm: SensorManager) : SensorEventListener {
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val ts = LongArray(512)
    private val mag = FloatArray(512)
    private var n = 0
    private var running = false

    val available: Boolean get() = gyro != null

    fun start() {
        if (running || gyro == null) return
        running = true
        try { sm.registerListener(this, gyro, 10_000) } catch (e: Exception) { running = false }
    }

    fun stop() {
        if (!running) return
        running = false
        try { sm.unregisterListener(this) } catch (e: Exception) { }
    }

    @Synchronized
    override fun onSensorChanged(e: SensorEvent) {
        val m = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        val i = n % ts.size
        ts[i] = e.timestamp
        mag[i] = m
        n++
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    /** peak angular speed (rad/s) between two elapsedRealtime-nanos timestamps; -1 when no sample is available */
    @Synchronized
    fun peakBetween(t0: Long, t1: Long): Float {
        var best = -1f
        val cnt = minOf(n, ts.size)
        for (k in 0 until cnt) {
            val t = ts[k]
            if (t in t0..t1 && mag[k] > best) best = mag[k]
        }
        return best
    }

    /** peak over the last [ms] milliseconds */
    fun recentPeak(ms: Long): Float {
        val now = SystemClock.elapsedRealtimeNanos()
        return peakBetween(now - ms * 1_000_000L, now)
    }
}

package com.ultracam.app

import android.graphics.Bitmap
import android.util.Log
import kotlin.math.max
import kotlin.math.min

/**
 * Final-photo luma denoise (non-local means, native). Runs after the merge and BEFORE colour fix / beauty, so the beauty filter
 * works on clean data and never has to smear the face to hide grain. Edges, hair, beard and skin texture are kept because only
 * pixels whose 5x5 neighbourhood matches are averaged.
 * The noise level is measured once on three strips of the photo and shared by all strips, so there are no seams.
 */
object Denoise {
    private const val TAG = "UltraCamNlm"

    fun apply(bmp: Bitmap, strength: Float, keep: Float = 0.35f): Boolean {
        if (!NativeEngine.ok || !bmp.isMutable) return false
        val w = bmp.width
        val h = bmp.height
        if (w < 64 || h < 64 || strength < 0.03f) return false
        return try {
            val searchR = if (w.toLong() * h > 13_000_000L) 2 else 3
            // ---- noise level: median of 3 strips (25 %, 50 %, 75 % of the height)
            val sr = min(160, h / 4)
            val buf = IntArray(w * sr)
            val vals = ArrayList<Float>()
            for (f in floatArrayOf(0.25f, 0.5f, 0.75f)) {
                val y0 = (h * f).toInt().coerceIn(0, h - sr)
                bmp.getPixels(buf, 0, w, 0, y0, w, sr)
                val c = NativeEngine.nlmNoise(buf, w, sr, searchR)
                if (c > 0f) vals.add(c)
            }
            if (vals.isEmpty()) return false
            vals.sort()
            val c2 = vals[vals.size / 2]
            if (c2 < 1.2f) return false                          // clean photo: nothing to remove
            // ---- strips with overlap
            val rows = 576
            val margin = 10
            var y = 0
            while (y < h) {
                val yEnd = min(h, y + rows)
                val ya = max(0, y - margin)
                val yb = min(h, yEnd + margin)
                val hs = yb - ya
                val px = IntArray(w * hs)
                bmp.getPixels(px, 0, w, 0, ya, w, hs)
                NativeEngine.nlm(px, w, hs, strength, searchR, keep, c2)
                bmp.setPixels(px, (y - ya) * w, w, 0, y, w, yEnd - y)
                y = yEnd
            }
            true
        } catch (t: Throwable) {
            Log.w(TAG, "nlm failed", t)
            false
        }
    }
}

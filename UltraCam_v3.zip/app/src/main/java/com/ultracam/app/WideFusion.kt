package com.ultracam.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RectF
import android.util.Log
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Ultra-wide fusion: the main lens image (narrow, sharp, 16MP) is registered onto the ultra-wide image (wide, 8MP)
 * and pasted in at native resolution; the ultra-wide only supplies the outer ring. Result = ultra-wide field of view
 * with main-lens detail in the middle.
 *
 * Registration = scale (k = main width / ultra-wide width) + translation, found by normalised cross-correlation of
 * blurred gradient maps, coarse -> fine over three resolutions. Colour of the ultra-wide is matched to the main lens
 * and the seam is feathered, so lens differences / small parallax fade out instead of showing a hard edge.
 */
object WideFusion {
    private const val TAG = "UltraCamWide"
    private const val MIN_SCORE = 0.20f

    private class Gray(val w: Int, val h: Int, val g: FloatArray)
    class Hit(val k: Float, val cx: Float, val cy: Float, val score: Float)

    // ------------------------------------------------------------------ helpers
    /** Always returns a NEW bitmap of exactly w x h (halving steps first, so big downscales don't alias). */
    private fun shrink(src: Bitmap, w: Int, h: Int): Bitmap {
        var cur = src
        var own = false
        while (cur.width / 2 >= w && cur.height / 2 >= h) {
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (own) cur.recycle()
            cur = n
            own = true
        }
        if (cur.width != w || cur.height != h) {
            val n = Bitmap.createScaledBitmap(cur, w, h, true)
            if (own) cur.recycle()
            cur = n
            own = true
        }
        if (!own) return src.copy(Bitmap.Config.ARGB_8888, false)
        return cur
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        val d = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val row = y * w
            var acc = 0f
            for (x in -r..r) acc += src[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = acc / d
                acc += src[row + min(w - 1, x + r + 1)] - src[row + max(0, x - r)]
            }
        }
        for (x in 0 until w) {
            var acc = 0f
            for (y in -r..r) acc += tmp[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = acc / d
                acc += tmp[min(h - 1, y + r + 1) * w + x] - tmp[max(0, y - r) * w + x]
            }
        }
        return out
    }

    /** Blurred gradient magnitude (robust to the colour / exposure difference between the two lenses). */
    private fun gradOf(bmp: Bitmap): Gray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val g = FloatArray(w * h)
        for (i in px.indices) {
            val p = px[i]
            g[i] = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
        }
        val m = FloatArray(w * h)
        for (y in 1 until h - 1) {
            val r = y * w
            for (x in 1 until w - 1) {
                val gx = g[r + x + 1] - g[r + x - 1]
                val gy = g[r + w + x] - g[r - w + x]
                m[r + x] = sqrt(gx * gx + gy * gy)
            }
        }
        return Gray(w, h, boxBlur(m, w, h, 2))
    }

    /** Slides the main image (scaled to k x ultra-wide width) around (cxn, cyn) and returns the best NCC position. */
    private fun scan(g: Gray, m960: Bitmap, k: Float, cxn: Float, cyn: Float, rx: Int, ry: Int, stride: Int): Hit? {
        val tw = (k * g.w).roundToInt()
        val th = (tw * m960.height.toFloat() / m960.width).roundToInt()
        if (tw < 24 || th < 24 || tw > g.w - 4 || th > g.h - 4) return null
        val sm = shrink(m960, tw, th)
        val t = gradOf(sm)
        sm.recycle()
        val tg = t.g
        var n = 0
        var sT = 0.0
        var sTT = 0.0
        var ty = 0
        while (ty < th) {
            var tx = 0
            while (tx < tw) {
                val v = tg[ty * tw + tx].toDouble()
                sT += v
                sTT += v * v
                n++
                tx += stride
            }
            ty += stride
        }
        val vT = sTT - sT * sT / n
        if (n < 16 || vT < 1e-3) return null
        val ox0 = (cxn * g.w - tw / 2f).roundToInt()
        val oy0 = (cyn * g.h - th / 2f).roundToInt()
        var best = -2.0
        var bx = ox0
        var by = oy0
        val gg = g.g
        for (oy in max(0, oy0 - ry)..min(g.h - th, oy0 + ry)) {
            for (ox in max(0, ox0 - rx)..min(g.w - tw, ox0 + rx)) {
                var sP = 0.0
                var sPP = 0.0
                var sTP = 0.0
                var yy = 0
                while (yy < th) {
                    val rowG = (oy + yy) * g.w + ox
                    val rowT = yy * tw
                    var xx = 0
                    while (xx < tw) {
                        val p = gg[rowG + xx].toDouble()
                        val q = tg[rowT + xx].toDouble()
                        sP += p
                        sPP += p * p
                        sTP += p * q
                        xx += stride
                    }
                    yy += stride
                }
                val vP = sPP - sP * sP / n
                if (vP <= 1e-6) continue
                val cov = sTP - sT * sP / n
                val sc = cov / sqrt(vT * vP)
                if (sc > best) { best = sc; bx = ox; by = oy }
            }
        }
        if (best < -1.5) return null
        return Hit(k, (bx + tw / 2f) / g.w, (by + th / 2f) / g.h, best.toFloat())
    }

    /** Finds where the main image sits inside the ultra-wide image. null = no reliable match. */
    fun register(main: Bitmap, uw: Bitmap): Hit? {
        val aspM = main.height.toFloat() / main.width
        val aspU = uw.height.toFloat() / uw.width
        val m960 = shrink(main, 960, (960f * aspM).roundToInt())
        val u960 = shrink(uw, 960, (960f * aspU).roundToInt())
        val u480 = shrink(u960, 480, (480f * aspU).roundToInt())
        val u240 = shrink(u480, 240, (240f * aspU).roundToInt())
        val g240 = gradOf(u240)
        val g480 = gradOf(u480)
        val g960 = gradOf(u960)
        u240.recycle(); u480.recycle(); u960.recycle()
        try {
            // coarse: unknown zoom ratio (ultra-wide FOV differs per phone), 5% steps from 0.30 to 0.86
            var best: Hit? = null
            var k = 0.30f
            while (k <= 0.86f) {
                val h = scan(g240, m960, k, 0.5f, 0.5f, 34, 28, 3)
                if (h != null && (best == null || h.score > best.score)) best = h
                k *= 1.05f
            }
            var cur: Hit = best ?: return null
            // medium
            var b2: Hit? = null
            for (f in floatArrayOf(0.96f, 0.98f, 1.0f, 1.02f, 1.04f)) {
                val h = scan(g480, m960, cur.k * f, cur.cx, cur.cy, 5, 5, 2)
                if (h != null && (b2 == null || h.score > b2.score)) b2 = h
            }
            if (b2 != null) cur = b2
            // fine
            var b3: Hit? = null
            for (f in floatArrayOf(0.99f, 1.0f, 1.01f)) {
                val h = scan(g960, m960, cur.k * f, cur.cx, cur.cy, 4, 4, 3)
                if (h != null && (b3 == null || h.score > b3.score)) b3 = h
            }
            if (b3 != null) cur = b3
            Log.i(TAG, "register: k=${cur.k} cx=${cur.cx} cy=${cur.cy} score=${cur.score}")
            return cur
        } finally {
            m960.recycle()
        }
    }

    /** Mean R,G,B over the central 70% of a bitmap. */
    private fun meanRgb(b: Bitmap): FloatArray {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        var r = 0.0
        var g = 0.0
        var bl = 0.0
        var n = 0
        for (y in (h * 0.15f).toInt() until (h * 0.85f).toInt()) {
            for (x in (w * 0.15f).toInt() until (w * 0.85f).toInt()) {
                val p = px[y * w + x]
                r += (p shr 16) and 255
                g += (p shr 8) and 255
                bl += p and 255
                n++
            }
        }
        if (n == 0) return floatArrayOf(128f, 128f, 128f)
        return floatArrayOf((r / n).toFloat(), (g / n).toFloat(), (bl / n).toFloat())
    }

    private fun smooth(t: Float): Float {
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    /**
     * main + ultra-wide (both already processed, same orientation) -> wide image with main detail in the middle.
     * Returns null when the two cannot be matched reliably (caller then keeps both images separately).
     */
    fun fuse(main: Bitmap, uw: Bitmap, status: (String) -> Unit): Bitmap? {
        status("Wide: lenses match ho rahe hain…")
        val hit = register(main, uw) ?: return null
        if (hit.score < MIN_SCORE) {
            Log.w(TAG, "match too weak: ${hit.score}")
            return null
        }
        status("Wide: fusion…")
        val k = hit.k
        val uwW = uw.width
        val uwH = uw.height

        // output size: main stays ~native, UW is upscaled to match; capped by heap
        val maxPx = min(26_000_000L, max(10_000_000L, Runtime.getRuntime().maxMemory() / 24L))
        var wOut = (main.width / k).roundToInt()
        var hOut = (wOut.toLong() * uwH / uwW).toInt()
        val px = wOut.toLong() * hOut
        if (px > maxPx) {
            val s = sqrt(maxPx.toDouble() / px.toDouble()).toFloat()
            wOut = (wOut * s).toInt()
            hOut = (wOut.toLong() * uwH / uwW).toInt()
        }
        if (wOut < uwW) { wOut = uwW; hOut = uwH }

        val mw2 = (k * wOut).roundToInt().coerceAtLeast(16)
        val mh2 = (mw2 * main.height.toFloat() / main.width).roundToInt().coerceAtLeast(16)
        val px0 = (hit.cx * wOut - mw2 / 2f).roundToInt()
        val py0 = (hit.cy * hOut - mh2 / 2f).roundToInt()

        // ---- colour match: scale the ultra-wide channels so its overlap area has the same mean as the main lens
        var gr = 1f
        var gg = 1f
        var gb = 1f
        try {
            val rx = ((hit.cx - k / 2f) * uwW).roundToInt().coerceIn(0, uwW - 2)
            val ry = ((hit.cy * uwH) - (k * uwW * main.height.toFloat() / main.width) / 2f).roundToInt().coerceIn(0, uwH - 2)
            val rw = min(uwW - rx, (k * uwW).roundToInt()).coerceAtLeast(2)
            val rh = min(uwH - ry, (k * uwW * main.height.toFloat() / main.width).roundToInt()).coerceAtLeast(2)
            val sub = Bitmap.createBitmap(uw, rx, ry, rw, rh)
            val subS = shrink(sub, 96, max(8, (96f * rh / rw).roundToInt()))
            if (sub !== uw) sub.recycle()
            val mainS = shrink(main, 96, max(8, (96f * main.height / main.width).roundToInt()))
            val mu = meanRgb(subS)
            val mm = meanRgb(mainS)
            subS.recycle(); mainS.recycle()
            gr = (mm[0] / max(mu[0], 8f)).coerceIn(0.8f, 1.25f)
            gg = (mm[1] / max(mu[1], 8f)).coerceIn(0.8f, 1.25f)
            gb = (mm[2] / max(mu[2], 8f)).coerceIn(0.8f, 1.25f)
        } catch (t: Throwable) {
            Log.w(TAG, "colour match skipped", t)
        }

        val out = Bitmap.createBitmap(wOut, hOut, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        paint.isFilterBitmap = true
        paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
            gr, 0f, 0f, 0f, 0f,
            0f, gg, 0f, 0f, 0f,
            0f, 0f, gb, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )))
        Canvas(out).drawBitmap(uw, null, RectF(0f, 0f, wOut.toFloat(), hOut.toFloat()), paint)

        // ---- paste the main image with a feathered edge
        val ms = shrink(main, mw2, mh2)
        try {
            val feather = max(8, (mw2 * 0.07f).roundToInt())
            val xa = max(0, px0)
            val xb = min(wOut, px0 + mw2)
            val ya = max(0, py0)
            val yb = min(hOut, py0 + mh2)
            if (xb > xa && yb > ya) {
                val cw = xb - xa
                val wxArr = FloatArray(cw)
                for (x in 0 until cw) {
                    val mx = xa + x - px0
                    wxArr[x] = smooth(min(mx, mw2 - 1 - mx).toFloat() / feather)
                }
                val rowsPer = 32
                val bufM = IntArray(cw * rowsPer)
                val bufO = IntArray(cw * rowsPer)
                var y = ya
                while (y < yb) {
                    val nr = min(rowsPer, yb - y)
                    ms.getPixels(bufM, 0, cw, xa - px0, y - py0, cw, nr)
                    out.getPixels(bufO, 0, cw, xa, y, cw, nr)
                    for (r in 0 until nr) {
                        val my = y + r - py0
                        val wy = smooth(min(my, mh2 - 1 - my).toFloat() / feather)
                        val base = r * cw
                        for (x in 0 until cw) {
                            val wgt = min(wxArr[x], wy)
                            val a = bufM[base + x]
                            if (wgt >= 0.999f) {
                                bufO[base + x] = a
                            } else {
                                val b = bufO[base + x]
                                val iw = 1f - wgt
                                val rr = (((a shr 16) and 255) * wgt + ((b shr 16) and 255) * iw).toInt()
                                val g2 = (((a shr 8) and 255) * wgt + ((b shr 8) and 255) * iw).toInt()
                                val bb = ((a and 255) * wgt + (b and 255) * iw).toInt()
                                bufO[base + x] = (0xFF shl 24) or (rr shl 16) or (g2 shl 8) or bb
                            }
                        }
                    }
                    out.setPixels(bufO, 0, cw, xa, y, cw, nr)
                    y += nr
                }
            }
        } finally {
            ms.recycle()
        }
        Log.i(TAG, "fused ${wOut}x$hOut main@${px0},${py0} ${mw2}x$mh2 gain=$gr/$gg/$gb")
        return out
    }
}

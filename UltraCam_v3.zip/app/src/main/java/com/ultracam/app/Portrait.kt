package com.ultracam.app

import android.graphics.Bitmap
import android.graphics.Matrix
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Portrait / bokeh: ML Kit selfie segmentation (people) + background blur. Falls back to a centre ellipse. */
object Portrait {

    private class Mask(val w: Int, val h: Int, val v: FloatArray)

    suspend fun apply(bmp: Bitmap, rotDeg: Int, strength: Float) {
        val w = bmp.width
        val h = bmp.height
        val sc = 640f / max(w, h)
        val sw = max(8, (w * sc).roundToInt())
        val sh = max(8, (h * sc).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val m = Matrix()
        m.postRotate(rotDeg.toFloat())
        val upright = Bitmap.createBitmap(scaled, 0, 0, sw, sh, m, true)
        val mask: Mask = try {
            segment(upright)
        } catch (t: Throwable) {
            ellipse(upright.width, upright.height)
        }
        composite(bmp, rotDeg, mask, strength)
    }

    /**
     * Software "aperture": blur the background only when a person is really found (no ellipse fallback).
     * Returns true if blur was applied. Person must cover between minCover and maxCover of the frame.
     */
    suspend fun applyIfPerson(bmp: Bitmap, rotDeg: Int, strength: Float, minCover: Float = 0.07f, maxCover: Float = 0.75f): Boolean {
        val w = bmp.width
        val h = bmp.height
        val sc = 640f / max(w, h)
        val sw = max(8, (w * sc).roundToInt())
        val sh = max(8, (h * sc).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val m = Matrix()
        m.postRotate(rotDeg.toFloat())
        val upright = Bitmap.createBitmap(scaled, 0, 0, sw, sh, m, true)
        val mask: Mask = try { segment(upright) } catch (t: Throwable) { return false }
        var on = 0
        for (v in mask.v) if (v > 0.5f) on++
        val cover = on.toFloat() / max(1, mask.v.size)
        if (cover < minCover || cover > maxCover) return false
        composite(bmp, rotDeg, mask, strength)
        return true
    }

    private suspend fun segment(img: Bitmap): Mask = suspendCancellableCoroutine { cont ->
        val opts = SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
        val seg = Segmentation.getClient(opts)
        seg.process(InputImage.fromBitmap(img, 0))
            .addOnSuccessListener { res ->
                try {
                    val buf = res.buffer
                    buf.rewind()
                    val mw = res.width
                    val mh = res.height
                    val arr = FloatArray(mw * mh)
                    for (i in arr.indices) arr[i] = buf.getFloat()
                    seg.close()
                    if (cont.isActive) cont.resume(Mask(mw, mh, arr))
                } catch (e: Exception) {
                    if (cont.isActive) cont.resumeWithException(e)
                }
            }
            .addOnFailureListener { e ->
                seg.close()
                if (cont.isActive) cont.resumeWithException(e)
            }
    }

    private fun ellipse(w: Int, h: Int): Mask {
        val a = FloatArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val u = (x + 0.5f) / w - 0.5f
                val v = (y + 0.5f) / h - 0.48f
                val d = sqrt((u / 0.32f) * (u / 0.32f) + (v / 0.42f) * (v / 0.42f))
                a[y * w + x] = (1.2f - d).coerceIn(0f, 1f)
            }
        }
        return Mask(w, h, a)
    }

    private fun sampleMask(mk: Mask, u: Float, v: Float): Float {
        val fx = (u * mk.w - 0.5f).coerceIn(0f, (mk.w - 1).toFloat())
        val fy = (v * mk.h - 0.5f).coerceIn(0f, (mk.h - 1).toFloat())
        val x0 = min(mk.w - 2, fx.toInt()).coerceAtLeast(0)
        val y0 = min(mk.h - 2, fy.toInt()).coerceAtLeast(0)
        val x1 = min(mk.w - 1, x0 + 1)
        val y1 = min(mk.h - 1, y0 + 1)
        val tx = fx - x0
        val ty = fy - y0
        val a = mk.v[y0 * mk.w + x0] * (1f - tx) + mk.v[y0 * mk.w + x1] * tx
        val b = mk.v[y1 * mk.w + x0] * (1f - tx) + mk.v[y1 * mk.w + x1] * tx
        return a * (1f - ty) + b * ty
    }

    private fun composite(bmp: Bitmap, rot: Int, mk: Mask, strength: Float) {
        val w = bmp.width
        val h = bmp.height
        val bw = max(8, w / 4)
        val bh = max(8, h / 4)
        val small = Bitmap.createScaledBitmap(bmp, bw, bh, true)
        val px = IntArray(bw * bh)
        small.getPixels(px, 0, bw, 0, 0, bw, bh)
        small.recycle()
        val n = bw * bh
        val r = FloatArray(n)
        val g = FloatArray(n)
        val b = FloatArray(n)
        val tmp = FloatArray(n)
        for (i in 0 until n) {
            r[i] = ((px[i] shr 16) and 255).toFloat()
            g[i] = ((px[i] shr 8) and 255).toFloat()
            b[i] = (px[i] and 255).toFloat()
        }
        val rad = (3 + strength * 14f).roundToInt()
        blurTwice(r, r, tmp, bw, bh, rad)
        blurTwice(g, g, tmp, bw, bh, rad)
        blurTwice(b, b, tmp, bw, bh, rad)
        val blur = IntArray(n)
        for (i in 0 until n) {
            blur[i] = (0xFF shl 24) or (r[i].toInt().coerceIn(0, 255) shl 16) or
                (g[i].toInt().coerceIn(0, 255) shl 8) or b[i].toInt().coerceIn(0, 255)
        }

        val rows = 64
        val buf = IntArray(rows * w)
        var y0 = 0
        while (y0 < h) {
            val nr = min(rows, h - y0)
            bmp.getPixels(buf, 0, w, 0, y0, w, nr)
            Par.rows(0, nr) { a, bEnd ->
                for (ry in a until bEnd) {
                    val y = y0 + ry
                    val fy = (y + 0.5f) / h
                    // blurred sample row (bilinear)
                    val sy = (y / 4f).coerceIn(0f, (bh - 1).toFloat())
                    val ya = min(bh - 2, sy.toInt()).coerceAtLeast(0)
                    val ty = sy - ya
                    for (x in 0 until w) {
                        val fx = (x + 0.5f) / w
                        val u: Float
                        val v: Float
                        when (rot) {
                            90 -> { u = 1f - fy; v = fx }
                            180 -> { u = 1f - fx; v = 1f - fy }
                            270 -> { u = fy; v = 1f - fx }
                            else -> { u = fx; v = fy }
                        }
                        val m = sampleMask(mk, u, v)
                        val t = ((m - 0.35f) / 0.4f).coerceIn(0f, 1f)
                        val al = t * t * (3f - 2f * t)
                        val i = ry * w + x
                        if (al >= 0.999f) continue
                        val sx = (x / 4f).coerceIn(0f, (bw - 1).toFloat())
                        val xa = min(bw - 2, sx.toInt()).coerceAtLeast(0)
                        val tx = sx - xa
                        val p00 = blur[ya * bw + xa]; val p10 = blur[ya * bw + xa + 1]
                        val p01 = blur[(ya + 1) * bw + xa]; val p11 = blur[(ya + 1) * bw + xa + 1]
                        val w00 = (1f - tx) * (1f - ty); val w10 = tx * (1f - ty)
                        val w01 = (1f - tx) * ty; val w11 = tx * ty
                        val br = ((p00 shr 16) and 255) * w00 + ((p10 shr 16) and 255) * w10 +
                            ((p01 shr 16) and 255) * w01 + ((p11 shr 16) and 255) * w11
                        val bg = ((p00 shr 8) and 255) * w00 + ((p10 shr 8) and 255) * w10 +
                            ((p01 shr 8) and 255) * w01 + ((p11 shr 8) and 255) * w11
                        val bb = (p00 and 255) * w00 + (p10 and 255) * w10 +
                            (p01 and 255) * w01 + (p11 and 255) * w11
                        val s = buf[i]
                        val outR = (((s shr 16) and 255) * al + br * (1f - al)).toInt()
                        val outG = (((s shr 8) and 255) * al + bg * (1f - al)).toInt()
                        val outB = ((s and 255) * al + bb * (1f - al)).toInt()
                        buf[i] = (0xFF shl 24) or (outR shl 16) or (outG shl 8) or outB
                    }
                }
            }
            bmp.setPixels(buf, 0, w, 0, y0, w, nr)
            y0 += nr
        }
    }
}

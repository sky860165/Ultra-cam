package com.ultracam.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Overlay: histogram, horizon level, focus peaking, zebra. Fed with a tiny preview bitmap. */
class AnalyzerView(ctx: Context) : View(ctx) {
    var level: Int = 0
        set(v) { field = v; invalidate() }
    var levelDeg: Float = 0f
        set(v) { field = v; if (level > 0) invalidate() }
    var aspect: Float = 0.75f

    var highPct = 0f
    var shadowPct = 0f
    var meanLuma = 128f

    private val hist = IntArray(256)
    private var gw = 0
    private var gh = 0
    private var peak = BooleanArray(0)
    private var zebra = BooleanArray(0)
    private val paint = Paint()
    private val line = Paint().apply { strokeWidth = 4f; isAntiAlias = true }
    private val d = resources.displayMetrics.density

    fun update(px: IntArray, w: Int, h: Int) {
        gw = w
        gh = h
        if (peak.size != w * h) { peak = BooleanArray(w * h); zebra = BooleanArray(w * h) }
        java.util.Arrays.fill(hist, 0)
        val lum = FloatArray(w * h)
        var sum = 0.0
        var hi = 0
        var lo = 0
        for (i in px.indices) {
            val p = px[i]
            val l = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
            lum[i] = l
            val li = min(255, max(0, l.toInt()))
            hist[li]++
            sum += l
            if (li >= 250) hi++
            if (li <= 12) lo++
            zebra[i] = li >= 242
        }
        val n = px.size.toFloat()
        meanLuma = (sum / n).toFloat()
        highPct = hi * 100f / n
        shadowPct = lo * 100f / n
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                if (x >= w - 1 || y >= h - 1) { peak[i] = false; continue }
                val g = abs(lum[i + 1] - lum[i]) + abs(lum[i + w] - lum[i])
                peak[i] = g > 34f && lum[i] in 20f..240f
            }
        }
        if (level > 0) invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (level <= 0) return
        val vw = width.toFloat()
        val vh = height.toFloat()
        // content rect (aspect = w/h)
        var cw = vw
        var ch = vw / aspect
        if (ch > vh) { ch = vh; cw = vh * aspect }
        val cl = (vw - cw) / 2f
        val ct = (vh - ch) / 2f

        if (level >= 3 && gw > 0) {
            val cwid = cw / gw
            val chei = ch / gh
            paint.color = 0x99FFFFFF.toInt()
            for (y in 0 until gh) for (x in 0 until gw) {
                if (zebra[y * gw + x] && (x + y) % 2 == 0) {
                    canvas.drawRect(cl + x * cwid, ct + y * chei, cl + (x + 1) * cwid, ct + (y + 1) * chei, paint)
                }
            }
        }
        if (level >= 2 && gw > 0) {
            val cwid = cw / gw
            val chei = ch / gh
            paint.color = 0xCCFF2D2D.toInt()
            for (y in 0 until gh) for (x in 0 until gw) {
                if (peak[y * gw + x]) {
                    canvas.drawRect(cl + x * cwid, ct + y * chei, cl + (x + 1) * cwid, ct + (y + 1) * chei, paint)
                }
            }
        }
        // histogram
        val hw = 130f * d
        val hh = 56f * d
        val hx = 10f * d
        val hy = vh - hh - 10f * d
        paint.color = 0x66000000
        canvas.drawRect(hx, hy, hx + hw, hy + hh, paint)
        var mx = 1
        for (i in 1..254) mx = max(mx, hist[i])
        paint.color = Color.WHITE
        for (i in 0 until 256) {
            val v = sqrt(min(hist[i], mx).toFloat() / mx)
            val x = hx + i * hw / 256f
            canvas.drawRect(x, hy + hh - v * hh, x + hw / 256f + 0.5f, hy + hh, paint)
        }
        // horizon level
        val cx = vw / 2f
        val cy = vh / 2f
        val half = vw * 0.22f
        line.color = if (abs(levelDeg) < 1f) Color.GREEN else Color.YELLOW
        canvas.save()
        canvas.rotate(-levelDeg, cx, cy)
        canvas.drawLine(cx - half, cy, cx - half * 0.3f, cy, line)
        canvas.drawLine(cx + half * 0.3f, cy, cx + half, cy, line)
        canvas.restore()
    }
}

package com.ultracam.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

private class SquareImageView(ctx: Context) : ImageView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
    }
}

class GalleryActivity : AppCompatActivity() {

    private class Item(val id: Long, val name: String)

    private val items = ArrayList<Item>()
    private val cache = object : LruCache<Long, Bitmap>(90) {}
    private val io = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadItems()
        val grid = GridView(this)
        grid.numColumns = 3
        grid.setBackgroundColor(Color.BLACK)
        grid.horizontalSpacing = 3
        grid.verticalSpacing = 3
        grid.adapter = object : BaseAdapter() {
            override fun getCount(): Int = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int): Long = items[position].id
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val iv = (convertView as? ImageView) ?: SquareImageView(this@GalleryActivity).also {
                    it.scaleType = ImageView.ScaleType.CENTER_CROP
                    it.setBackgroundColor(0xFF222222.toInt())
                }
                val id = items[position].id
                iv.tag = id
                val c = cache.get(id)
                if (c != null) {
                    iv.setImageBitmap(c)
                } else {
                    iv.setImageDrawable(null)
                    io.execute {
                        val b = loadThumb(id)
                        if (b != null) {
                            cache.put(id, b)
                            ui.post { if (iv.tag == id) iv.setImageBitmap(b) }
                        }
                    }
                }
                return iv
            }
        }
        grid.setOnItemClickListener { _, _, pos, _ ->
            val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, items[pos].id)
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "image/*")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(this, "Viewer nahi mila", Toast.LENGTH_SHORT).show()
            }
        }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            val origId = findOriginal(items[pos].name)
            if (origId == null) {
                Toast.makeText(this, "Original nahi hai (Settings me 'Original JPEG save' ON karo)", Toast.LENGTH_LONG).show()
            } else {
                val i = Intent(this, CompareActivity::class.java)
                i.putExtra("a", items[pos].id)
                i.putExtra("b", origId)
                startActivity(i)
            }
            true
        }
        setContentView(grid)
        Toast.makeText(this, "Long-press = Before/After compare", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }

    private fun loadItems() {
        items.clear()
        val c = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME),
            "${MediaStore.Images.Media.DISPLAY_NAME} LIKE ? OR ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?",
            arrayOf("ULTRACAM_%", "LAPSE_%"),
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        ) ?: return
        c.use {
            while (it.moveToNext()) {
                val name = it.getString(1) ?: continue
                if (name.contains("_ORIG")) continue
                items.add(Item(it.getLong(0), name))
            }
        }
    }

    private fun findOriginal(name: String): Long? {
        val orig = name.removeSuffix(".jpg") + "_ORIG.jpg"
        val c = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID),
            "${MediaStore.Images.Media.DISPLAY_NAME} = ?",
            arrayOf(orig), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getLong(0) else null }
    }

    @Suppress("DEPRECATION")
    private fun loadThumb(id: Long): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) {
            val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
            contentResolver.loadThumbnail(uri, Size(256, 256), null)
        } else {
            MediaStore.Images.Thumbnails.getThumbnail(
                contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null
            )
        }
    } catch (e: Exception) {
        null
    }
}

private class CompareView(ctx: Context, val a: Bitmap, val b: Bitmap) : View(ctx) {
    private var split = 0.5f
    private val dest = RectF()
    private val paint = Paint().apply { isFilterBitmap = true }
    private val line = Paint().apply { color = Color.WHITE; strokeWidth = 5f }
    private val label = Paint().apply { color = Color.WHITE; textSize = 42f; isAntiAlias = true; setShadowLayer(6f, 0f, 0f, Color.BLACK) }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val vw = width.toFloat()
        val vh = height.toFloat()
        val ar = a.width.toFloat() / a.height
        var dw = vw
        var dh = vw / ar
        if (dh > vh) { dh = vh; dw = vh * ar }
        dest.set((vw - dw) / 2f, (vh - dh) / 2f, (vw + dw) / 2f, (vh + dh) / 2f)
        canvas.drawBitmap(a, null, dest, paint)
        val sx = dest.left + dest.width() * split
        canvas.save()
        canvas.clipRect(dest.left, dest.top, sx, dest.bottom)
        canvas.drawBitmap(b, null, dest, paint)
        canvas.restore()
        canvas.drawLine(sx, dest.top, sx, dest.bottom, line)
        canvas.drawText("ORIGINAL", dest.left + 20f, dest.top + 60f, label)
        canvas.drawText("ULTRACAM", dest.right - 260f, dest.top + 60f, label)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (dest.width() > 0f) {
            split = ((e.x - dest.left) / dest.width()).coerceIn(0f, 1f)
            invalidate()
        }
        return true
    }
}

class CompareActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ba = load(intent.getLongExtra("a", -1L))
        val bb = load(intent.getLongExtra("b", -1L))
        if (ba == null || bb == null) {
            Toast.makeText(this, "Images load nahi hui", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContentView(CompareView(this, ba, bb))
    }

    private fun load(id: Long): Bitmap? {
        if (id < 0) return null
        return try {
            val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var ss = 1
            while (max(bounds.outWidth, bounds.outHeight) / ss > 2400) ss *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = ss
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
            var deg = 0
            contentResolver.openInputStream(uri)?.use {
                val ori = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                deg = when (ori) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            }
            if (deg == 0) bmp else {
                val m = Matrix()
                m.postRotate(deg.toFloat())
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
        } catch (e: Exception) {
            null
        }
    }
}

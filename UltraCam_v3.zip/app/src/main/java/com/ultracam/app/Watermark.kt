package com.ultracam.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

object Watermark {
    /** Draws text at upright bottom-right. rotDeg = clockwise rotation needed to make the bitmap upright. */
    fun draw(bmp: Bitmap, rotDeg: Int, text: String) {
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val c = Canvas(bmp)
        val uw: Float
        val uh: Float
        when (rotDeg) {
            90 -> { uw = h; uh = w; c.translate(0f, h); c.rotate(-90f) }
            180 -> { uw = w; uh = h; c.translate(w, h); c.rotate(180f) }
            270 -> { uw = h; uh = w; c.translate(w, 0f); c.rotate(90f) }
            else -> { uw = w; uh = h }
        }
        val p = Paint()
        p.isAntiAlias = true
        p.color = Color.WHITE
        p.textSize = uw / 55f
        p.textAlign = Paint.Align.RIGHT
        p.setShadowLayer(p.textSize / 6f, 0f, 0f, Color.BLACK)
        val pad = uw / 60f
        c.drawText(text, uw - pad, uh - pad, p)
    }
}

package com.ultracam.app

import android.graphics.Bitmap
import android.util.Log
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Final-photo noise cleanup (runs after the merge, before colour fix / beauty):
 *  - CHROMA: the coloured speckle ("dot dot dot" when zoomed) is replaced by a wide low-res chroma average, but only where
 *    the difference is small (= noise). Big differences (real colour edges: lips, clothes) are kept, so no colour bleeding.
 *  - LUMA: a 5x5 average blended in only on flat-ish areas (difference below the measured noise level), so edges/hair/beard stay.
 * Noise level is measured from the photo itself (Laplacian median), so clean bright photos are barely touched.
 * Works in strips: no full-size float arrays, safe for 12 MP+ photos.
 */
object Clean {
    private const val TAG = "UltraCamClean"
    private const val ROWS = 64

    fun apply(bmp: Bitmap, chromaAmt: Float, lumaAmt: Float): Boolean {
        val sc = chromaAmt.coerceIn(0f, 1f)
        val sl = lumaAmt.coerceIn(0f, 1f)
        if ((sc < 0.02f && sl < 0.02f) || !bmp.isMutable) return false
        val w = bmp.width
        val h = bmp.height
        if (w < 32 || h < 32) return false
        val lw = w / 2
        val lh = h / 2
        val cbG = FloatArray(lw * lh)
        val crG = FloatArray(lw * lh)
        val hist = IntArray(256)
        val buf = IntArray(w * (ROWS + 4))

        // ---------- pass 1: low-res chroma grid + noise estimate
        var y0 = 0
        while (y0 < h) {
            val n = min(ROWS, h - y0)
            bmp.getPixels(buf, 0, w, 0, y0, w, n)
            for (ry in 0 until n) {
                val y = y0 + ry
                val ly = y shr 1
                val rowOff = ry * w
                for (x in 0 until w) {
                    val p = buf[rowOff + x]
                    val r = ((p shr 16) and 255).toFloat()
                    val g = ((p shr 8) and 255).toFloat()
                    val b = (p and 255).toFloat()
                    val yy = 0.299f * r + 0.587f * g + 0.114f * b
                    val lx = x shr 1
                    if (lx < lw && ly < lh) {
                        val li = ly * lw + lx
                        cbG[li] += (b - yy) * 0.25f
                        crG[li] += (r - yy) * 0.25f
                    }
                    if (ry in 1 until n - 1 && x in 1 until w - 1 && ry % 3 == 0 && x % 3 == 0) {
                        val yl = lumaOf(buf[rowOff + x - 1]); val yr = lumaOf(buf[rowOff + x + 1])
                        val yu = lumaOf(buf[rowOff - w + x]); val yd = lumaOf(buf[rowOff + w + x])
                        val lap = abs(4f * yy - yl - yr - yu - yd)
                        hist[min(255, lap.toInt())]++
                    }
                }
            }
            y0 += n
        }
        var total = 0
        for (c in hist) total += c
        var med = 0
        if (total > 0) {
            var acc = 0
            for (i in 0..255) { acc += hist[i]; if (acc >= total / 2) { med = i; break } }
        }
        val sigma = (med / 0.6745f / 4.47f).coerceIn(0.5f, 20f)
        boxBlur(cbG, lw, lh, 3); boxBlur(cbG, lw, lh, 3)
        boxBlur(crG, lw, lh, 3); boxBlur(crG, lw, lh, 3)

        val tc = (sigma * (3f + 5f * sc)).coerceIn(6f, 48f)
        val tl = (sigma * (1.2f + 2.2f * sl)).coerceIn(3f, 22f)
        val cScale = if (sc < 0.7f) sc / 0.7f else 1f
        val lScale = if (sl < 0.4f) sl / 0.4f else 1f
        Log.i(TAG, "sigma=$sigma Tc=$tc Tl=$tl chroma=$sc luma=$sl")

        // ---------- pass 2: apply, strip by strip with 2 rows halo for the luma 5x5
        val tail = IntArray(w * 2)      // ORIGINAL last 2 rows of the previous strip
        var haveTail = false
        val hAvg = FloatArray(w * (ROWS + 4))
        val yRow = FloatArray(w)
        y0 = 0
        while (y0 < h) {
            val n = min(ROWS, h - y0)
            // buffer layout: 2 halo rows on top, n core rows, 2 halo rows at the bottom
            val top = 2
            val bot = min(2, h - (y0 + n))
            if (haveTail && y0 >= 2) {
                System.arraycopy(tail, 0, buf, 0, w * 2)
            } else {
                // no previous strip: the top halo is not needed (clamped below), keep zeros
            }
            bmp.getPixels(buf, w * top, w, 0, y0, w, n)
            if (bot > 0) bmp.getPixels(buf, w * (top + n), w, 0, y0 + n, w, bot)
            // save ORIGINAL last 2 core rows for the next strip
            if (n >= 2) { System.arraycopy(buf, w * (top + n - 2), tail, 0, w * 2); haveTail = true }

            val firstValid = if (y0 >= 2) 0 else top - y0           // first usable buffer row
            val lastValid = top + n - 1 + bot                       // last usable buffer row
            // horizontal 5-average of luma for every usable buffer row
            for (br in firstValid..lastValid) {
                val off = br * w
                for (x in 0 until w) yRow[x] = lumaOf(buf[off + x])
                var run = 0f
                // sliding window of width 5 with edge clamp
                var cnt = 0
                for (x in 0 until min(3, w)) { run += yRow[x]; cnt++ }
                for (x in 0 until w) {
                    hAvg[off + x] = run / cnt
                    val addX = x + 3
                    val remX = x - 2
                    if (addX < w) { run += yRow[addX]; cnt++ }
                    if (remX >= 0) { run -= yRow[remX]; cnt-- }
                }
            }
            for (ry in 0 until n) {
                val br = top + ry
                val y = y0 + ry
                val fy = (y + 0.5f) / 2f - 0.5f
                val iy = fy.toInt().coerceIn(0, lh - 1)
                val iy1 = min(lh - 1, iy + 1)
                val ty = (fy - iy).coerceIn(0f, 1f)
                val v0 = max(firstValid, br - 2)
                val v1 = min(lastValid, br + 2)
                val off = br * w
                for (x in 0 until w) {
                    val p = buf[off + x]
                    val r = ((p shr 16) and 255).toFloat()
                    val g = ((p shr 8) and 255).toFloat()
                    val b = (p and 255).toFloat()
                    val yy = 0.299f * r + 0.587f * g + 0.114f * b
                    val cb = b - yy
                    val cr = r - yy
                    // chroma: bilinear from the smoothed low-res grid
                    var cb2 = cb
                    var cr2 = cr
                    if (sc >= 0.02f) {
                        val fx = (x + 0.5f) / 2f - 0.5f
                        val ix = fx.toInt().coerceIn(0, lw - 1)
                        val ix1 = min(lw - 1, ix + 1)
                        val tx = (fx - ix).coerceIn(0f, 1f)
                        val a0 = iy * lw
                        val a1 = iy1 * lw
                        val cbs = (cbG[a0 + ix] * (1f - tx) + cbG[a0 + ix1] * tx) * (1f - ty) +
                            (cbG[a1 + ix] * (1f - tx) + cbG[a1 + ix1] * tx) * ty
                        val crs = (crG[a0 + ix] * (1f - tx) + crG[a0 + ix1] * tx) * (1f - ty) +
                            (crG[a1 + ix] * (1f - tx) + crG[a1 + ix1] * tx) * ty
                        val d = max(abs(cb - cbs), abs(cr - crs))
                        val wc = (1f - smooth(0.5f * tc, 1.5f * tc, d)) * cScale
                        cb2 = cb + (cbs - cb) * wc
                        cr2 = cr + (crs - cr) * wc
                    }
                    // luma: 5x5 average on flat areas only
                    var y2 = yy
                    if (sl >= 0.02f) {
                        var s = 0f
                        for (vr in v0..v1) s += hAvg[vr * w + x]
                        val ys = s / (v1 - v0 + 1)
                        val wl = (1f - smooth(0.5f * tl, 1.5f * tl, abs(yy - ys))) * lScale
                        y2 = yy + (ys - yy) * wl * 0.85f
                    }
                    val r2 = (y2 + cr2).coerceIn(0f, 255f)
                    val b2 = (y2 + cb2).coerceIn(0f, 255f)
                    val g2 = ((y2 - 0.299f * r2 - 0.114f * b2) / 0.587f).coerceIn(0f, 255f)
                    buf[off + x] = (p and 0xFF000000.toInt()) or
                        ((r2 + 0.5f).toInt() shl 16) or ((g2 + 0.5f).toInt() shl 8) or (b2 + 0.5f).toInt()
                }
            }
            bmp.setPixels(buf, w * top, w, 0, y0, w, n)
            y0 += n
        }
        return true
    }

    private fun lumaOf(p: Int): Float =
        0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** separable box blur with edge clamp, O(n) sliding sums; in place */
    private fun boxBlur(a: FloatArray, w: Int, h: Int, r: Int) {
        val tmp = FloatArray(max(w, h))
        // horizontal
        for (y in 0 until h) {
            val o = y * w
            var run = 0f
            var cnt = 0
            for (x in 0..min(r, w - 1)) { run += a[o + x]; cnt++ }
            for (x in 0 until w) {
                tmp[x] = run / cnt
                val addX = x + r + 1
                val remX = x - r
                if (addX < w) { run += a[o + addX]; cnt++ }
                if (remX >= 0) { run -= a[o + remX]; cnt-- }
            }
            for (x in 0 until w) a[o + x] = tmp[x]
        }
        // vertical
        for (x in 0 until w) {
            var run = 0f
            var cnt = 0
            for (y in 0..min(r, h - 1)) { run += a[y * w + x]; cnt++ }
            for (y in 0 until h) {
                tmp[y] = run / cnt
                val addY = y + r + 1
                val remY = y - r
                if (addY < h) { run += a[addY * w + x]; cnt++ }
                if (remY >= 0) { run -= a[remY * w + x]; cnt-- }
            }
            for (y in 0 until h) a[y * w + x] = tmp[y]
        }
    }
}

package com.ultracam.app

import android.util.Log

/** JNI bridge to libultracam_native.so (C++ merge / denoise / tone-map engine). If the library can't load, `ok` is false and the Kotlin engine is used. */
object NativeEngine {
    @JvmField val ok: Boolean = try {
        System.loadLibrary("ultracam_native"); true
    } catch (t: Throwable) {
        Log.w("UltraCam", "native engine unavailable, using Kotlin fallback", t); false
    }

    external fun create(ci: IntArray, cf: FloatArray, base: FloatArray, look: FloatArray, sigma: FloatArray, fw: FloatArray): Long
    external fun destroy(h: Long)
    external fun sample(h: Long, slot: Int, src: IntArray, rows: Int, yTop: Int, dx: Float, dy: Float, r0: Int, nr: Int)
    external fun merge(h: Long, kind: Int, nr: Int, arg: Int)
    external fun post(h: Long, r0: Int, nr: Int)
    external fun finish(h: Long, r0: Int, y0: Int, y1: Int, out: IntArray)
    external fun search(a: FloatArray, b: FloatArray, w: Int, h: Int, win: IntArray, cx: Int, cy: Int, rad: Int, step: Int): IntArray
}

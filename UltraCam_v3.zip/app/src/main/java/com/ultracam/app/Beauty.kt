package com.ultracam.app

import android.graphics.Bitmap
import android.graphics.PointF
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Face beauty (front + back camera, separate settings). Every effect has its own ON/OFF + amount.
 * Pipeline per face: ML Kit face + landmarks -> crop (upright) -> geometry warps (slim / eye enlarge) -> skin-aware effects
 * (edge-preserving smoothing, tone, blemish, glow, eyes, teeth, lips) -> write back.
 * "AI Auto-Beauty" measures each face (skin roughness, blotchiness, brightness) and scales the effects so skin stays natural.
 */
object Beauty {
    private const val TAG = "UltraCamBeauty"

    class Feat(val id: String, val label: String, val defOn: Boolean, val defAmt: Int)

    val FEATURES: List<Feat> = listOf(
        Feat("smooth", "Skin smoothing", true, 45),
        Feat("tone", "Even skin tone (redness / patches)", true, 25),
        Feat("blemish", "Blemish / spot remover", true, 40),
        Feat("glow", "Skin brighten + glow", true, 15),
        Feat("eyes", "Eyes bright + dark circles", true, 30),
        Feat("teeth", "Teeth whitening", true, 30),
        Feat("lips", "Lip colour", false, 20),
        Feat("slim", "Face slim", false, 25),
        Feat("eyeBig", "Eye enlarge", false, 20)
    )

    /** amt: feature id -> 0..1 (0 = off). */
    class Cfg(val ai: Boolean, val amt: Map<String, Float>) {
        fun a(id: String): Float = amt[id] ?: 0f
        val any: Boolean get() = amt.values.any { it > 0.01f }
    }

    /** Settings snapshot for one camera. Returns null when beauty is OFF for that camera. */
    fun cfgFrom(prefs: Prefs, front: Boolean): Cfg? {
        if (!prefs.beautyOn(front)) return null
        val m = HashMap<String, Float>()
        for (f in FEATURES) m[f.id] = if (prefs.beautyFeatOn(front, f.id, f.defOn)) prefs.beautyAmt(front, f.id, f.defAmt) / 100f else 0f
        val c = Cfg(prefs.beautyAi(front), m)
        return if (c.any) c else null
    }

    // ------------------------------------------------------------------ geometry
    private class Geo(
        val l: Float, val t: Float, val r: Float, val b: Float,
        val eL: PointF?, val eR: PointF?, val mL: PointF?, val mR: PointF?, val mB: PointF?, val nose: PointF?
    ) {
        val w: Float get() = r - l
        val h: Float get() = b - t
        val cx: Float get() = (l + r) * 0.5f

        fun shift(dx: Float, dy: Float, s: Float): Geo {
            fun p(q: PointF?): PointF? = if (q == null) null else PointF((q.x + dx) * s, (q.y + dy) * s)
            return Geo((l + dx) * s, (t + dy) * s, (r + dx) * s, (b + dy) * s, p(eL), p(eR), p(mL), p(mR), p(mB), p(nose))
        }
    }

    private fun pt(f: com.google.mlkit.vision.face.Face, type: Int, k: Float, ox: Float, oy: Float): PointF? {
        val p = f.getLandmark(type)?.position ?: return null
        return PointF(p.x * k + ox, p.y * k + oy)
    }

    private suspend fun detect(img: Bitmap): List<com.google.mlkit.vision.face.Face> = suspendCancellableCoroutine { cont ->
        val opts = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .setMinFaceSize(0.06f)
            .build()
        val det = FaceDetection.getClient(opts)
        det.process(InputImage.fromBitmap(img, 0))
            .addOnSuccessListener { res ->
                det.close()
                if (cont.isActive) cont.resume(res)
            }
            .addOnFailureListener { e ->
                det.close()
                if (cont.isActive) cont.resumeWithException(e)
            }
    }

    // ------------------------------------------------------------------ entry
    /** rotDeg = clockwise rotation that makes the bitmap upright (same meaning as in Portrait). Returns the number of faces processed. */
    suspend fun apply(bmp: Bitmap, rotDeg: Int, cfg: Cfg): Int {
        if (!cfg.any) return 0
        val rot = ((rotDeg % 360) + 360) % 360
        val bw = bmp.width
        val bh = bmp.height
        val uw = if (rot == 90 || rot == 270) bh else bw
        val uh = if (rot == 90 || rot == 270) bw else bh

        // upright detection image (<= 960 px)
        val sc = min(1f, 960f / max(bw, bh))
        val sw = max(8, (bw * sc).roundToInt())
        val sh = max(8, (bh * sc).roundToInt())
        val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val upright = if (rot == 0) scaled else {
            val m = android.graphics.Matrix()
            m.postRotate(rot.toFloat())
            val u = Bitmap.createBitmap(scaled, 0, 0, sw, sh, m, true)
            if (u !== scaled) scaled.recycle()
            u
        }
        val faces = try { detect(upright) } catch (t: Throwable) { Log.w(TAG, "face detect failed", t); emptyList() }
        val k = uw.toFloat() / upright.width
        upright.recycle()
        if (faces.isEmpty()) {
            Log.i(TAG, "no face found - beauty skipped")
            return 0
        }

        val sorted = faces.sortedByDescending { it.boundingBox.width() * it.boundingBox.height() }.take(6)
        var done = 0
        for (f in sorted) {
            val bb = f.boundingBox
            val fwFull = bb.width() * k
            if (fwFull < 70f) continue                       // too small to beautify properly
            val ux0 = (bb.left * k)
            val uy0 = (bb.top * k)
            val geoU = Geo(
                bb.left * k, bb.top * k, bb.right * k, bb.bottom * k,
                pt(f, FaceLandmark.LEFT_EYE, k, 0f, 0f), pt(f, FaceLandmark.RIGHT_EYE, k, 0f, 0f),
                pt(f, FaceLandmark.MOUTH_LEFT, k, 0f, 0f), pt(f, FaceLandmark.MOUTH_RIGHT, k, 0f, 0f),
                pt(f, FaceLandmark.MOUTH_BOTTOM, k, 0f, 0f), pt(f, FaceLandmark.NOSE_BASE, k, 0f, 0f)
            )
            if (ux0.isNaN() || uy0.isNaN()) continue
            try {
                processFace(bmp, rot, bw, bh, uw, uh, geoU, cfg)
                done++
            } catch (t: Throwable) {
                Log.w(TAG, "face beautify failed", t)
            }
        }
        Log.i(TAG, "beauty applied on $done face(s)")
        return done
    }

    private fun processFace(bmp: Bitmap, rot: Int, bw: Int, bh: Int, uw: Int, uh: Int, g: Geo, cfg: Cfg) {
        // ROI in upright full-size coordinates
        val u0 = max(0f, g.l - 0.45f * g.w)
        val u1 = min(uw.toFloat(), g.r + 0.45f * g.w)
        val v0 = max(0f, g.t - 0.55f * g.h)
        val v1 = min(uh.toFloat(), g.b + 0.45f * g.h)
        // matching rectangle in the (unrotated) bitmap
        val fx0: Float
        val fy0: Float
        val fx1: Float
        val fy1: Float
        when (rot) {
            90 -> { fx0 = v0; fx1 = v1; fy0 = bh - u1; fy1 = bh - u0 }
            180 -> { fx0 = bw - u1; fx1 = bw - u0; fy0 = bh - v1; fy1 = bh - v0 }
            270 -> { fx0 = bw - v1; fx1 = bw - v0; fy0 = u0; fy1 = u1 }
            else -> { fx0 = u0; fx1 = u1; fy0 = v0; fy1 = v1 }
        }
        val x0 = max(0, floor(fx0).toInt())
        val y0 = max(0, floor(fy0).toInt())
        val x1 = min(bw, (fx1 + 0.999f).toInt())
        val y1 = min(bh, (fy1 + 0.999f).toInt())
        val cw = x1 - x0
        val ch = y1 - y0
        if (cw < 64 || ch < 64) return
        // upright origin of the rotated crop
        val ox: Int
        val oy: Int
        when (rot) {
            90 -> { ox = bh - y1; oy = x0 }
            180 -> { ox = bw - x1; oy = bh - y1 }
            270 -> { ox = y0; oy = bw - x1 }
            else -> { ox = x0; oy = y0 }
        }
        val src = IntArray(cw * ch)
        bmp.getPixels(src, 0, cw, x0, y0, cw, ch)
        val roi = if (rot == 0) src else rotateInts(src, cw, ch, rot)
        val rw = if (rot == 90 || rot == 270) ch else cw
        val rh = if (rot == 90 || rot == 270) cw else ch
        val geo = g.shift(-ox.toFloat(), -oy.toFloat(), 1f)

        beautifyRoi(roi, rw, rh, geo, cfg)

        val back = if (rot == 0) roi else rotateInts(roi, rw, rh, (360 - rot) % 360)
        bmp.setPixels(back, 0, cw, x0, y0, cw, ch)
    }

    /** clockwise rotation by 90 / 180 / 270 degrees */
    private fun rotateInts(s: IntArray, w: Int, h: Int, rot: Int): IntArray {
        val d = IntArray(s.size)
        when (rot) {
            90 -> for (y in 0 until h) for (x in 0 until w) d[x * h + (h - 1 - y)] = s[y * w + x]
            180 -> for (y in 0 until h) for (x in 0 until w) d[(h - 1 - y) * w + (w - 1 - x)] = s[y * w + x]
            270 -> for (y in 0 until h) for (x in 0 until w) d[(w - 1 - x) * h + y] = s[y * w + x]
            else -> System.arraycopy(s, 0, d, 0, s.size)
        }
        return d
    }

    // ------------------------------------------------------------------ ROI processing
    private fun beautifyRoi(px: IntArray, w: Int, h: Int, g: Geo, cfg: Cfg) {
        if (cfg.a("slim") > 0.01f || cfg.a("eyeBig") > 0.01f) warp(px, w, h, g, cfg.a("slim"), cfg.a("eyeBig"))

        val skinWork = cfg.a("smooth") > 0.01f || cfg.a("tone") > 0.01f || cfg.a("blemish") > 0.01f || cfg.a("glow") > 0.01f ||
            cfg.a("eyes") > 0.01f || cfg.a("teeth") > 0.01f || cfg.a("lips") > 0.01f
        if (!skinWork) return

        val ws = min(1f, 1536f / max(w, h))
        if (ws >= 0.999f) {
            val res = effects(px, w, h, g, cfg)
            System.arraycopy(res, 0, px, 0, px.size)
            return
        }
        // large ROI: run the effects at reduced size and add the (smooth) difference back to the full-resolution pixels
        val ww = max(16, (w * ws).roundToInt())
        val wh = max(16, (h * ws).roundToInt())
        val small = resize(px, w, h, ww, wh)
        val res = effects(small, ww, wh, g.shift(0f, 0f, ww.toFloat() / w), cfg)
        val n = ww * wh
        val dR = FloatArray(n)
        val dG = FloatArray(n)
        val dB = FloatArray(n)
        for (i in 0 until n) {
            val a = small[i]
            val b = res[i]
            dR[i] = (((b shr 16) and 255) - ((a shr 16) and 255)).toFloat()
            dG[i] = (((b shr 8) and 255) - ((a shr 8) and 255)).toFloat()
            dB[i] = ((b and 255) - (a and 255)).toFloat()
        }
        val sx = ww.toFloat() / w
        val sy = wh.toFloat() / h
        Par.rows(0, h) { ya, yb ->
            for (y in ya until yb) {
                val fy = ((y + 0.5f) * sy - 0.5f).coerceIn(0f, (wh - 1).toFloat())
                val y0 = min(wh - 2, fy.toInt()).coerceAtLeast(0)
                val ty = fy - y0
                for (x in 0 until w) {
                    val fx = ((x + 0.5f) * sx - 0.5f).coerceIn(0f, (ww - 1).toFloat())
                    val x0 = min(ww - 2, fx.toInt()).coerceAtLeast(0)
                    val tx = fx - x0
                    val i00 = y0 * ww + x0
                    val i10 = i00 + 1
                    val i01 = i00 + ww
                    val i11 = i01 + 1
                    val w00 = (1f - tx) * (1f - ty)
                    val w10 = tx * (1f - ty)
                    val w01 = (1f - tx) * ty
                    val w11 = tx * ty
                    val ar = dR[i00] * w00 + dR[i10] * w10 + dR[i01] * w01 + dR[i11] * w11
                    val ag = dG[i00] * w00 + dG[i10] * w10 + dG[i01] * w01 + dG[i11] * w11
                    val ab = dB[i00] * w00 + dB[i10] * w10 + dB[i01] * w01 + dB[i11] * w11
                    val p = px[y * w + x]
                    val r = (((p shr 16) and 255) + ar).roundToInt().coerceIn(0, 255)
                    val gg = (((p shr 8) and 255) + ag).roundToInt().coerceIn(0, 255)
                    val b = ((p and 255) + ab).roundToInt().coerceIn(0, 255)
                    px[y * w + x] = (0xFF shl 24) or (r shl 16) or (gg shl 8) or b
                }
            }
        }
    }

    private fun resize(px: IntArray, w: Int, h: Int, nw: Int, nh: Int): IntArray {
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bm.setPixels(px, 0, w, 0, 0, w, h)
        val sc = Bitmap.createScaledBitmap(bm, nw, nh, true)
        val out = IntArray(nw * nh)
        sc.getPixels(out, 0, nw, 0, 0, nw, nh)
        if (sc !== bm) sc.recycle()
        bm.recycle()
        return out
    }

    // ------------------------------------------------------------------ warps (full-res, inverse mapping)
    private fun warp(px: IntArray, w: Int, h: Int, g: Geo, slim: Float, eyeBig: Float) {
        val src = px.copyOf()
        val fw = g.w
        val fh = g.h
        val eyes = ArrayList<PointF>()
        g.eL?.let { eyes.add(it) }
        g.eR?.let { eyes.add(it) }
        val er = 0.2f * fw
        val ek = eyeBig * 0.32f
        val slimD = slim * 0.065f * fw
        val xa = max(0, (g.l - 0.35f * fw).toInt())
        val xb = min(w - 1, (g.r + 0.35f * fw).toInt())
        val ya = max(0, (g.t - 0.1f * fh).toInt())
        val yb = min(h - 1, (g.b + 0.25f * fh).toInt())
        val cx = g.cx
        Par.rows(ya, yb + 1) { r0, r1 ->
            for (y in r0 until r1) {
                for (x in xa..xb) {
                    var sx = x.toFloat()
                    var sy = y.toFloat()
                    if (ek > 0.001f) {
                        for (e in eyes) {
                            val dx = x - e.x
                            val dy = y - e.y
                            val q = (dx * dx + dy * dy) / (er * er)
                            if (q < 1f) {
                                val f = 1f - ek * (1f - q) * (1f - q)
                                sx += dx * (f - 1f)
                                sy += dy * (f - 1f)
                            }
                        }
                    }
                    if (slimD > 0.01f) {
                        val ys = (y - g.t) / fh
                        val wy = exp(-((ys - 0.72f) * (ys - 0.72f)) / (2f * 0.17f * 0.17f))
                        val ax = abs(x - cx) / (fw * 0.5f)
                        val wx = smooth(0.55f, 1.0f, ax) * (1f - smooth(1.0f, 1.45f, ax))
                        val dsp = slimD * wy * wx
                        if (dsp > 0.01f) sx += if (x < cx) -dsp else dsp
                    }
                    if (sx == x.toFloat() && sy == y.toFloat()) continue
                    px[y * w + x] = bilinear(src, w, h, sx, sy)
                }
            }
        }
    }

    private fun bilinear(s: IntArray, w: Int, h: Int, x: Float, y: Float): Int {
        val fx = x.coerceIn(0f, (w - 1).toFloat())
        val fy = y.coerceIn(0f, (h - 1).toFloat())
        val x0 = min(w - 2, fx.toInt()).coerceAtLeast(0)
        val y0 = min(h - 2, fy.toInt()).coerceAtLeast(0)
        val tx = fx - x0
        val ty = fy - y0
        val a = s[y0 * w + x0]
        val b = s[y0 * w + x0 + 1]
        val c = s[(y0 + 1) * w + x0]
        val d = s[(y0 + 1) * w + x0 + 1]
        val w00 = (1f - tx) * (1f - ty)
        val w10 = tx * (1f - ty)
        val w01 = (1f - tx) * ty
        val w11 = tx * ty
        val r = (((a shr 16) and 255) * w00 + ((b shr 16) and 255) * w10 + ((c shr 16) and 255) * w01 + ((d shr 16) and 255) * w11).roundToInt()
        val gg = (((a shr 8) and 255) * w00 + ((b shr 8) and 255) * w10 + ((c shr 8) and 255) * w01 + ((d shr 8) and 255) * w11).roundToInt()
        val bb = ((a and 255) * w00 + (b and 255) * w10 + (c and 255) * w01 + (d and 255) * w11).roundToInt()
        return (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (gg.coerceIn(0, 255) shl 8) or bb.coerceIn(0, 255)
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    // ------------------------------------------------------------------ helpers
    /** soft ellipse weight: 1 inside, falling to 0 outside (rotated by ca/sa) */
    private inline fun forEllipse(
        w: Int, h: Int, cx: Float, cy: Float, rx: Float, ry: Float, ca: Float, sa: Float, body: (Int, Float) -> Unit
    ) {
        val rr = max(rx, ry) * 1.3f
        val xa = max(0, (cx - rr).toInt())
        val xb = min(w - 1, (cx + rr).toInt())
        val ya = max(0, (cy - rr).toInt())
        val yb = min(h - 1, (cy + rr).toInt())
        for (y in ya..yb) {
            for (x in xa..xb) {
                val dx = x - cx
                val dy = y - cy
                val u = (dx * ca + dy * sa) / rx
                val v = (-dx * sa + dy * ca) / ry
                val d = sqrt(u * u + v * v)
                val wt = ((1.25f - d) / 0.45f).coerceIn(0f, 1f)
                if (wt > 0f) body(y * w + x, wt)
            }
        }
    }

    private fun guidedSelf(src: FloatArray, w: Int, h: Int, r: Int, eps: Float): FloatArray {
        val n = w * h
        val tmp = FloatArray(n)
        val mI = FloatArray(n)
        val mII = FloatArray(n)
        val sq = FloatArray(n)
        for (i in 0 until n) sq[i] = src[i] * src[i]
        boxBlur(src, mI, tmp, w, h, r)
        boxBlur(sq, mII, tmp, w, h, r)
        val a = FloatArray(n)
        val b = FloatArray(n)
        for (i in 0 until n) {
            val v = max(0f, mII[i] - mI[i] * mI[i])
            val ai = v / (v + eps)
            a[i] = ai
            b[i] = mI[i] - ai * mI[i]
        }
        boxBlur(a, a, tmp, w, h, r)
        boxBlur(b, b, tmp, w, h, r)
        val out = FloatArray(n)
        for (i in 0 until n) out[i] = a[i] * src[i] + b[i]
        return out
    }

    private fun blur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val out = FloatArray(src.size)
        boxBlur(src, out, FloatArray(src.size), w, h, max(1, r))
        return out
    }

    // ------------------------------------------------------------------ effects (work resolution)
    private fun effects(px: IntArray, w: Int, h: Int, g: Geo, cfg: Cfg): IntArray {
        val n = w * h
        val R = FloatArray(n)
        val G = FloatArray(n)
        val B = FloatArray(n)
        for (i in 0 until n) {
            val p = px[i]
            R[i] = ((p shr 16) and 255).toFloat()
            G[i] = ((p shr 8) and 255).toFloat()
            B[i] = (p and 255).toFloat()
        }
        val fw = g.w
        val fh = g.h

        // eye line angle (ellipse orientation)
        var ca = 1f
        var sa = 0f
        if (g.eL != null && g.eR != null) {
            val a = if (g.eL.x <= g.eR.x) g.eL else g.eR
            val b = if (g.eL.x <= g.eR.x) g.eR else g.eL
            val ang = atan2(b.y - a.y, b.x - a.x).coerceIn(-0.6f, 0.6f)
            ca = cos(ang); sa = sin(ang)
        }
        val mouthOk = g.mL != null && g.mR != null
        val mw = if (mouthOk) sqrt((g.mR!!.x - g.mL!!.x) * (g.mR.x - g.mL.x) + (g.mR.y - g.mL.y) * (g.mR.y - g.mL.y)) else 0.4f * fw
        val mcx = if (mouthOk) (g.mL!!.x + g.mR!!.x) * 0.5f else g.cx
        val cornerY = if (mouthOk) (g.mL!!.y + g.mR!!.y) * 0.5f else g.t + 0.78f * fh
        val botY = g.mB?.y ?: (cornerY + 0.28f * mw)

        // ---- skin colour statistics from the cheek / nose area
        val eyeMidY = if (g.eL != null && g.eR != null) (g.eL.y + g.eR.y) * 0.5f else g.t + 0.40f * fh
        val sx0 = max(0, (g.cx - 0.17f * fw).toInt())
        val sx1 = min(w - 1, (g.cx + 0.17f * fw).toInt())
        val sy0 = max(0, (eyeMidY + 0.10f * fh).toInt())
        val sy1 = min(h - 1, max(sy0 + 4f, cornerY - 0.06f * fh).toInt())
        var cnt = 0
        var sY = 0.0; var sCb = 0.0; var sCr = 0.0; var sY2 = 0.0; var sCb2 = 0.0; var sCr2 = 0.0; var sRG = 0.0; var sRed = 0.0; var sRed2 = 0.0
        val step = max(1, (sx1 - sx0) / 40)
        var yy = sy0
        while (yy <= sy1) {
            var xx = sx0
            while (xx <= sx1) {
                val i = yy * w + xx
                val y = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                if (y in 30f..245f) {
                    val cb = B[i] - y
                    val cr = R[i] - y
                    cnt++
                    sY += y; sY2 += y * y
                    sCb += cb; sCb2 += cb * cb
                    sCr += cr; sCr2 += cr * cr
                    sRG += (R[i] - G[i]) / (R[i] + 1f)
                    sRed += cr; sRed2 += cr * cr
                }
                xx += step
            }
            yy += step
        }
        if (cnt < 12) return px                           // no usable skin sample
        val muY = (sY / cnt).toFloat()
        val muCb = (sCb / cnt).toFloat()
        val muCr = (sCr / cnt).toFloat()
        val sdCb = sqrt(max(1.0, sCb2 / cnt - (sCb / cnt) * (sCb / cnt))).toFloat()
        val sdCr = sqrt(max(1.0, sCr2 / cnt - (sCr / cnt) * (sCr / cnt))).toFloat()
        val muRG = (sRG / cnt).toFloat()
        val blotch = sdCr                                  // spread of redness inside the cheek patch
        val sigCb = max(7f, sdCb * 2.4f)
        val sigCr = max(7f, sdCr * 2.4f)

        // ---- masks
        val Y = FloatArray(n)
        val S = FloatArray(n)                              // skin mask (0..1)
        val fcx = g.cx
        val fcy = g.t + 0.52f * fh
        val frx = 0.56f * fw
        val fry = 0.60f * fh
        for (y in 0 until h) {
            val dyN = (y - fcy) / fry
            for (x in 0 until w) {
                val i = y * w + x
                val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                Y[i] = yl
                val dxN = (x - fcx) / frx
                val d = sqrt(dxN * dxN + dyN * dyN)
                val wf = ((1.12f - d) / 0.35f).coerceIn(0f, 1f)
                if (wf <= 0f) continue
                val dcb = (B[i] - yl) - muCb
                val dcr = (R[i] - yl) - muCr
                val lik = exp(-0.5f * (dcb * dcb / (sigCb * sigCb) + dcr * dcr / (sigCr * sigCr)))
                val ly = ((yl - 28f) / 25f).coerceIn(0f, 1f)
                S[i] = wf * lik * ly
            }
        }
        // protect eyes, brows, mouth, nostrils
        val P = FloatArray(n)
        val eyes = ArrayList<PointF>()
        g.eL?.let { eyes.add(it) }
        g.eR?.let { eyes.add(it) }
        for (e in eyes) {
            forEllipse(w, h, e.x, e.y, 0.12f * fw, 0.066f * fw, ca, sa) { i, wt -> if (wt > P[i]) P[i] = wt }
            forEllipse(w, h, e.x, e.y - 0.085f * fw, 0.16f * fw, 0.05f * fw, ca, sa) { i, wt -> if (wt > P[i]) P[i] = wt }
        }
        if (mouthOk) {
            val cy = cornerY * 0.6f + botY * 0.4f
            val ry = max(0.22f * mw, (botY - cornerY) * 0.9f + 0.1f * mw)
            forEllipse(w, h, mcx, cy, 0.64f * mw, ry, ca, sa) { i, wt -> if (wt > P[i]) P[i] = wt }
        }
        g.nose?.let { nb -> forEllipse(w, h, nb.x, nb.y - 0.01f * fw, 0.13f * fw, 0.07f * fw, ca, sa) { i, wt -> if (wt > P[i]) P[i] = wt } }
        val rEdge = max(1, (fw * 0.008f).toInt())
        val Sb = blur(S, w, h, rEdge)
        for (i in 0 until n) S[i] = (Sb[i] * (1f - P[i])).coerceIn(0f, 1f)

        // ---- AI Auto-Beauty: measure the face and scale the effects
        var aiSm = 1f
        var aiGlow = 1f
        var aiTone = 1f
        if (cfg.ai) {
            val bl = blur(Y, w, h, max(2, (fw * 0.010f).toInt()))
            var acc = 0.0
            var wsum = 0.0
            for (i in 0 until n) {
                val m = S[i]
                if (m > 0.5f) { acc += abs(Y[i] - bl[i]); wsum += 1.0 }
            }
            val rough = if (wsum > 30) (acc / wsum).toFloat() else 4f
            aiSm = (0.65f + rough / 9f).coerceIn(0.65f, 1.25f)
            aiGlow = ((172f - muY) / 55f).coerceIn(0.15f, 1.3f)
            aiTone = (0.5f + blotch / 6f).coerceIn(0.5f, 1.3f)
            Log.i(TAG, "AI beauty: rough=$rough skinLuma=$muY blotch=$blotch -> smooth x$aiSm glow x$aiGlow tone x$aiTone")
        }

        // ---- 1) blemish / spot remover (before smoothing, on the original)
        val bAmt = cfg.a("blemish")
        if (bAmt > 0.01f) {
            val rb = ((fw * 0.028f).toInt()).coerceIn(3, 22)
            val Yb = blur(Y, w, h, rb)
            val Cr = FloatArray(n)
            for (i in 0 until n) Cr[i] = R[i] - Y[i]
            val Crb = blur(Cr, w, h, rb)
            val spot = FloatArray(n)
            val t0 = 4f + 10f * (1f - bAmt)
            val t1 = 14f + 16f * (1f - bAmt)
            val r0 = 3f + 6f * (1f - bAmt)
            val r1 = 10f + 10f * (1f - bAmt)
            for (i in 0 until n) {
                if (S[i] < 0.25f) continue
                val dark = smooth(t0, t1, Yb[i] - Y[i])
                val red = smooth(r0, r1, Cr[i] - Crb[i]) * 0.9f
                spot[i] = max(dark, red) * S[i]
            }
            val spotB = blur(spot, w, h, 1)
            val inv = FloatArray(n)
            for (i in 0 until n) inv[i] = 1f - spotB[i]
            val wR = FloatArray(n); val wG = FloatArray(n); val wB = FloatArray(n)
            for (i in 0 until n) { wR[i] = R[i] * inv[i]; wG[i] = G[i] * inv[i]; wB[i] = B[i] * inv[i] }
            val nR = blur(wR, w, h, rb)
            val nG = blur(wG, w, h, rb)
            val nB = blur(wB, w, h, rb)
            val den = blur(inv, w, h, rb)
            for (i in 0 until n) {
                val m = spotB[i] * bAmt
                if (m < 0.01f) continue
                val dd = den[i]
                if (dd < 0.05f) continue
                R[i] += (nR[i] / dd - R[i]) * m
                G[i] += (nG[i] / dd - G[i]) * m
                B[i] += (nB[i] / dd - B[i]) * m
            }
            for (i in 0 until n) Y[i] = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
        }

        // ---- 2) skin smoothing: edge-preserving base + partly removed detail
        val sAmt = (cfg.a("smooth") * aiSm).coerceIn(0f, 0.9f)
        if (sAmt > 0.01f) {
            val r = ((fw * 0.010f).roundToInt()).coerceIn(2, 10)
            val e = 10f + 34f * sAmt
            val base = guidedSelf(Y, w, h, r, e * e)
            val keep = 1f - 0.78f * sAmt
            for (i in 0 until n) {
                val m = S[i]
                if (m < 0.01f) continue
                val ys = base[i] + (Y[i] - base[i]) * keep
                val d = (ys - Y[i]) * m
                R[i] += d; G[i] += d; B[i] += d
            }
            for (i in 0 until n) Y[i] = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
        }

        // ---- 3) even skin tone: masked chroma blur + pull back red excess
        val tAmt = (cfg.a("tone") * aiTone).coerceIn(0f, 1f)
        if (tAmt > 0.01f) {
            val rc = ((fw * 0.035f).roundToInt()).coerceIn(3, 24)
            val Cr = FloatArray(n)
            val Cb = FloatArray(n)
            val cr = FloatArray(n)
            val cb = FloatArray(n)
            for (i in 0 until n) {
                cr[i] = R[i] - Y[i]
                cb[i] = B[i] - Y[i]
                Cr[i] = cr[i] * S[i]
                Cb[i] = cb[i] * S[i]
            }
            val nCr = blur(Cr, w, h, rc)
            val nCb = blur(Cb, w, h, rc)
            val dS = blur(S, w, h, rc)
            for (i in 0 until n) {
                val m = S[i]
                if (m < 0.01f) continue
                val dd = dS[i]
                if (dd < 0.05f) continue
                val avgCr = nCr[i] / dd
                val avgCb = nCb[i] / dd
                val k = 0.85f * tAmt * m
                var ncr = cr[i] + (avgCr - cr[i]) * k
                val ncb = cb[i] + (avgCb - cb[i]) * k
                // only a whisper of red-excess pull: pulling red hard turned warm / dark skin yellow-green
                val excess = ncr - muCr
                if (excess > 0f) ncr -= excess * 0.10f * tAmt * m
                R[i] = Y[i] + ncr
                B[i] = Y[i] + ncb
                G[i] = (Y[i] - 0.299f * R[i] - 0.114f * B[i]) / 0.587f
            }
        }

        // ---- 4) brighten + glow
        val gAmt = (cfg.a("glow") * aiGlow).coerceIn(0f, 1f)
        if (gAmt > 0.01f) {
            for (i in 0 until n) {
                val m = S[i]
                if (m < 0.01f) continue
                val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                // brighten only the darker / mid skin; bright (already shiny) pixels get no extra gain
                val room = (1f - ((yl - 120f) / 70f).coerceIn(0f, 1f))
                val gain = 1f + 0.16f * gAmt * m * (1f - 0.7f * yl / 255f) * room
                R[i] *= gain; G[i] *= gain; B[i] *= gain
            }
        }

        // ---- 4b) shine control: pull specular highlights (oily shine / flash glare) on skin back towards the skin mean
        val shAmt = max(cfg.a("smooth"), cfg.a("glow")).coerceIn(0f, 1f)
        if (shAmt > 0.01f) {
            val hiT = muY * 1.18f + 12f
            for (i in 0 until n) {
                val m = S[i]
                if (m < 0.01f) continue
                val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                if (yl <= hiT) continue
                val over = ((yl - hiT) / 60f).coerceIn(0f, 1f)
                val k = 1f - 0.55f * shAmt * m * over          // scale RGB together = hue preserved
                R[i] *= k; G[i] *= k; B[i] *= k
            }
        }

        // ---- 5) eyes: brighter whites + lighter dark circles
        val eAmt = cfg.a("eyes")
        if (eAmt > 0.01f && eyes.isNotEmpty()) {
            for (e in eyes) {
                forEllipse(w, h, e.x, e.y, 0.115f * fw, 0.055f * fw, ca, sa) { i, wt ->
                    val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                    val mx = max(R[i], max(G[i], B[i]))
                    val mn = min(R[i], min(G[i], B[i]))
                    val sat = (mx - mn) / (mx + 1f)
                    val k = wt * smooth(muY, muY + 25f, yl) * (1f - smooth(0.25f, 0.45f, sat)) * eAmt
                    if (k > 0.01f) {
                        val gain = 1f + 0.30f * k
                        val gray = yl * gain
                        R[i] = R[i] * gain + (gray - R[i] * gain) * 0.4f * k
                        G[i] = G[i] * gain + (gray - G[i] * gain) * 0.4f * k
                        B[i] = B[i] * gain + (gray - B[i] * gain) * 0.4f * k
                    }
                }
                forEllipse(w, h, e.x, e.y + 0.095f * fw, 0.14f * fw, 0.05f * fw, ca, sa) { i, wt ->
                    val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                    if (yl < muY * 0.97f) {
                        val k = wt * eAmt * 0.6f * S[i].coerceAtLeast(0.35f)
                        val d = (muY * 0.98f - yl) * k
                        R[i] += d; G[i] += d; B[i] += d
                    }
                }
            }
        }

        // ---- 6) teeth whitening
        val tthAmt = cfg.a("teeth")
        if (tthAmt > 0.01f && mouthOk) {
            val cy = cornerY + 0.12f * mw
            forEllipse(w, h, mcx, min(cy, botY - 0.05f * mw), 0.40f * mw, 0.14f * mw, ca, sa) { i, wt ->
                val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                val mx = max(R[i], max(G[i], B[i]))
                val mn = min(R[i], min(G[i], B[i]))
                val sat = (mx - mn) / (mx + 1f)
                val rg = R[i] / (G[i] + 1f)
                val k = wt * smooth(muY * 0.95f + 8f, muY * 0.95f + 30f, yl) * (1f - smooth(0.30f, 0.42f, sat)) * (1f - smooth(1.25f, 1.45f, rg)) * tthAmt
                if (k > 0.01f) {
                    B[i] += (G[i] - B[i]) * 0.7f * k
                    val gain = 1f + 0.14f * k
                    R[i] *= gain; G[i] *= gain; B[i] *= gain
                }
            }
        }

        // ---- 7) lip colour
        val lAmt = cfg.a("lips")
        if (lAmt > 0.01f && mouthOk) {
            val cy = cornerY + 0.15f * mw
            forEllipse(w, h, mcx, cy, 0.60f * mw, 0.30f * mw, ca, sa) { i, wt ->
                val rgv = (R[i] - G[i]) / (R[i] + 1f)
                val lip = smooth(muRG + 0.04f, muRG + 0.16f, rgv)
                val k = wt * lip * lAmt
                if (k > 0.01f) {
                    val yl = 0.299f * R[i] + 0.587f * G[i] + 0.114f * B[i]
                    val boost = 1f + 0.55f * k
                    R[i] = yl + (R[i] - yl) * boost
                    G[i] = yl + (G[i] - yl) * (1f + 0.15f * k)
                    B[i] = yl + (B[i] - yl) * (1f + 0.25f * k)
                }
            }
        }

        val out = IntArray(n)
        for (i in 0 until n) {
            val r = R[i].roundToInt().coerceIn(0, 255)
            val gg = G[i].roundToInt().coerceIn(0, 255)
            val b = B[i].roundToInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (r shl 16) or (gg shl 8) or b
        }
        return out
    }
}

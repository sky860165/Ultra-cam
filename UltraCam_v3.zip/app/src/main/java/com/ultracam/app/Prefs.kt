package com.ultracam.app

import android.content.Context

class Prefs(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val sp = ctx.getSharedPreferences("ultracam", Context.MODE_PRIVATE)

    private fun gi(k: String, d: Int): Int = sp.getInt(k, d)
    private fun si(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    private fun gb(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun sb(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    var lookId: String
        get() = sp.getString("look", "natural") ?: "natural"
        set(v) { sp.edit().putString("look", v).apply() }

    var lookIntensity: Int
        get() = gi("lookInt", 100)
        set(v) { si("lookInt", v) }

    /** 0 = ~12MP (4K+), 1 = ~16MP, 2 = MAX sensor (direct JPEG, no processing) */
    var capRes: Int
        get() = gi("capRes16", 1)          // default 16MP (new key so the new default applies once)
        set(v) { si("capRes16", v) }

    /** 0 = native, 1 = 1.5x super-res, 2 = 2x super-res (capped by megapixel limit) */
    var outScale: Int
        get() = gi("outScale", 0)
        set(v) { si("outScale", v) }

    var denoise: Int
        get() = gi("denoise", 50)
        set(v) { si("denoise", v) }

    var sharp: Int
        get() = gi("sharp", 50)
        set(v) { si("sharp", v) }

    var detail: Int
        get() = gi("detail", 45)
        set(v) { si("detail", v) }

    var enhance: Int
        get() = gi("enhance", 50)
        set(v) { si("enhance", v) }

    var lift: Int
        get() = gi("lift", 35)
        set(v) { si("lift", v) }

    /** 0 off, 1 auto, 2 on */
    var flash: Int
        get() = gi("flash", 0)
        set(v) { si("flash", v) }

    /** 0, 3, 10 seconds */
    var timer: Int
        get() = gi("timer", 0)
        set(v) { si("timer", v) }

    var grid: Boolean
        get() = gb("grid", true)
        set(v) { sb("grid", v) }

    var tripod: Boolean
        get() = gb("tripod", false)
        set(v) { sb("tripod", v) }

    var keepOriginal: Boolean
        get() = gb("keepOrig", false)
        set(v) { sb("keepOrig", v) }

    var proProcess: Boolean
        get() = gb("proProcess", false)
        set(v) { sb("proProcess", v) }

    /** 0 = 4K, 1 = FHD, 2 = HD */
    var videoRes: Int
        get() = gi("videoRes", 0)
        set(v) { si("videoRes", v) }

    var superSteady: Boolean
        get() = gb("superSteady", true)
        set(v) { sb("superSteady", v) }

    var videoLowLight: Boolean
        get() = gb("videoLow", false)
        set(v) { sb("videoLow", v) }

    /** 0 off, 1 histogram+level, 2 +focus peaking, 3 +zebra */
    var analyzer: Int
        get() = gi("analyzer", 0)
        set(v) { si("analyzer", v) }

    /** AUTO = quick multi-frame burst + smart focus (default on) */
    /** 0 = Fast (fewer frames, short focus wait, no NLM pass), 1 = Balanced, 2 = Quality */
    var speed: Int
        get() = gi("speed", 0)
        set(v) { si("speed", v.coerceIn(0, 2)) }

    var showTiming: Boolean
        get() = gb("showTiming", true)
        set(v) { sb("showTiming", v) }

    var smartAuto: Boolean
        get() = gb("smartAuto", true)
        set(v) { sb("smartAuto", v) }

    /** AI Director: scene/light/motion analysis picks shutter policy, frame count, EV and processing strengths per shot */
    var aiDirector: Boolean
        get() = gb("aiDirector", true)
        set(v) { sb("aiDirector", v) }

    /** RAW (DNG) burst merge + develop for AUTO / ULTRA / NIGHT / HDR when the lens exposes RAW */
    /** RAW in PANO / LAPSE / TRAILS: the camera is driven directly (Camera2), so the live preview is paused while it runs */
    var rawMulti: Boolean
        get() = gb("rawMulti", true)
        set(v) { sb("rawMulti", v) }

    var rawEngine: Boolean
        get() = gb("rawEngine", true)
        set(v) { sb("rawEngine", v) }

    /** also keep the reference DNG next to the processed JPEG */
    var saveDng: Boolean
        get() = gb("saveDng", false)
        set(v) { sb("saveDng", v) }

    /** colour pop: vibrance + blue/green boost (skin stays natural) */
    var colorPop: Int
        get() = gi("colorPop", 55)
        set(v) { si("colorPop", v) }

    /** AI Director may blur the background automatically when it finds a person (off by default; PORTRAIT mode always blurs) */
    var autoBlur: Boolean
        get() = gb("autoBlur", false)
        set(v) { sb("autoBlur", v) }

    var autoScene: Boolean
        get() = gb("autoScene", true)
        set(v) { sb("autoScene", v) }

    var lapseInterval: Int
        get() = gi("lapseInt", 5)
        set(v) { si("lapseInt", v) }

    /** 0 = until stopped */
    var lapseCount: Int
        get() = gi("lapseCount", 100)
        set(v) { si("lapseCount", v) }

    var bokeh: Int
        get() = gi("bokeh", 60)
        set(v) { si("bokeh", v) }

    /** RAW path: sub-pixel multi-frame super-resolution (green plane). Needs more RAM + a few seconds more. */
    var subPixelSr: Boolean
        get() = gb("subSr", true)
        set(v) { sb("subSr", v) }

    /** Beauty power: global multiplier on every beauty amount (100 = default, up to 200, 200 = max) */
    var beautyPower: Int
        get() = gi("beautyPower", 100)
        set(v) { si("beautyPower", v.coerceIn(50, 200)) }

    // ---- Beauty: front and back camera have separate settings ----
    private fun bk(front: Boolean): String = if (front) "bf" else "bb"
    /** master switch (default: front ON, back ON — both cameras; only touches photos where a face is found) */
    fun beautyOn(front: Boolean): Boolean = gb("${bk(front)}_on", true)
    fun setBeautyOn(front: Boolean, v: Boolean) { sb("${bk(front)}_on", v) }
    fun beautyAi(front: Boolean): Boolean = gb("${bk(front)}_ai", true)
    fun setBeautyAi(front: Boolean, v: Boolean) { sb("${bk(front)}_ai", v) }
    fun beautyFeatOn(front: Boolean, id: String, def: Boolean): Boolean = gb("${bk(front)}_${id}_on", def)
    fun setBeautyFeatOn(front: Boolean, id: String, v: Boolean) { sb("${bk(front)}_${id}_on", v) }
    fun beautyAmt(front: Boolean, id: String, def: Int): Int = gi("${bk(front)}_${id}_amt", def)
    fun setBeautyAmt(front: Boolean, id: String, v: Int) { si("${bk(front)}_${id}_amt", v) }

    /** "Ultra Natural" look = true-to-life colours: no colour pop / vibrance / auto-enhance (the plain "Natural" look is untouched) */
    val realColor: Boolean
        get() = lookId == "ultranat"

    /** Auto Details: denoise / sharpness / detail follow how much light the sensor is getting (ISO x shutter) */
    var autoDetail: Boolean
        get() = gb("autoDetail", true)
        set(v) { sb("autoDetail", v) }

    /** bias for Auto Details: 0 = cleaner / smoother, 50 = balanced, 100 = maximum detail */
    var detailLevel: Int
        get() = gi("detailLvl", 55)
        set(v) { si("detailLvl", v) }

    /** Focus blur (background blur) for every photo mode, adjustable strength */
    var focusBlur: Boolean
        get() = gb("fblur", false)
        set(v) { sb("fblur", v) }

    var focusBlurAmt: Int
        get() = gi("fblurAmt", 60)
        set(v) { si("fblurAmt", v) }

    /** 0 = person (AI) else tapped focus point, 1 = tapped focus point only */
    var focusBlurMode: Int
        get() = gi("fblurMode", 0)
        set(v) { si("fblurMode", v) }

    /** Full-screen: preview fills the whole screen (controls float on top) and photos are cropped to the screen shape */
    var fullScreen: Boolean
        get() = gb("fullScreen", false)
        set(v) { sb("fullScreen", v) }

    /** front-camera screen flash strength 20..100 (soft fill light; 100 = old full-white) */
    var frontFlash: Int
        get() = gi("frontFlash", 40)
        set(v) { si("frontFlash", v) }

    /** front flash tint: 0 = neutral white, 100 = clearly cool (blue-ish) light to cancel the warm / yellow cast */
    var frontFlashCool: Int
        get() = gi("frontFlashCool", 60)
        set(v) { si("frontFlashCool", v) }

    /** final noise clean: chroma = coloured speckle ("dots"), luma = grain on flat areas (0..100) */
    var cleanChroma: Int
        get() = gi("cleanChroma", 70)
        set(v) { si("cleanChroma", v) }

    var cleanLuma: Int
        get() = gi("cleanLuma", 35)
        set(v) { si("cleanLuma", v) }

    /** selfie colour fix (neutral white balance + skin hue guard) */
    var colorFix: Boolean
        get() = gb("colorFix", true)
        set(v) { sb("colorFix", v) }

    var colorFixAmt: Int
        get() = gi("colorFixAmt", 80)
        set(v) { si("colorFixAmt", v) }

    var watermark: Boolean
        get() = gb("wm", false)
        set(v) { sb("wm", v) }

    var video60: Boolean
        get() = gb("video60", false)
        set(v) { sb("video60", v) }

    var videoHdr: Boolean
        get() = gb("videoHdr", false)
        set(v) { sb("videoHdr", v) }

    fun savePreset(n: Int) {
        val e = appCtx.getSharedPreferences("ultracam_preset_$n", Context.MODE_PRIVATE).edit()
        e.clear()
        for ((k, v) in sp.all) put(e, k, v)
        e.apply()
    }

    fun loadPreset(n: Int): Boolean {
        val src = appCtx.getSharedPreferences("ultracam_preset_$n", Context.MODE_PRIVATE)
        if (src.all.isEmpty()) return false
        val e = sp.edit()
        for ((k, v) in src.all) put(e, k, v)
        e.apply()
        return true
    }

    private fun put(e: android.content.SharedPreferences.Editor, k: String, v: Any?) {
        when (v) {
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
            is String -> e.putString(k, v)
            is Float -> e.putFloat(k, v)
            is Long -> e.putLong(k, v)
            else -> {}
        }
    }
}

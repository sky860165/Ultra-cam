package com.ultracam.app

import android.content.Context

class Prefs(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val sp = ctx.getSharedPreferences("ultracam", Context.MODE_PRIVATE)

    private fun gi(k: String, d: Int): Int = sp.getInt(k, d)
    private fun si(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    private fun gb(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun sb(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    var lookId: String
        get() = sp.getString("look", "natural") ?: "natural"
        set(v) { sp.edit().putString("look", v).apply() }

    var lookIntensity: Int
        get() = gi("lookInt", 100)
        set(v) { si("lookInt", v) }

    /** 0 = ~12MP (4K+), 1 = ~16MP, 2 = MAX sensor (direct JPEG, no processing) */
    var capRes: Int
        get() = gi("capRes", 0)
        set(v) { si("capRes", v) }

    /** 0 = native, 1 = 1.5x super-res, 2 = 2x super-res (capped by megapixel limit) */
    var outScale: Int
        get() = gi("outScale", 0)
        set(v) { si("outScale", v) }

    var denoise: Int
        get() = gi("denoise", 50)
        set(v) { si("denoise", v) }

    var sharp: Int
        get() = gi("sharp", 50)
        set(v) { si("sharp", v) }

    var detail: Int
        get() = gi("detail", 45)
        set(v) { si("detail", v) }

    var enhance: Int
        get() = gi("enhance", 50)
        set(v) { si("enhance", v) }

    var lift: Int
        get() = gi("lift", 35)
        set(v) { si("lift", v) }

    /** 0 off, 1 auto, 2 on */
    var flash: Int
        get() = gi("flash", 0)
        set(v) { si("flash", v) }

    /** 0, 3, 10 seconds */
    var timer: Int
        get() = gi("timer", 0)
        set(v) { si("timer", v) }

    var grid: Boolean
        get() = gb("grid", true)
        set(v) { sb("grid", v) }

    var tripod: Boolean
        get() = gb("tripod", false)
        set(v) { sb("tripod", v) }

    var keepOriginal: Boolean
        get() = gb("keepOrig", false)
        set(v) { sb("keepOrig", v) }

    var proProcess: Boolean
        get() = gb("proProcess", false)
        set(v) { sb("proProcess", v) }

    /** 0 = 4K, 1 = FHD, 2 = HD */
    var videoRes: Int
        get() = gi("videoRes", 0)
        set(v) { si("videoRes", v) }

    var superSteady: Boolean
        get() = gb("superSteady", false)
        set(v) { sb("superSteady", v) }

    var videoLowLight: Boolean
        get() = gb("videoLow", false)
        set(v) { sb("videoLow", v) }

    /** 0 off, 1 histogram+level, 2 +focus peaking, 3 +zebra */
    var analyzer: Int
        get() = gi("analyzer", 0)
        set(v) { si("analyzer", v) }

    /** AUTO = quick multi-frame burst + smart focus (default on) */
    var smartAuto: Boolean
        get() = gb("smartAuto", true)
        set(v) { sb("smartAuto", v) }

    /** AI Director: scene/light/motion analysis picks shutter policy, frame count, EV and processing strengths per shot */
    var aiDirector: Boolean
        get() = gb("aiDirector", true)
        set(v) { sb("aiDirector", v) }

    var autoScene: Boolean
        get() = gb("autoScene", true)
        set(v) { sb("autoScene", v) }

    var lapseInterval: Int
        get() = gi("lapseInt", 5)
        set(v) { si("lapseInt", v) }

    /** 0 = until stopped */
    var lapseCount: Int
        get() = gi("lapseCount", 100)
        set(v) { si("lapseCount", v) }

    var bokeh: Int
        get() = gi("bokeh", 60)
        set(v) { si("bokeh", v) }

    var watermark: Boolean
        get() = gb("wm", false)
        set(v) { sb("wm", v) }

    var video60: Boolean
        get() = gb("video60", false)
        set(v) { sb("video60", v) }

    var videoHdr: Boolean
        get() = gb("videoHdr", false)
        set(v) { sb("videoHdr", v) }

    fun savePreset(n: Int) {
        val e = appCtx.getSharedPreferences("ultracam_preset_$n", Context.MODE_PRIVATE).edit()
        e.clear()
        for ((k, v) in sp.all) put(e, k, v)
        e.apply()
    }

    fun loadPreset(n: Int): Boolean {
        val src = appCtx.getSharedPreferences("ultracam_preset_$n", Context.MODE_PRIVATE)
        if (src.all.isEmpty()) return false
        val e = sp.edit()
        for ((k, v) in src.all) put(e, k, v)
        e.apply()
        return true
    }

    private fun put(e: android.content.SharedPreferences.Editor, k: String, v: Any?) {
        when (v) {
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
            is String -> e.putString(k, v)
            is Float -> e.putFloat(k, v)
            is Long -> e.putLong(k, v)
            else -> {}
        }
    }
}

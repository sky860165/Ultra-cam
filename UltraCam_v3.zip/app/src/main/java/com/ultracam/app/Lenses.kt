package com.ultracam.app

import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** One rear sensor found on the phone. */
data class LensInfo(
    val id: String,
    val eqMm: Float,          // 35mm-equivalent focal length (0 = unknown)
    val mp: Int,              // max JPEG megapixels (0 = unknown)
    val role: String,         // Main / Ultra-wide / Tele / Macro / Depth / Mono
    val usable: Boolean,      // CameraX can open it directly
    val isImage: Boolean,     // false for depth-only sensors
    val note: String
) {
    val label: String
        get() = buildString {
            append("Camera ").append(id).append("  •  ").append(role)
            if (eqMm > 0f) append("  •  ").append(eqMm.roundToInt()).append("mm")
            if (mp > 0) append("  •  ").append(mp).append("MP")
            append("\n    ").append(if (!isImage) "depth sensor (photo nahi deta)" else if (usable) "✓ ON kar sakte ho" else note)
        }
}

/** Finds every rear sensor Android lets this app see: public camera ids, physical sensors behind logical cameras, and probed hidden ids. */
object Lenses {

    fun discover(cm: CameraManager): List<LensInfo> {
        val out = LinkedHashMap<String, LensInfo>()
        val publicIds = try { cm.cameraIdList.toList() } catch (e: Exception) { emptyList() }

        fun add(id: String, usable: Boolean, note: String) {
            if (out.containsKey(id)) return
            val c = try { cm.getCameraCharacteristics(id) } catch (e: Exception) { return }
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) return
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
            val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val eq = if (f != null && sz != null) f * 43.27f / sqrt(sz.width * sz.width + sz.height * sz.height) else 0f
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val jpeg = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }
            val mp = if (jpeg != null) (jpeg.width.toLong() * jpeg.height / 1_000_000L).toInt() else 0
            val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
            val cfa = c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT)
            val depthOnly = 8 in caps && 0 !in caps
            val role = when {
                depthOnly -> "Depth"
                cfa == 5 -> "Mono"
                eq in 0.1f..21f -> "Ultra-wide"
                eq > 65f -> "Tele"
                minFocus >= 10f && mp in 1..5 -> "Macro"
                mp in 1..3 && eq > 0f -> "Macro/aux"
                else -> "Main"
            }
            val shownNote = if (role == "Ultra-wide" && !usable) "ULTRA-WIDE mode isse direct Camera2 se kholne ka try karta hai" else note
            out[id] = LensInfo(id, eq, mp, role, usable && !depthOnly, !depthOnly, shownNote)
        }

        for (id in publicIds) add(id, true, "")
        if (Build.VERSION.SDK_INT >= 28) {
            for (id in publicIds) {
                val phys = try { cm.getCameraCharacteristics(id).physicalCameraIds } catch (e: Exception) { emptySet<String>() }
                for (p in phys) add(p, false, "logical camera $id ka hissa — phone sirf group deta hai")
            }
        }
        // hidden ids: most phones refuse, some (older MediaTek/Qualcomm builds) answer
        for (i in 0..40) {
            val id = i.toString()
            if (id !in out && id !in publicIds) add(id, false, "phone ne app se chhupa rakha hai (MIUI block)")
        }
        return out.values.toList()
    }
}

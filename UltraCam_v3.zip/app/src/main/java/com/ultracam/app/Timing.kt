package com.ultracam.app

import java.util.Locale

/** Tiny stage timer: shows "total 4.2s: merge 1.8s • clean 0.9s • ..." after each photo so slow stages are visible without a PC. */
class StageTimer {
    private val t0 = System.currentTimeMillis()
    private var last = t0
    private val sb = StringBuilder()

    fun lap(name: String) {
        val n = System.currentTimeMillis()
        val d = n - last
        last = n
        if (d >= 50L) sb.append(name).append(' ').append(String.format(Locale.US, "%.1f", d / 1000f)).append("s • ")
    }

    fun note(s: String) {
        sb.append(s).append(" • ")
    }

    fun summary(): String {
        val total = String.format(Locale.US, "total %.1fs", (System.currentTimeMillis() - t0) / 1000f)
        val rest = sb.toString().trimEnd(' ', '•')
        return if (rest.isEmpty()) total else "$total: $rest"
    }
}

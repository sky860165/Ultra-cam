package com.ultracam.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class ProcMode { SINGLE, STACK, NIGHT, HDR, ASTRO, TRAILS, DOC }

data class ProcParams(
    val mode: ProcMode,
    val scale: Float = 1f,
    val maxPixels: Long = 30_000_000L,
    val denoise: Float = 0.5f,
    val sharpness: Float = 0.5f,
    val detail: Float = 0.45f,
    val shadowLift: Float = 0.35f,
    val look: Look = Looks.NATURAL,
    val lookIntensity: Float = 1f,
    val localAlign: Boolean = true,
    val nativeEngine: Boolean = true,
    /** 0..1 Google-Photos-style auto enhance (levels, contrast, vibrance, local detail, shadows) */
    val enhance: Float = 0f
)

/** Tiny parallel-for helper. */
object Par {
    private val threads = max(2, Runtime.getRuntime().availableProcessors())
    private val pool = Executors.newFixedThreadPool(threads) { r ->
        val t = Thread(Runnable {
            try { android.os.Process.setThreadPriority(4) } catch (e: Throwable) { }
            r.run()
        })
        t.isDaemon = true
        t
    }

    fun rows(from: Int, to: Int, body: (Int, Int) -> Unit) {
        val n = to - from
        if (n <= 0) return
        val chunks = min(n, threads * 3)
        val step = (n + chunks - 1) / chunks
        val fs = ArrayList<Future<*>>(chunks)
        var s = from
        while (s < to) {
            val a = s
            val b = min(to, s + step)
            fs.add(pool.submit(Runnable { body(a, b) }))
            s = b
        }
        for (f in fs) f.get()
    }
}

/** Small pool for parallel JPEG decode / per-frame alignment (separate from Par so nesting can't deadlock). */
object Io {
    val pool = Executors.newFixedThreadPool(3) { r ->
        val t = Thread(Runnable {
            try { android.os.Process.setThreadPriority(4) } catch (e: Throwable) { }
            r.run()
        })
        t.isDaemon = true
        t
    }
}

/** Separable box blur (replicate edges). src and dst may be the same array; tmp must differ from both. */
internal fun boxBlur(src: FloatArray, dst: FloatArray, tmp: FloatArray, w: Int, h: Int, r: Int) {
    val inv = 1f / (2 * r + 1)
    Par.rows(0, h) { a, b ->
        for (y in a until b) {
            val o = y * w
            var acc = 0f
            for (k in -r..r) acc += src[o + min(w - 1, max(0, k))]
            for (x in 0 until w) {
                tmp[o + x] = acc * inv
                val ad = min(w - 1, x + r + 1)
                val sb = max(0, x - r)
                acc += src[o + ad] - src[o + sb]
            }
        }
    }
    Par.rows(0, w) { a, b ->
        for (x in a until b) {
            var acc = 0f
            for (k in -r..r) acc += tmp[min(h - 1, max(0, k)) * w + x]
            for (y in 0 until h) {
                dst[y * w + x] = acc * inv
                val ad = min(h - 1, y + r + 1)
                val sb = max(0, y - r)
                acc += tmp[ad * w + x] - tmp[sb * w + x]
            }
        }
    }
}

internal fun blurTwice(src: FloatArray, dst: FloatArray, tmp: FloatArray, w: Int, h: Int, r: Int) {
    boxBlur(src, dst, tmp, w, h, r)
    boxBlur(dst, dst, tmp, w, h, r)
}

internal class Small(val w: Int, val h: Int, val g: FloatArray, val avgR: Float, val avgG: Float, val avgB: Float)

class AlignResult(
    val ref: Int,
    val dx: FloatArray,
    val dy: FloatArray,
    val sigma: FloatArray,
    val bw: Int,
    val bh: Int,
    val base: FloatArray,
    val median: Float,
    val wbR: Float,
    val wbB: Float,
    val fw: FloatArray = FloatArray(0)
)

/** Global (translation) alignment with coarse-to-fine NCC search + sub-pixel refinement. */
object Align {

    internal fun decodeSmall(path: String, sample: Int): Small {
        val o = BitmapFactory.Options()
        o.inSampleSize = sample
        o.inPreferredConfig = Bitmap.Config.ARGB_8888
        val bmp = BitmapFactory.decodeFile(path, o) ?: throw IllegalStateException("decode failed: $path")
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()
        val g = FloatArray(w * h)
        var sr = 0.0
        var sg = 0.0
        var sb = 0.0
        for (i in px.indices) {
            val p = px[i]
            val r = (p shr 16) and 255
            val gg = (p shr 8) and 255
            val b = p and 255
            g[i] = 0.299f * r + 0.587f * gg + 0.114f * b
            sr += r; sg += gg; sb += b
        }
        val n = px.size.toDouble()
        return Small(w, h, g, (sr / n).toFloat(), (sg / n).toFloat(), (sb / n).toFloat())
    }

    private fun sharpness(s: Small): Double {
        var acc = 0.0
        val w = s.w
        var y = 1
        while (y < s.h - 1) {
            var x = 1
            while (x < w - 1) {
                val i = y * w + x
                acc += abs(s.g[i + 1] - s.g[i]) + abs(s.g[i + w] - s.g[i])
                x += 2
            }
            y += 2
        }
        return acc
    }

    /** Returns [x0, y0, ww, wh] of the most textured window. */
    private fun chooseWindow(s: Small, margin: Int, maxW: Int, maxH: Int): IntArray {
        val ww = max(16, min(maxW, s.w - 2 * margin))
        val wh = max(16, min(maxH, s.h - 2 * margin))
        var bestE = -1.0
        var bx = margin
        var by = margin
        for (iy in 0 until 3) {
            for (ix in 0 until 3) {
                val x0 = margin + max(0, (s.w - 2 * margin - ww)) * ix / 2
                val y0 = margin + max(0, (s.h - 2 * margin - wh)) * iy / 2
                var e = 0.0
                var y = y0
                while (y < y0 + wh - 1 && y < s.h - 1) {
                    var x = x0
                    while (x < x0 + ww - 1 && x < s.w - 1) {
                        val i = y * s.w + x
                        e += abs(s.g[i + 1] - s.g[i]) + abs(s.g[i + s.w] - s.g[i])
                        x += 3
                    }
                    y += 3
                }
                if (e > bestE) { bestE = e; bx = x0; by = y0 }
            }
        }
        return intArrayOf(bx, by, ww, wh)
    }

    private fun valid(win: IntArray, w: Int, h: Int, dx: Int, dy: Int): Boolean =
        win[0] + dx >= 0 && win[1] + dy >= 0 && win[0] + win[2] + dx <= w && win[1] + win[3] + dy <= h

    private fun ncc(a: FloatArray, b: FloatArray, w: Int, win: IntArray, dx: Int, dy: Int, step: Int): Double {
        var sa = 0.0; var sb = 0.0; var saa = 0.0; var sbb = 0.0; var sab = 0.0
        var n = 0
        var y = win[1]
        val yEnd = win[1] + win[3]
        val xEnd = win[0] + win[2]
        while (y < yEnd) {
            val ra = y * w
            val rb = (y + dy) * w + dx
            var x = win[0]
            while (x < xEnd) {
                val p = a[ra + x].toDouble()
                val q = b[rb + x].toDouble()
                sa += p; sb += q; saa += p * p; sbb += q * q; sab += p * q
                n++
                x += step
            }
            y += step
        }
        val num = n * sab - sa * sb
        val den = sqrt(max(1e-9, (n * saa - sa * sa) * (n * sbb - sb * sb)))
        return num / den
    }

    private fun search(a: Small, b: Small, win: IntArray, cx: Int, cy: Int, rad: Int, step: Int): IntArray {
        if (NativeEngine.ok) {
            try { return NativeEngine.search(a.g, b.g, a.w, a.h, win, cx, cy, rad, step) } catch (t: Throwable) { }
        }
        var bestS = -2.0
        var bx = cx
        var by = cy
        for (dy in cy - rad..cy + rad) {
            for (dx in cx - rad..cx + rad) {
                if (!valid(win, a.w, a.h, dx, dy)) continue
                val s = ncc(a.g, b.g, a.w, win, dx, dy, step)
                if (s > bestS) { bestS = s; bx = dx; by = dy }
            }
        }
        return intArrayOf(bx, by)
    }

    private fun subpix(a: Small, b: Small, win: IntArray, bx: Int, by: Int): FloatArray {
        if (!valid(win, a.w, a.h, bx - 1, by - 1) || !valid(win, a.w, a.h, bx + 1, by + 1)) return floatArrayOf(0f, 0f)
        val c0 = ncc(a.g, b.g, a.w, win, bx, by, 1)
        val xm = ncc(a.g, b.g, a.w, win, bx - 1, by, 1)
        val xp = ncc(a.g, b.g, a.w, win, bx + 1, by, 1)
        val ym = ncc(a.g, b.g, a.w, win, bx, by - 1, 1)
        val yp = ncc(a.g, b.g, a.w, win, bx, by + 1, 1)
        fun off(m: Double, c: Double, p: Double): Float {
            val d = m - 2 * c + p
            if (abs(d) < 1e-12) return 0f
            return (0.5 * (m - p) / d).toFloat().coerceIn(-0.5f, 0.5f)
        }
        return floatArrayOf(off(xm, c0, xp), off(ym, c0, yp))
    }

    private fun decodeAll(paths: List<String>, sample: Int): Array<Small> {
        val fs = paths.map { p -> Io.pool.submit(java.util.concurrent.Callable { decodeSmall(p, sample) }) }
        return Array(paths.size) { fs[it].get() }
    }

    fun run(paths: List<String>, mode: ProcMode): AlignResult {
        val n = paths.size
        val s8 = decodeAll(paths, 8)
        val s4 = decodeAll(paths, 4)
        val noAlign = mode == ProcMode.ASTRO || mode == ProcMode.TRAILS
        var ref = 0
        val fw = FloatArray(n) { 1f }
        if (n > 1 && !noAlign) {
            if (mode == ProcMode.HDR && n >= 3) {
                ref = n / 2
            } else {
                var best = -1.0
                val shs = DoubleArray(n)
                for (i in 0 until n) {
                    val sh = sharpness(s4[i])
                    shs[i] = sh
                    if (sh > best) { best = sh; ref = i }
                }
                if (best > 0.0) {
                    for (i in 0 until n) {
                        val ratio = (shs[i] / best).toFloat()
                        fw[i] = ((ratio - 0.55f) / 0.4f).coerceIn(0.08f, 1f)
                    }
                }
            }
        }
        val dx = FloatArray(n)
        val dy = FloatArray(n)
        val sigma = FloatArray(n) { if (noAlign) 60f else 14f }

        if (n > 1 && !noAlign) {
            val r2 = decodeSmall(paths[ref], 2)
            val a8 = s8[ref]
            val a4 = s4[ref]
            val win8 = chooseWindow(a8, 12, 480, 360)
            val win4 = chooseWindow(a4, 30, 640, 480)
            val win2 = chooseWindow(r2, 54, 640, 480)
            val futs = ArrayList<Future<*>>()
            for (i in 0 until n) {
                if (i == ref) continue
                futs.add(Io.pool.submit(Runnable {
                val b8 = search(a8, s8[i], win8, 0, 0, 10, 2)
                val b4 = search(a4, s4[i], win4, b8[0] * 2, b8[1] * 2, 2, 2)

                // noise / motion level estimate for merge weights
                var acc = 0.0
                var cnt = 0
                if (valid(win4, a4.w, a4.h, b4[0], b4[1])) {
                    var y = win4[1]
                    while (y < win4[1] + win4[3]) {
                        var x = win4[0]
                        while (x < win4[0] + win4[2]) {
                            acc += abs(a4.g[y * a4.w + x] - s4[i].g[(y + b4[1]) * a4.w + x + b4[0]])
                            cnt++
                            x += 2
                        }
                        y += 2
                    }
                }
                val meanAbs = if (cnt > 0) (acc / cnt).toFloat() else 6f
                var sg = 6f + 2.6f * meanAbs
                if (mode == ProcMode.NIGHT) sg *= 1.15f
                sigma[i] = sg.coerceIn(8f, 50f)

                val c2 = decodeSmall(paths[i], 2)
                val b2 = search(r2, c2, win2, b4[0] * 2, b4[1] * 2, 2, 1)
                val sp = subpix(r2, c2, win2, b2[0], b2[1])
                dx[i] = (b2[0] + sp[0]) * 2f
                dy[i] = (b2[1] + sp[1]) * 2f
                }))
            }
            for (fu in futs) fu.get()
        }

        // smooth luminance "base" for local tone mapping (from reference, 1/4 scale)
        val a4 = s4[ref]
        // edge-aware base (self-guided filter, 2 passes): a plain blur here made bright halos around dark frames/edges
        val base = edgeAwareBase(a4.g, a4.w, a4.h)

        val sorted = s8[ref].g.copyOf()
        sorted.sort()
        val median = sorted[sorted.size / 2]

        val aR = max(1f, s8[ref].avgR)
        val aG = max(1f, s8[ref].avgG)
        val aB = max(1f, s8[ref].avgB)
        val gray = (aR + aG + aB) / 3f
        val wbR = 1f + ((gray / aR).coerceIn(0.85f, 1.18f) - 1f) * 0.7f
        val wbB = 1f + ((gray / aB).coerceIn(0.85f, 1.18f) - 1f) * 0.7f

        return AlignResult(ref, dx, dy, sigma, a4.w, a4.h, base, median, wbR, wbB, fw)
    }
}


/** Self-guided filter (He et al.) on a luma plane (0..255). Smooths flat areas strongly but keeps strong edges => tone mapping without halos. */
internal fun edgeAwareBase(src: FloatArray, w: Int, h: Int): FloatArray {
    val n = w * h
    var cur = src.copyOf()
    val tmp = FloatArray(n)
    val meanI = FloatArray(n)
    val meanII = FloatArray(n)
    val sq = FloatArray(n)
    val a = FloatArray(n)
    val b = FloatArray(n)
    val radii = intArrayOf(8, 12)
    val eps = floatArrayOf(22f * 22f, 30f * 30f)
    for (pass in radii.indices) {
        val r = radii[pass]
        boxBlur(cur, meanI, tmp, w, h, r)
        for (i in 0 until n) sq[i] = cur[i] * cur[i]
        boxBlur(sq, meanII, tmp, w, h, r)
        for (i in 0 until n) {
            val v = max(0f, meanII[i] - meanI[i] * meanI[i])
            val ai = v / (v + eps[pass])
            a[i] = ai
            b[i] = meanI[i] - ai * meanI[i]
        }
        boxBlur(a, a, tmp, w, h, r)
        boxBlur(b, b, tmp, w, h, r)
        val out = FloatArray(n)
        for (i in 0 until n) out[i] = a[i] * cur[i] + b[i]
        cur = out
    }
    return cur
}

/** Histogram-driven auto enhance: stretch unused tonal range, add contrast/vibrance in proportion to how flat the scene is. */
internal fun autoEnhance(base: FloatArray, e: Float): Enh {
    if (e <= 0f || base.size < 64) return Enh()
    val step = max(1, base.size / 20000)
    val s = FloatArray(base.size / step) { base[it * step] }
    s.sort()
    val p1 = s[(s.size * 0.01f).toInt()]
    val p99 = s[min(s.size - 1, (s.size * 0.99f).toInt())]
    val range = (p99 - p1).coerceIn(40f, 255f)
    val flat = ((230f - range) / 120f).coerceIn(0f, 1f)          // 0 = already punchy, 1 = flat / hazy
    val lo = (p1 * 0.6f).coerceIn(0f, 28f) * e
    val hi = 255f - ((255f - p99) * 0.5f).coerceIn(0f, 22f) * e
    return Enh(
        satMul = 1f + 0.06f * e,
        vibAdd = 0.30f * e,
        contrastMul = 1f + (0.07f + 0.10f * flat) * e,
        lo = lo,
        hi = hi
    )
}

object Engine {
    private const val HS = 160
    private const val MG = 16

    fun process(paths: List<String>, p: ProcParams, status: (String) -> Unit): Bitmap {
        require(paths.isNotEmpty())
        status("Aligning frames…")
        val al = Align.run(paths, p.mode)
        val decs = ArrayList<BitmapRegionDecoder>()
        try {
            for (path in paths) decs.add(BitmapRegionDecoder.newInstance(path, false)!!)
            val w = decs[0].width
            val h = decs[0].height
            var s = p.scale.coerceIn(1f, 2f)
            if (s > 1f && w.toDouble() * h * s * s > p.maxPixels) {
                s = max(1f, sqrt(p.maxPixels.toDouble() / (w.toDouble() * h)).toFloat())
            }
            if (s < 1.02f) s = 1f
            val wo = if (s == 1f) w else (w * s).roundToInt()
            val ho = if (s == 1f) h else (h * s).roundToInt()
            val out = Bitmap.createBitmap(wo, ho, Bitmap.Config.ARGB_8888)
            var done = false
            if (NativeEngine.ok && p.nativeEngine) {
                try {
                    Pipe(w, h, wo, ho, s, p, al, decs, true).executeNative(out, status)
                    done = true
                } catch (t: Throwable) {
                    android.util.Log.w("UltraCam", "native path failed, falling back", t)
                }
            }
            if (!done) Pipe(w, h, wo, ho, s, p, al, decs, false).execute(out, status)
            return out
        } finally {
            for (d in decs) { try { d.recycle() } catch (e: Exception) { } }
        }
    }

    private class Scratch(srcRows: Int, w: Int, wo: Int) {
        val src = IntArray(srcRows * w)
        val xi0 = IntArray(wo)
        val xf = FloatArray(wo)
    }

    private class Pipe(
        val w: Int, val h: Int, val wo: Int, val ho: Int, val s: Float,
        val p: ProcParams, val al: AlignResult, val decs: List<BitmapRegionDecoder>,
        val useNative: Boolean = false
    ) {
        private val NO = FloatArray(0)
        val n = decs.size
        val isNight = p.mode == ProcMode.NIGHT || p.mode == ProcMode.ASTRO
        val isDoc = p.mode == ProcMode.DOC
        val isTrails = p.mode == ProcMode.TRAILS && n >= 2
        val local = p.localAlign && n >= 2 && (p.mode == ProcMode.STACK || p.mode == ProcMode.NIGHT)
        val isHdr = p.mode == ProcMode.HDR && n >= 2
        val merge = n >= 2 && p.mode != ProcMode.SINGLE && !isHdr

        // strip height adapts to output width: fewer strips = far fewer repeated JPEG region decodes
        val hs: Int = ((if (isHdr) 900_000 else 1_800_000) / wo - 2 * MG).coerceIn(96, 480)
        val maxNr = hs + 2 * MG
        val cap = maxNr * wo

        val rP = if (useNative) NO else FloatArray(cap)
        val gP = if (useNative) NO else FloatArray(cap)
        val bP = if (useNative) NO else FloatArray(cap)
        val yP = if (useNative) NO else FloatArray(cap)
        val cbP = if (useNative) NO else FloatArray(cap)
        val crP = if (useNative) NO else FloatArray(cap)
        val t1 = if (useNative) NO else FloatArray(cap)
        val wsP = if (useNative) NO else FloatArray(cap)
        val bufRef = if (useNative) IntArray(0) else IntArray(cap)
        val bufCur = if (useNative) IntArray(0) else IntArray(cap)
        val srcRows = ceil(maxNr / s).toInt() + 10
        val scMain = Scratch(srcRows, w, wo)
        val scratchQ = java.util.concurrent.ArrayBlockingQueue<Scratch>(3).also { q ->
            for (k in 0 until (if (merge && !isTrails) 3 else 0)) q.add(Scratch(srcRows, w, wo))
        }
        val strip = IntArray(hs * wo)
        var noiseSigma = -1f

        val bs = 32
        val bxCount = (wo + bs - 1) / bs
        val offX = ByteArray(bxCount * ((maxNr + bs - 1) / bs))
        val offY = ByteArray(bxCount * ((maxNr + bs - 1) / bs))

        val hdrBuf: Array<IntArray>? = if (isHdr && !useNative) Array(n) { IntArray(cap) } else null
        val hdrW: Array<FloatArray>? = if (isHdr && !useNative) Array(n) { FloatArray(cap) } else null
        val frameBuf: Array<IntArray>? = if (merge && !isTrails && !useNative) Array(n) { IntArray(cap) } else null

        // merge weight LUTs
        val luts = Array(n) { f ->
            val sg = al.sigma[f]
            FloatArray(256) { d -> exp(-(d * d).toFloat() / (2f * sg * sg)) }
        }

        // parameters
        val nf = if (isNight) 1.5f else 1f
        val frameFactor = if (n >= 4) 0.75f else if (n >= 2) 0.9f else 1.15f
        val dn = (p.denoise * nf * frameFactor).coerceIn(0f, 1.6f)
        val chromaR = if (dn < 0.05f) 0 else (1 + 3.5f * dn * s).roundToInt().coerceIn(1, 8)
        val bilSigma = 3f + 20f * dn
        val sharpAmt = (0.30f + 1.2f * p.sharpness) * (if (s > 1f) 1.2f else 1f) * (if (isDoc) 1.5f else 1f)
        val sharpR = if (s >= 1.5f) 2 else 1
        val coreT = 2.5f + 6f * dn
        val hdrK = if (isHdr) 0.6f else 1f
        val enh = if (isDoc) 0f else p.enhance.coerceIn(0f, 1f)
        val detE = (p.detail + 0.25f * enh).coerceAtMost(1f)
        val midAmt = 0.45f * detE * hdrK
        val midR = max(3, (4 * s).roundToInt())
        val detailB = 1f + 0.55f * detE * hdrK
        val lift = (p.shadowLift + 0.15f * enh).coerceAtMost(1f) * hdrK
        val wbR = if (isNight) al.wbR else 1f
        val wbB = if (isNight) al.wbB else 1f
        val gain: Float = run {
            val med = max(al.median, 6f)
            if (isHdr) 1f
            else if (isNight) (0.34f * 255f / med).coerceIn(1f, 3.2f)
            else (0.27f * 255f / med).coerceIn(1f, 1.35f)
        }

        val toneLut = FloatArray(1024).also { lt ->
            for (i in 0 until 1024) {
                val v = i / 1023f
                var v1 = v * gain
                v1 = v1.pow(1f - 0.5f * lift)
                if (v1 > 0.75f) v1 = 0.75f + 0.25f * (1f - exp(-(v1 - 0.75f) / 0.25f))
                lt[i] = v1 * 255f
            }
        }

        // base-map sampling tables (base is 1/4 scale of source)
        val bx0 = IntArray(wo)
        val bxf = FloatArray(wo)
        val by0 = IntArray(ho)
        val byf = FloatArray(ho)
        val lookRt = LookRuntime(p.look, p.lookIntensity, autoEnhance(al.base, enh))

        init {
            for (x in 0 until wo) {
                val u = ((x / s) - 2f) / 4f
                val uc = u.coerceIn(0f, (al.bw - 1).toFloat())
                val i = min(al.bw - 2, uc.toInt()).coerceAtLeast(0)
                bx0[x] = i
                bxf[x] = (uc - i).coerceIn(0f, 1f)
            }
            for (y in 0 until ho) {
                val v = ((y / s) - 2f) / 4f
                val vc = v.coerceIn(0f, (al.bh - 1).toFloat())
                val i = min(al.bh - 2, vc.toInt()).coerceAtLeast(0)
                by0[y] = i
                byf[y] = (vc - i).coerceIn(0f, 1f)
            }
        }

        // ---------- native (C++) path ----------
        private var nh = 0L

        fun executeNative(out: Bitmap, status: (String) -> Unit) {
            val flags = (if (isHdr) 1 else 0) or (if (isTrails) 2 else 0) or (if (isDoc) 4 else 0) or
                (if (merge) 8 else 0) or (if (local) 16 else 0)
            val nSlots = if (isHdr || (merge && !isTrails)) n else 1
            val ci = intArrayOf(w, h, wo, ho, n, al.ref, maxNr, flags, sharpR, midR, al.bw, al.bh, nSlots)
            val cf = floatArrayOf(s, dn, sharpAmt, coreT, midAmt, detailB, lift, wbR, wbB, gain, 0f)
            val fwArr = if (al.fw.size == n) al.fw else FloatArray(n) { 1f }
            nh = NativeEngine.create(ci, cf, al.base, lookRt.toArray(), al.sigma, fwArr)
            if (nh == 0L) throw IllegalStateException("native init failed")
            try {
                var y0 = 0
                while (y0 < ho) {
                    val y1 = min(ho, y0 + hs)
                    val r0 = max(0, y0 - MG)
                    val r1 = min(ho, y1 + MG)
                    val nr = r1 - r0
                    status("Processing ${(y0 * 100L / ho).toInt()}%")
                    nativeMerge(r0, nr)
                    NativeEngine.post(nh, r0, nr)
                    NativeEngine.finish(nh, r0, y0, y1, strip)
                    out.setPixels(strip, 0, wo, 0, y0, wo, y1 - y0)
                    y0 = y1
                }
                status("Saving…")
            } finally {
                NativeEngine.destroy(nh)
                nh = 0L
            }
        }

        private fun nativeSample(f: Int, slot: Int, r0: Int, nr: Int, sc: Scratch) {
            val src = sc.src
            val dec = decs[f]
            val dxf = al.dx[f]
            val dyf = al.dy[f]
            if (s == 1f) {
                readRows(dec, r0 + dyf.roundToInt(), nr, src)
                NativeEngine.sample(nh, slot, src, nr, 0, dxf, dyf, r0, nr)
            } else {
                val invS = 1f / s
                val yTop = floor(r0 * invS + dyf).toInt() - 1
                val yBot = ceil((r0 + nr - 1) * invS + dyf).toInt() + 2
                val rows = yBot - yTop + 1
                readRows(dec, yTop, rows, src)
                NativeEngine.sample(nh, slot, src, rows, yTop, dxf, dyf, r0, nr)
            }
        }

        private fun nativeMerge(r0: Int, nr: Int) {
            when {
                isHdr -> {
                    for (f in 0 until n) nativeSample(f, f, r0, nr, scMain)
                    NativeEngine.merge(nh, 2, nr, 0)
                }
                isTrails -> {
                    for (f in 0 until n) {
                        nativeSample(f, 0, r0, nr, scMain)
                        NativeEngine.merge(nh, 3, nr, if (f == 0) 1 else 0)
                    }
                }
                merge -> {
                    val futs = ArrayList<Future<*>>(n)
                    for (f in 0 until n) {
                        futs.add(Io.pool.submit(Runnable {
                            val sc = scratchQ.take()
                            try { nativeSample(f, f, r0, nr, sc) } finally { scratchQ.put(sc) }
                        }))
                    }
                    for (fu in futs) fu.get()
                    NativeEngine.merge(nh, 1, nr, 0)
                }
                else -> {
                    nativeSample(al.ref, 0, r0, nr, scMain)
                    NativeEngine.merge(nh, 0, nr, 0)
                }
            }
        }

        fun execute(out: Bitmap, status: (String) -> Unit) {
            var y0 = 0
            while (y0 < ho) {
                val y1 = min(ho, y0 + hs)
                val r0 = max(0, y0 - MG)
                val r1 = min(ho, y1 + MG)
                val nr = r1 - r0
                status("Processing ${(y0 * 100L / ho).toInt()}%")
                when {
                    isHdr -> mergeHdr(r0, nr)
                    isTrails -> mergeMax(r0, nr)
                    merge -> mergeStack(r0, nr)
                    else -> loadSingle(r0, nr)
                }
                post(r0, nr)
                finish(r0, y0, y1)
                out.setPixels(strip, 0, wo, 0, y0, wo, y1 - y0)
                y0 = y1
            }
            status("Saving…")
        }

        // ---------- source sampling ----------
        private fun readRows(dec: BitmapRegionDecoder, yStart: Int, rows: Int, src: IntArray) {
            var vs = max(0, yStart)
            var ve = min(h, yStart + rows)
            if (ve <= vs) {
                if (yStart >= h) { vs = h - 1; ve = h } else { vs = 0; ve = 1 }
            }
            val opts = BitmapFactory.Options()
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888
            val bmp = dec.decodeRegion(Rect(0, vs, w, ve), opts) ?: return
            val hh = ve - vs
            bmp.getPixels(src, 0, w, 0, 0, w, hh)
            bmp.recycle()
            var r = rows - 1
            while (r >= 0) {
                val m = min(ve - 1, max(vs, yStart + r)) - vs
                if (m != r) System.arraycopy(src, m * w, src, r * w, w)
                r--
            }
        }

        private fun sampleStrip(f: Int, r0: Int, nr: Int, dst: IntArray, sc: Scratch) {
            val src = sc.src
            val xi0 = sc.xi0
            val xf = sc.xf
            val dec = decs[f]
            val dxf = al.dx[f]
            val dyf = al.dy[f]
            if (s == 1f) {
                val idx = dxf.roundToInt()
                val idy = dyf.roundToInt()
                readRows(dec, r0 + idy, nr, src)
                Par.rows(0, nr) { a, b ->
                    for (row in a until b) {
                        val so = row * w
                        val oo = row * wo
                        for (x in 0 until wo) {
                            var sx = x + idx
                            if (sx < 0) sx = 0 else if (sx >= w) sx = w - 1
                            dst[oo + x] = src[so + sx]
                        }
                    }
                }
            } else {
                val invS = 1f / s
                val yTop = floor(r0 * invS + dyf).toInt() - 1
                val yBot = ceil((r0 + nr - 1) * invS + dyf).toInt() + 2
                val rows = yBot - yTop + 1
                readRows(dec, yTop, rows, src)
                for (x in 0 until wo) {
                    val sx = x * invS + dxf
                    val x0 = floor(sx).toInt()
                    xi0[x] = x0
                    xf[x] = sx - x0
                }
                Par.rows(0, nr) { a, b ->
                    for (row in a until b) {
                        val sy = (r0 + row) * invS + dyf
                        val yy = floor(sy).toInt()
                        val fy = sy - yy
                        val ra = min(rows - 1, max(0, yy - yTop)) * w
                        val rb = min(rows - 1, max(0, yy + 1 - yTop)) * w
                        val oo = row * wo
                        for (x in 0 until wo) {
                            val xa = min(w - 1, max(0, xi0[x]))
                            val xb = min(w - 1, max(0, xi0[x] + 1))
                            val fx = xf[x]
                            val p00 = src[ra + xa]; val p10 = src[ra + xb]
                            val p01 = src[rb + xa]; val p11 = src[rb + xb]
                            val w00 = (1f - fx) * (1f - fy)
                            val w10 = fx * (1f - fy)
                            val w01 = (1f - fx) * fy
                            val w11 = fx * fy
                            val r = ((p00 shr 16) and 255) * w00 + ((p10 shr 16) and 255) * w10 +
                                ((p01 shr 16) and 255) * w01 + ((p11 shr 16) and 255) * w11
                            val g = ((p00 shr 8) and 255) * w00 + ((p10 shr 8) and 255) * w10 +
                                ((p01 shr 8) and 255) * w01 + ((p11 shr 8) and 255) * w11
                            val b = (p00 and 255) * w00 + (p10 and 255) * w10 +
                                (p01 and 255) * w01 + (p11 and 255) * w11
                            dst[oo + x] = (0xFF shl 24) or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt()
                        }
                    }
                }
            }
        }

        // ---------- merging ----------
        private fun loadSingle(r0: Int, nr: Int) {
            sampleStrip(al.ref, r0, nr, bufRef, scMain)
            Par.rows(0, nr) { a, b ->
                for (i in a * wo until b * wo) {
                    val px = bufRef[i]
                    rP[i] = ((px shr 16) and 255).toFloat()
                    gP[i] = ((px shr 8) and 255).toFloat()
                    bP[i] = (px and 255).toFloat()
                }
            }
        }

        private fun mergeStack(r0: Int, nr: Int) {
            val ref = al.ref
            val fb = frameBuf!!
            // decode + resample every frame of this strip in parallel
            val futs = ArrayList<Future<*>>(n)
            for (f in 0 until n) {
                futs.add(Io.pool.submit(Runnable {
                    val sc = scratchQ.take()
                    try { sampleStrip(f, r0, nr, fb[f], sc) } finally { scratchQ.put(sc) }
                }))
            }
            for (fu in futs) fu.get()
            val refBuf = fb[ref]
            Par.rows(0, nr) { a, b ->
                for (i in a * wo until b * wo) {
                    val px = refBuf[i]
                    rP[i] = ((px shr 16) and 255).toFloat()
                    gP[i] = ((px shr 8) and 255).toFloat()
                    bP[i] = (px and 255).toFloat()
                    wsP[i] = 1f
                }
            }
            for (f in 0 until n) {
                if (f == ref) continue
                val cur = fb[f]
                val fwt = if (al.fw.size == n) al.fw[f] else 1f
                val lut = luts[f]
                if (local) blockOffsets(nr, refBuf, cur)
                Par.rows(0, nr) { a, b ->
                    for (row in a until b) {
                        val ro = row * wo
                        val byo = (row / bs) * bxCount
                        for (x in 0 until wo) {
                            val i = ro + x
                            var ci = i
                            if (local) {
                                val bi = byo + x / bs
                                var yy = row + offY[bi]
                                var xx = x + offX[bi]
                                if (yy < 0) yy = 0 else if (yy >= nr) yy = nr - 1
                                if (xx < 0) xx = 0 else if (xx >= wo) xx = wo - 1
                                ci = yy * wo + xx
                            }
                            val pc = cur[ci]
                            val pr = refBuf[i]
                            val rc = (pc shr 16) and 255
                            val gc = (pc shr 8) and 255
                            val bc = pc and 255
                            val d = abs(lum(pc) - lum(pr))
                            val wt = lut[if (d > 255) 255 else d] * fwt
                            rP[i] += wt * rc
                            gP[i] += wt * gc
                            bP[i] += wt * bc
                            wsP[i] += wt
                        }
                    }
                }
            }
            Par.rows(0, nr) { a, b ->
                for (i in a * wo until b * wo) {
                    val inv = 1f / wsP[i]
                    rP[i] *= inv; gP[i] *= inv; bP[i] *= inv
                }
            }
        }

        private fun lum(p: Int): Int =
            (77 * ((p shr 16) and 255) + 150 * ((p shr 8) and 255) + 29 * (p and 255)) shr 8

        /** Per 32x32 block extra shift (-3..3) of the current frame vs. the reference (local alignment). */
        private fun blockOffsets(nr: Int, bufRef: IntArray, bufCur: IntArray) {
            val byCount = (nr + bs - 1) / bs
            Par.rows(0, byCount) { a, b ->
                for (by in a until b) {
                    for (bx in 0 until bxCount) {
                        val x0 = bx * bs
                        val y0 = by * bs
                        var best = Int.MAX_VALUE
                        var bo = 0
                        var bp = 0
                        for (oy in -3..3) {
                            for (ox in -3..3) {
                                var sad = (abs(ox) + abs(oy)) * 8
                                var yy = y0 + 2
                                while (yy < y0 + bs && yy < nr) {
                                    var xx = x0 + 2
                                    while (xx < x0 + bs && xx < wo) {
                                        val pr = bufRef[yy * wo + xx]
                                        var cy = yy + oy
                                        if (cy < 0) cy = 0 else if (cy >= nr) cy = nr - 1
                                        var cx = xx + ox
                                        if (cx < 0) cx = 0 else if (cx >= wo) cx = wo - 1
                                        sad += abs(lum(pr) - lum(bufCur[cy * wo + cx]))
                                        xx += 4
                                    }
                                    yy += 4
                                }
                                if (sad < best) { best = sad; bo = ox; bp = oy }
                            }
                        }
                        offX[by * bxCount + bx] = bo.toByte()
                        offY[by * bxCount + bx] = bp.toByte()
                    }
                }
            }
        }

        /** Star trails: lighten blend (per-channel maximum). */
        private fun mergeMax(r0: Int, nr: Int) {
            sampleStrip(0, r0, nr, bufRef, scMain)
            Par.rows(0, nr) { a, b ->
                for (i in a * wo until b * wo) {
                    val px = bufRef[i]
                    rP[i] = ((px shr 16) and 255).toFloat()
                    gP[i] = ((px shr 8) and 255).toFloat()
                    bP[i] = (px and 255).toFloat()
                }
            }
            for (f in 1 until n) {
                sampleStrip(f, r0, nr, bufCur, scMain)
                Par.rows(0, nr) { a, b ->
                    for (i in a * wo until b * wo) {
                        val px = bufCur[i]
                        val r = ((px shr 16) and 255).toFloat()
                        val g = ((px shr 8) and 255).toFloat()
                        val bl = (px and 255).toFloat()
                        if (r > rP[i]) rP[i] = r
                        if (g > gP[i]) gP[i] = g
                        if (bl > bP[i]) bP[i] = bl
                    }
                }
            }
        }

        private fun mergeHdr(r0: Int, nr: Int) {
            val bufs = hdrBuf!!
            val ws = hdrW!!
            for (f in 0 until n) {
                sampleStrip(f, r0, nr, bufs[f], scMain)
                val bf = bufs[f]
                val wf = ws[f]
                Par.rows(0, nr) { a, b ->
                    for (i in a * wo until b * wo) {
                        val px = bf[i]
                        val r = ((px shr 16) and 255)
                        val g = ((px shr 8) and 255)
                        val bl = (px and 255)
                        val lum = (0.299f * r + 0.587f * g + 0.114f * bl) / 255f
                        val d = lum - 0.5f
                        val we = exp(-d * d * 12.5f)
                        val sat = (max(r, max(g, bl)) - min(r, min(g, bl))) / 255f
                        wf[i] = we * (0.15f + sat) + 1e-4f
                    }
                }
                boxBlur(wf, wf, t1, wo, nr, 5)
            }
            Par.rows(0, nr) { a, b ->
                for (i in a * wo until b * wo) {
                    var sr = 0f; var sg = 0f; var sb = 0f; var sw = 0f
                    for (f in 0 until n) {
                        val px = bufs[f][i]
                        val wt = ws[f][i]
                        sr += wt * ((px shr 16) and 255)
                        sg += wt * ((px shr 8) and 255)
                        sb += wt * (px and 255)
                        sw += wt
                    }
                    val inv = 1f / sw
                    rP[i] = sr * inv; gP[i] = sg * inv; bP[i] = sb * inv
                }
            }
        }

        // ---------- post processing ----------
        private fun shoulder(v: Float): Float {
            if (v <= 0f) return 0f
            if (v < 232f) return v
            val x = (v - 232f) / 23f
            return 232f + 23f * (x / (1f + x))
        }

        private fun bilateral(srcA: FloatArray, dst: FloatArray, nr: Int) {
            val inv = 1f / (bilSigma * bilSigma)
            val w = wo
            Par.rows(0, nr) { a, b ->
                for (y in a until b) {
                    val o = y * w
                    if (y == 0 || y == nr - 1) {
                        System.arraycopy(srcA, o, dst, o, w)
                        continue
                    }
                    dst[o] = srcA[o]
                    dst[o + w - 1] = srcA[o + w - 1]
                    for (x in 1 until w - 1) {
                        val i = o + x
                        val c = srcA[i]
                        var acc = c * 4f
                        var ws = 4f
                        var v = srcA[i - 1]; var d = v - c; var wt = 2f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i + 1]; d = v - c; wt = 2f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i - w]; d = v - c; wt = 2f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i + w]; d = v - c; wt = 2f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i - w - 1]; d = v - c; wt = 1f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i - w + 1]; d = v - c; wt = 1f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i + w - 1]; d = v - c; wt = 1f / (1f + d * d * inv); acc += v * wt; ws += wt
                        v = srcA[i + w + 1]; d = v - c; wt = 1f / (1f + d * d * inv); acc += v * wt; ws += wt
                        dst[i] = acc / ws
                    }
                }
            }
        }

        /** Immerkaer noise estimate on flat-ish blocks (luma, 0..255 scale). */
        private fun estimateNoise(yv: FloatArray, w: Int, nr: Int): Float {
            val bsz = 16
            val bxn = w / bsz
            val byn = nr / bsz
            if (bxn < 2 || byn < 2) return 4f
            val stepB = max(1, (bxn * byn) / 600)
            val vals = FloatArray(bxn * byn / stepB + 2)
            var cntV = 0
            var idx = 0
            for (by in 0 until byn) {
                for (bx in 0 until bxn) {
                    idx++
                    if (idx % stepB != 0) continue
                    val x0 = bx * bsz
                    val y0 = by * bsz
                    var acc = 0f
                    var cnt = 0
                    for (y in y0 + 1 until y0 + bsz - 1) {
                        val o = y * w
                        for (x in x0 + 1 until x0 + bsz - 1) {
                            val i = o + x
                            val v = 4f * yv[i] - 2f * (yv[i - 1] + yv[i + 1] + yv[i - w] + yv[i + w]) +
                                (yv[i - w - 1] + yv[i - w + 1] + yv[i + w - 1] + yv[i + w + 1])
                            acc += abs(v)
                            cnt++
                        }
                    }
                    if (cnt > 0 && cntV < vals.size) { vals[cntV] = acc / cnt * 0.20888f; cntV++ }
                }
            }
            if (cntV == 0) return 4f
            java.util.Arrays.sort(vals, 0, cntV)
            val v = vals[(cntV * 0.2f).toInt().coerceIn(0, cntV - 1)]
            return (v * 1.15f).coerceIn(1.2f, 30f)
        }

        /** Edge-preserving 12-tap denoise; range weights come from a pre-smoothed guide and scale with the noise level (stronger in shadows). */
        private fun bilateralWide(srcA: FloatArray, guide: FloatArray, dst: FloatArray, nr: Int, st: Int, sigR: Float) {
            val w = wo
            val invBase = 1f / (sigR * sigR)
            val m = 2 * st
            val offs = intArrayOf(-st, st, -st * w, st * w, -st * w - st, -st * w + st, st * w - st, st * w + st, -2 * st, 2 * st, -2 * st * w, 2 * st * w)
            val wsp = floatArrayOf(1f, 1f, 1f, 1f, 0.7f, 0.7f, 0.7f, 0.7f, 0.5f, 0.5f, 0.5f, 0.5f)
            Par.rows(0, nr) { a, b ->
                for (y in a until b) {
                    val o = y * w
                    if (y < m || y >= nr - m || w <= 2 * m) {
                        System.arraycopy(srcA, o, dst, o, w)
                        continue
                    }
                    for (x in 0 until m) dst[o + x] = srcA[o + x]
                    for (x in w - m until w) dst[o + x] = srcA[o + x]
                    for (x in m until w - m) {
                        val i = o + x
                        val c = guide[i]
                        var dk = 1f - c * (1f / 255f)
                        if (dk < 0f) dk = 0f else if (dk > 1f) dk = 1f
                        val f = 1f + 1.4f * dk * dk
                        val inv = invBase / (f * f)
                        var acc = srcA[i] * 2f
                        var wsum = 2f
                        for (k in 0 until 12) {
                            val j = i + offs[k]
                            val d = guide[j] - c
                            val wt = wsp[k] / (1f + d * d * inv)
                            acc += srcA[j] * wt
                            wsum += wt
                        }
                        dst[i] = acc / wsum
                    }
                }
            }
        }

        private fun post(r0: Int, nr: Int) {
            val w = wo
            // 1) luma / chroma split
            Par.rows(0, nr) { a, b ->
                for (i in a * w until b * w) {
                    val r = rP[i]; val g = gP[i]; val bl = bP[i]
                    val yv = 0.299f * r + 0.587f * g + 0.114f * bl
                    yP[i] = yv
                    cbP[i] = bl - yv
                    crP[i] = r - yv
                }
            }
            // 2) denoise (noise-adaptive, then re-inject real detail above the noise floor)
            if (noiseSigma < 0f) noiseSigma = estimateNoise(yP, w, nr)
            val ns = noiseSigma
            var yArr = yP
            var cbF = cbP
            var crF = crP
            if (dn >= 0.05f) {
                val sigR = ns * (1.1f + 2.4f * dn)
                val heavy = ns >= 4f          // clean scenes (daylight / well-merged) take the cheap path
                boxBlur(yP, wsP, t1, w, nr, 1)
                bilateralWide(yP, wsP, t1, nr, 1, sigR)
                var dS = t1
                if (heavy) {
                    boxBlur(t1, wsP, gP, w, nr, 1)
                    bilateralWide(t1, wsP, rP, nr, 2, sigR * 1.15f)   // rP = denoised luma
                    dS = rP
                }
                val th = ns * 1.4f
                val th2 = th * th + 1e-6f
                val keep = 0.18f + 0.22f * (1f - min(1f, dn))
                val dSf = dS
                Par.rows(0, nr) { a, b ->
                    for (i in a * w until b * w) {
                        val d2 = dSf[i]
                        val r = yP[i] - d2
                        val k = r * r / (r * r + th2)
                        t1[i] = d2 + r * (keep + (1f - keep) * k)
                    }
                }
                yArr = t1
                // chroma: luma-guided wide bilateral (no colour bleeding over edges)
                val sc2 = ns * (2.5f + 3f * dn)
                val stc = if (s > 1f) 3 else 2
                val guide = dSf
                if (heavy) {
                    bilateralWide(cbP, guide, gP, nr, stc, sc2)
                    bilateralWide(gP, guide, bP, nr, stc * 2, sc2 * 1.2f)
                    bilateralWide(crP, guide, yP, nr, stc, sc2)
                    bilateralWide(yP, guide, wsP, nr, stc * 2, sc2 * 1.2f)
                    val br = (ns * 0.25f * (if (s > 1f) s else 1f)).roundToInt().coerceIn(1, 6)
                    boxBlur(bP, bP, gP, w, nr, br)
                    boxBlur(wsP, wsP, yP, w, nr, br)
                } else {
                    bilateralWide(cbP, guide, bP, nr, stc, sc2)
                    bilateralWide(crP, guide, wsP, nr, stc, sc2)
                }
                cbF = bP
                crF = wsP
            }
            // noise-aware tone/detail strength: don't boost what is mostly noise
            val nk = 1f / (1f + ns / 8f)
            val detB = 1f + (detailB - 1f) * nk
            val midA = midAmt * (0.5f + 0.5f * nk)
            val coreFine = max(coreT, ns * 1.2f)
            val scMax = 2.2f + 3.8f / (1f + ns / 10f)
            val nsq = ns * 0.04f
            val cbFin = cbF
            val crFin = crF
            Par.rows(0, nr) { a, b ->
                for (i in a * w until b * w) {
                    val yv = yArr[i]
                    val r = yv + crFin[i]
                    val bl = yv + cbFin[i]
                    val g = (yv - 0.299f * r - 0.114f * bl) / 0.587f
                    rP[i] = r; gP[i] = g; bP[i] = bl
                }
            }
            // 3) local tone mapping (shadow lift, highlight roll-off, local contrast)
            val bw = al.bw
            val base = al.base
            Par.rows(0, nr) { a, b ->
                for (row in a until b) {
                    val yy = r0 + row
                    val ya = by0[yy]
                    val fy = byf[yy]
                    val oa = ya * bw
                    val ob = (ya + 1) * bw
                    val o = row * w
                    for (x in 0 until w) {
                        val i = o + x
                        val xa = bx0[x]
                        val fx = bxf[x]
                        val top = base[oa + xa] * (1f - fx) + base[oa + xa + 1] * fx
                        val bot = base[ob + xa] * (1f - fx) + base[ob + xa + 1] * fx
                        val bsv = top * (1f - fy) + bot * fy

                        val r1 = rP[i] * wbR
                        val g1 = gP[i]
                        val b1 = bP[i] * wbB
                        val yv = 0.299f * r1 + 0.587f * g1 + 0.114f * b1

                        var ti = bsv / 255f * 1023f
                        if (ti < 0f) ti = 0f else if (ti > 1022.99f) ti = 1022.99f
                        val i0 = ti.toInt()
                        val nb = toneLut[i0] + (toneLut[i0 + 1] - toneLut[i0]) * (ti - i0)

                        val newY: Float
                        if (isDoc) {
                            var v = (yv + 3f) / (bsv + 3f) * 246f
                            if (v > 255f) v = 255f
                            val xx = v / 255f
                            newY = xx * xx * (3f - 2f * xx) * 255f
                        } else {
                            var ratio = (yv + 3f) / (bsv + 3f)
                            if (ratio < 0.15f) ratio = 0.15f else if (ratio > 6f) ratio = 6f
                            val dr = if (detB == 1f) ratio else ratio.pow(detB)
                            newY = (nb + 3f) * dr - 3f
                        }
                        var sc = (newY + 3f) / (yv + 3f)
                        if (sc < 0.25f) sc = 0.25f else if (sc > scMax) sc = scMax
                        wsP[i] = sc

                        val rs = r1 * sc
                        val gs = g1 * sc
                        val bs2 = b1 * sc
                        val ys = 0.299f * rs + 0.587f * gs + 0.114f * bs2
                        val sk = 1f / (1f + nsq * (if (sc > 1f) sc - 1f else 0f))
                        val r2 = shoulder(ys + (rs - ys) * sk)
                        val g2 = shoulder(ys + (gs - ys) * sk)
                        val b2 = shoulder(ys + (bs2 - ys) * sk)
                        rP[i] = r2; gP[i] = g2; bP[i] = b2
                        yP[i] = 0.299f * r2 + 0.587f * g2 + 0.114f * b2
                    }
                }
            }
            // 4) detail + sharpen (with coring so noise is not sharpened)
            blurTwice(yP, t1, cbP, w, nr, sharpR)
            blurTwice(yP, crP, cbP, w, nr, midR)
            Par.rows(0, nr) { a, b ->
                for (i in a * w until b * w) {
                    val y = yP[i]
                    val df = y - t1[i]
                    val dm = y - crP[i]
                    val scl = wsP[i]
                    val th = coreFine * (if (scl > 1f) scl else 1f)
                    val tF = th * th
                    val tM = tF * 6.25f
                    val cf = df * df / (df * df + tF)
                    val cm = dm * dm / (dm * dm + tM)
                    val add = sharpAmt * df * cf + midA * dm * cm
                    rP[i] += add; gP[i] += add; bP[i] += add
                }
            }
        }

        private fun finish(r0: Int, y0: Int, y1: Int) {
            val w = wo
            Par.rows(y0, y1) { a, b ->
                for (y in a until b) {
                    val o = (y - r0) * w
                    val so = (y - y0) * w
                    for (x in 0 until w) {
                        val i = o + x
                        strip[so + x] = lookRt.apply(rP[i], gP[i], bP[i], x, y, w, ho)
                    }
                }
            }
        }
    }
}

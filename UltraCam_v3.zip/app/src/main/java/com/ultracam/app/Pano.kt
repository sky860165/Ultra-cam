package com.ultracam.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Simple translation-based panorama stitcher (half-resolution, feathered seams). */
object Pano {

    private fun nccOv(a: Small, b: Small, dx: Int, dy: Int, step: Int): Double {
        val w = a.w
        val h = a.h
        val x0 = max(0, -dx)
        val x1 = min(w, w - dx)
        val y0 = max(0, -dy)
        val y1 = min(h, h - dy)
        if (x1 - x0 < w / 4 || y1 - y0 < h / 2) return -2.0
        var sa = 0.0; var sb = 0.0; var saa = 0.0; var sbb = 0.0; var sab = 0.0
        var n = 0
        var y = y0
        while (y < y1) {
            val ra = y * w
            val rb = (y + dy) * w + dx
            var x = x0
            while (x < x1) {
                val p = a.g[ra + x].toDouble()
                val q = b.g[rb + x].toDouble()
                sa += p; sb += q; saa += p * p; sbb += q * q; sab += p * q
                n++
                x += step
            }
            y += step
        }
        val num = n * sab - sa * sb
        val den = sqrt(max(1e-9, (n * saa - sa * sa) * (n * sbb - sb * sb)))
        return num / den
    }

    private fun best(a: Small, b: Small, cx: Int, cy: Int, rx: Int, ry: Int, step: Int): IntArray {
        var bs = -2.0
        var bx = cx
        var by = cy
        for (dy in cy - ry..cy + ry) {
            for (dx in cx - rx..cx + rx) {
                val s = nccOv(a, b, dx, dy, step)
                if (s > bs) { bs = s; bx = dx; by = dy }
            }
        }
        return intArrayOf(bx, by)
    }

    /** b(x+dx, y+dy) ~ a(x, y), in half-resolution pixel units. */
    private fun pairShift(pa: String, pb: String): IntArray {
        val a16 = Align.decodeSmall(pa, 16)
        val b16 = Align.decodeSmall(pb, 16)
        val s16 = best(a16, b16, 0, 0, a16.w / 2, max(3, a16.h / 6), 2)
        val a4 = Align.decodeSmall(pa, 4)
        val b4 = Align.decodeSmall(pb, 4)
        val s4 = best(a4, b4, s16[0] * 4, s16[1] * 4, 5, 5, 2)
        val a2 = Align.decodeSmall(pa, 2)
        val b2 = Align.decodeSmall(pb, 2)
        return best(a2, b2, s4[0] * 2, s4[1] * 2, 4, 4, 3)
    }

    private fun blend(old: Int, nw: Int, a: Float): Int {
        val r = (((old shr 16) and 255) * (1f - a) + ((nw shr 16) and 255) * a).toInt()
        val g = (((old shr 8) and 255) * (1f - a) + ((nw shr 8) and 255) * a).toInt()
        val b = ((old and 255) * (1f - a) + (nw and 255) * a).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun stitch(paths: List<String>, status: (String) -> Unit): Bitmap {
        val n = paths.size
        val ox = IntArray(n)
        val oy = IntArray(n)
        for (i in 1 until n) {
            status("Pano align $i/${n - 1}")
            val s = pairShift(paths[i - 1], paths[i])
            ox[i] = ox[i - 1] - s[0]
            oy[i] = oy[i - 1] - s[1]
        }
        val o = BitmapFactory.Options()
        o.inSampleSize = 2
        o.inPreferredConfig = Bitmap.Config.ARGB_8888
        val first = BitmapFactory.decodeFile(paths[0], o) ?: throw IllegalStateException("pano decode")
        val fw = first.width
        val fh = first.height
        val minX = ox.minOrNull() ?: 0
        val minY = oy.minOrNull() ?: 0
        val cx = IntArray(n) { ox[it] - minX }
        val cy = IntArray(n) { oy[it] - minY }
        val maxCx = cx.maxOrNull() ?: 0
        val maxCy = cy.maxOrNull() ?: 0
        val horiz = abs(ox[n - 1]) >= abs(oy[n - 1])
        var cropX0 = 0
        var cropY0 = 0
        var cropW = maxCx + fw
        var cropH = maxCy + fh
        if (horiz) {
            cropY0 = maxCy
            cropH = (cy.minOrNull() ?: 0) + fh - cropY0
        } else {
            cropX0 = maxCx
            cropW = (cx.minOrNull() ?: 0) + fw - cropX0
        }
        if (cropW < 16 || cropH < 16) throw IllegalStateException("pano too small")
        if (cropW.toLong() * cropH > 70_000_000L) throw IllegalStateException("pano too large")
        val out = Bitmap.createBitmap(cropW, cropH, Bitmap.Config.ARGB_8888)

        for (i in 0 until n) {
            status("Pano blend ${i + 1}/$n")
            val bmp = if (i == 0) first else (BitmapFactory.decodeFile(paths[i], o) ?: continue)
            val px = IntArray(fw * fh)
            bmp.getPixels(px, 0, fw, 0, 0, fw, fh)
            bmp.recycle()
            val rx0 = max(0, cx[i] - cropX0)
            val ry0 = max(0, cy[i] - cropY0)
            val rx1 = min(cropW, cx[i] - cropX0 + fw)
            val ry1 = min(cropH, cy[i] - cropY0 + fh)
            val rw = rx1 - rx0
            val rh = ry1 - ry0
            if (rw <= 0 || rh <= 0) continue
            val ex = IntArray(rw * rh)
            out.getPixels(ex, 0, rw, rx0, ry0, rw, rh)
            var ov = 0
            var dir = 1
            if (i > 0) {
                if (horiz) {
                    dir = if (cx[i] >= cx[i - 1]) 1 else -1
                    ov = if (dir > 0) cx[i - 1] + fw - cx[i] else cx[i] + fw - cx[i - 1]
                } else {
                    dir = if (cy[i] >= cy[i - 1]) 1 else -1
                    ov = if (dir > 0) cy[i - 1] + fh - cy[i] else cy[i] + fh - cy[i - 1]
                }
            }
            for (y in 0 until rh) {
                val sy = ry0 + y - (cy[i] - cropY0)
                for (x in 0 until rw) {
                    val sx = rx0 + x - (cx[i] - cropX0)
                    val np = px[sy * fw + sx]
                    val idx = y * rw + x
                    val old = ex[idx]
                    var a = 1f
                    if (old != 0 && ov > 0) {
                        val t = if (horiz) (if (dir > 0) sx else fw - 1 - sx) else (if (dir > 0) sy else fh - 1 - sy)
                        a = min(1f, t.toFloat() / ov)
                    }
                    ex[idx] = if (a >= 1f) np else blend(old, np, a)
                }
            }
            out.setPixels(ex, 0, rw, rx0, ry0, rw, rh)
        }
        return out
    }
}

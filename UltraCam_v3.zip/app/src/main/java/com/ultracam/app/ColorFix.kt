package com.ultracam.app

import android.graphics.Bitmap
import android.util.Log
import kotlin.math.max
import kotlin.math.min
import kotlin.math.ln
import kotlin.math.pow

/**
 * Selfie colour-cast fix (screen flash / warm room light -> yellow face).
 *  1) neutral-pixel white balance: near-grey pixels (wall, pillow, headboard, clothes stripes) vote for the cast
 *  2) skin-hue guard: if skin sits too far towards yellow, nudge blue up / green down (small, clamped)
 * Gains are luma-normalised (brightness stays the same) and applied with one LUT per channel on the whole photo,
 * so face and background always stay consistent.
 */
object ColorFix {
    private const val TAG = "UltraCamColorFix"

    // measured from a Google Camera shot of the same face on the same phone: hue ~21, G/R 0.79, B/R 0.675, face luma ~140
    private const val SKIN_HUE_OK = 26f       // above this the skin is treated as yellow-cast
    private const val SKIN_GR = 0.79f
    private const val SKIN_BR = 0.675f
    private const val SKIN_LUMA_TARGET = 150f

    /** strength 0..1. Returns true if something was changed. */
    fun apply(bmp: Bitmap, strength: Float): Boolean {
        if (strength <= 0.01f || !bmp.isMutable) return false
        val w = bmp.width
        val h = bmp.height
        // ---- statistics on a small copy
        val sc = min(1f, 480f / max(w, h))
        val sw = max(8, (w * sc).toInt())
        val sh = max(8, (h * sc).toInt())
        val small = Bitmap.createScaledBitmap(bmp, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (small !== bmp) small.recycle()

        var nR = 0.0; var nG = 0.0; var nB = 0.0; var nCnt = 0
        var skinHueSum = 0.0; var skinCnt = 0
        var skinR = 0.0; var skinG = 0.0; var skinB = 0.0; var skinL = 0.0
        for (y in 0 until sh) {
            for (x in 0 until sw) {
                val p = px[y * sw + x]
                val r = ((p shr 16) and 255).toFloat()
                val g = ((p shr 8) and 255).toFloat()
                val b = (p and 255).toFloat()
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val luma = 0.299f * r + 0.587f * g + 0.114f * b
                if (luma < 40f || luma > 235f) continue
                val sat = (mx - mn) / (mx + 1f)
                // near-neutral pixels (not clipped): cast voters
                if (sat < 0.30f && mx < 245f) {
                    nR += r; nG += g; nB += b; nCnt++
                }
                // skin-like pixels in the central 70% of the frame
                if (x > sw * 0.15f && x < sw * 0.85f && y > sh * 0.10f && y < sh * 0.80f &&
                    r > g && g > b && sat in 0.22f..0.72f && luma in 55f..225f) {
                    val hue = hueDeg(r, g, b)
                    if (hue in 8f..60f) {
                        skinHueSum += hue; skinCnt++
                        skinR += r; skinG += g; skinB += b; skinL += luma
                    }
                }
            }
        }
        val total = sw * sh
        var gR = 1f; var gG = 1f; var gB = 1f
        var wR = 1f; var wB = 1f   // global (neutral-WB only) gains

        // ---- 1) neutral-pixel white balance (only when enough neutral area exists)
        if (nCnt > total * 0.03f) {
            val mr = (nR / nCnt).toFloat(); val mg = (nG / nCnt).toFloat(); val mb = (nB / nCnt).toFloat()
            if (mr > 1f && mg > 1f && mb > 1f) {
                val k = 0.75f * strength            // do not fully neutralise: keep the warm room mood
                gR = ((mg / mr) - 1f) * k + 1f
                gB = ((mg / mb) - 1f) * k + 1f
                gR = gR.coerceIn(0.88f, 1.12f)
                gB = gB.coerceIn(0.88f, 1.22f)
                wR = gR; wB = gB
            }
        }

        // ---- 2) skin guard: yellow cast -> move skin ratios towards the natural target; blown face -> pull tones down
        var skinHue = -1f
        var gamma = 1f
        if (skinCnt > total * 0.015f) {
            skinHue = (skinHueSum / skinCnt).toFloat()
            val r2 = (skinR / skinCnt).toFloat() * gR
            val g2 = (skinG / skinCnt).toFloat() * gG
            val b2 = (skinB / skinCnt).toFloat() * gB
            val hue2 = hueDeg(r2, g2, b2)
            if (hue2 > SKIN_HUE_OK && r2 > 1f && g2 > 1f && b2 > 1f) {
                val k = ((hue2 - SKIN_HUE_OK) / 8f).coerceIn(0f, 1f) * strength
                gG *= 1f + ((SKIN_GR * r2) / g2 - 1f) * k
                gB *= 1f + ((SKIN_BR * r2) / b2 - 1f) * k
                gG = gG.coerceIn(0.85f, 1.05f)
                gB = gB.coerceIn(0.95f, 1.40f)
            }
            val sl = (skinL / skinCnt).toFloat()
            if (sl > SKIN_LUMA_TARGET + 15f) {
                val raw = (ln(SKIN_LUMA_TARGET / 255f) / ln(sl / 255f)).coerceIn(1f, 1.6f)
                gamma = 1f + (raw - 1f) * strength
            }
        }

        // ---- keep brightness: normalise gains by luma
        val ln = 0.299f * gR + 0.587f * gG + 0.114f * gB
        gR /= ln; gG /= ln; gB /= ln
        val wl = 0.299f * wR + 0.587f * 1f + 0.114f * wB
        wR /= wl; val wG = 1f / wl; wB /= wl
        Log.i(TAG, "neutral=$nCnt/$total skinHue=$skinHue skin gains R=$gR G=$gG B=$gB gamma=$gamma | global R=$wR B=$wB")
        if (kotlin.math.abs(gR - 1f) < 0.01f && kotlin.math.abs(gG - 1f) < 0.01f && kotlin.math.abs(gB - 1f) < 0.01f && gamma < 1.02f) return false

        // ---- apply: skin-like pixels get the full skin fix, everything else only the mild global WB
        val sr = lut(gR, gamma); val sg = lut(gG, gamma); val sb = lut(gB, gamma)
        val ar = lut(wR, 1f); val ag = lut(wG, 1f); val ab = lut(wB, 1f)
        val rows = 256
        val buf = IntArray(w * rows)
        var y0 = 0
        while (y0 < h) {
            val n = min(rows, h - y0)
            bmp.getPixels(buf, 0, w, 0, y0, w, n)
            for (i in 0 until w * n) {
                val p = buf[i]
                val r0 = (p shr 16) and 255
                val g0 = (p shr 8) and 255
                val b0 = p and 255
                var wt = 0f
                if (r0 > 40 && r0 > g0 && g0 > b0) {
                    val gr = g0 / r0.toFloat()
                    val bg = b0 / max(1, g0).toFloat()
                    wt = ramp(gr, 0.55f, 0.65f, 0.93f, 0.98f) * ramp(bg, 0.40f, 0.50f, 0.95f, 1.0f)
                }
                val r = (ar[r0] + (sr[r0] - ar[r0]) * wt).toInt()
                val g = (ag[g0] + (sg[g0] - ag[g0]) * wt).toInt()
                val b = (ab[b0] + (sb[b0] - ab[b0]) * wt).toInt()
                buf[i] = (p and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b
            }
            bmp.setPixels(buf, 0, w, 0, y0, w, n)
            y0 += n
        }
        return true
    }

    /** trapezoid: 0 below a, up to 1 at b, 1 until c, down to 0 at d */
    private fun ramp(x: Float, a: Float, b: Float, c: Float, d: Float): Float =
        if (x <= a || x >= d) 0f else if (x < b) (x - a) / (b - a) else if (x <= c) 1f else (d - x) / (d - c)

    /** gain with a soft shoulder near white (no clipping step, highlights stay white) */
    private fun lut(gain: Float, gamma: Float): IntArray {
        val t = IntArray(256)
        for (i in 0..255) {
            val v = i / 255f
            val shoulder = ((v - 0.80f) / 0.20f).coerceIn(0f, 1f)
            val gg = 1f + (gain - 1f) * (1f - shoulder * shoulder)
            t[i] = ((v * gg).coerceIn(0f, 1f).pow(gamma) * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        return t
    }

    private fun hueDeg(r: Float, g: Float, b: Float): Float {
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = mx - mn
        if (d < 1e-3f) return 0f
        var hh = when (mx) {
            r -> ((g - b) / d) % 6f
            g -> (b - r) / d + 2f
            else -> (r - g) / d + 4f
        }
        hh *= 60f
        if (hh < 0f) hh += 360f
        return hh
    }
}

package com.ultracam.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import kotlinx.coroutines.Job
import kotlin.math.sqrt
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

private const val TAG = "UltraCam"
private val ACCENT: Int = Color.parseColor("#00E5FF")

private class LiveMeta {
    @Volatile var iso: Int = 0
    @Volatile var expNs: Long = 0L
}

private class GridView(ctx: Context) : View(ctx) {
    private val p = Paint().apply {
        color = 0x66FFFFFF
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
        }
    }
}

private class ShutterView(ctx: Context) : View(ctx) {
    private val ring = Paint().apply { color = Color.WHITE; style = Paint.Style.STROKE; isAntiAlias = true }
    private val fill = Paint().apply { isAntiAlias = true }
    var video: Boolean = false
        set(v) { field = v; invalidate() }
    var recording: Boolean = false
        set(v) { field = v; invalidate() }
    var busy: Boolean = false
        set(v) { field = v; invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy)
        ring.strokeWidth = r * 0.09f
        canvas.drawCircle(cx, cy, r * 0.90f, ring)
        fill.color = if (video) 0xFFE53935.toInt() else if (busy) 0xFFFFC107.toInt() else Color.WHITE
        if (recording) {
            val s = r * 0.42f
            canvas.drawRoundRect(RectF(cx - s, cy - s, cx + s, cy + s), 12f, 12f, fill)
        } else {
            canvas.drawCircle(cx, cy, r * 0.72f, fill)
        }
    }
}

@ExperimentalCamera2Interop
class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String) {
        AUTO("AUTO"), ULTRA("ULTRA"), NIGHT("NIGHT"), HDR("HDR"), PORTRAIT("PORTRAIT"), PRO("PRO"),
        ASTRO("ASTRO"), TRAILS("TRAILS"), PANO("PANO"), SCAN("SCAN"), LAPSE("LAPSE"), VIDEO("VIDEO")
    }

    private lateinit var prefs: Prefs
    private lateinit var previewView: PreviewView
    private lateinit var statusTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var zoomTv: TextView
    private lateinit var focusRing: View
    private lateinit var gridView: GridView
    private lateinit var thumb: ImageView
    private lateinit var busyTv: TextView
    private lateinit var shutter: ShutterView
    private lateinit var flashBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var looksPanel: LinearLayout
    private lateinit var proPanel: LinearLayout
    private lateinit var videoPanel: LinearLayout
    private val modePills = HashMap<Mode, TextView>()
    private val lookPills = HashMap<String, TextView>()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var tuner: CameraTuner? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var mode = Mode.AUTO
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var looksVisible = true
    private var boundCapRes = -1
    private var boundFast = false
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var lastTapMs = 0L
    private var lensId: String? = null
    private lateinit var analyzer: AnalyzerView
    private lateinit var suggestionTv: TextView
    private lateinit var portraitPanel: LinearLayout
    private lateinit var lapsePanel: LinearLayout
    private lateinit var sensorManager: SensorManager
    private var lapseJob: Job? = null
    private var panoJob: Job? = null
    private var panoStop = false
    private var suggestMode: Mode? = null
    private var suggestTicks = 0
    private var smoothLevel = 0f

    private lateinit var cameraExecutor: ExecutorService
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val procMutex = Mutex()
    private var pendingJobs = 0
    private var shooting = false
    private var lastUri: Uri? = null
    private val ui = Handler(Looper.getMainLooper())
    private val meta = LiveMeta()

    // PRO state
    private var proManualAE = false
    private var proIso = 35
    private var proShut = 50
    private var proManualAF = false
    private var proFocus = 0
    private var proAwb: Int? = null

    private val previewCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult
        ) {
            result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { meta.iso = it }
            result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { meta.expNs = it }
        }
    }

    private val infoTicker = object : Runnable {
        override fun run() {
            val iso = meta.iso
            val e = meta.expNs
            infoTv.text = if (iso > 0 && e > 0) "ISO $iso   ${fmtShutter(e)}   ${mode.label}" else mode.label
            ui.postDelayed(this, 500)
        }
    }

    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                val rot = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                imageCapture?.targetRotation = rot
                videoCapture?.targetRotation = rot
            }
        }
    }

    private val analysisTicker = object : Runnable {
        override fun run() {
            try { analyzeFrame() } catch (e: Throwable) { Log.w(TAG, "analyze", e) }
            ui.postDelayed(this, 900)
        }
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val deg = Math.toDegrees(Math.atan2(event.values[0].toDouble(), event.values[1].toDouble())).toFloat()
            smoothLevel += (deg - smoothLevel) * 0.2f
            analyzer.levelDeg = smoothLevel
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    // ===================================================================== lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = Prefs(this)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buildUi()
        if (hasCameraPermission()) startCamera() else requestPerms()
        if (Build.VERSION.SDK_INT >= 33 && hasCameraPermission() &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    override fun onResume() {
        super.onResume()
        orientationListener.enable()
        ui.post(infoTicker)
        ui.postDelayed(analysisTicker, 1500)
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(sensorListener, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        orientationListener.disable()
        ui.removeCallbacks(infoTicker)
        ui.removeCallbacks(analysisTicker)
        sensorManager.unregisterListener(sensorListener)
        recording?.stop()
        recording = null
        if (::shutter.isInitialized) shutter.recording = false
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        scope.cancel()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event?.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, list.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 10) return
        if (hasCameraPermission()) startCamera() else toast("Camera permission chahiye")
    }

    // ===================================================================== helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

    private fun fmtShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/${(1.0 / s).roundToInt()}"
    }

    private fun txt(text: String, sizeSp: Float = 13f, color: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        return t
    }

    private fun styleSel(v: TextView, sel: Boolean) {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(if (sel) ACCENT else 0x33FFFFFF)
        v.background = bg
        v.setTextColor(if (sel) Color.BLACK else Color.WHITE)
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = txt(text, 12f)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(6), dp(12), dp(6))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(3), dp(2), dp(3), dp(2))
        t.layoutParams = lp
        styleSel(t, false)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun hscroll(row: LinearLayout): HorizontalScrollView {
        val sv = HorizontalScrollView(this)
        sv.isHorizontalScrollBarEnabled = false
        sv.addView(row)
        return sv
    }

    private fun hrow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun vcol(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        return r
    }

    private fun sliderRow(
        title: String, max: Int, init: Int, fmt: (Int) -> String, onChange: (Int) -> Unit
    ): LinearLayout {
        val row = hrow()
        row.setPadding(dp(8), dp(2), dp(8), dp(2))
        val t = txt(title, 12f)
        t.layoutParams = LinearLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT)
        val v = txt(fmt(init), 12f, ACCENT)
        v.gravity = Gravity.END
        v.layoutParams = LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT)
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = init
        sb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                v.text = fmt(progress)
                if (fromUser) onChange(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        row.addView(t); row.addView(sb); row.addView(v)
        return row
    }

    // ===================================================================== UI
    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        // ---- top bar
        val top = hrow()
        top.setPadding(dp(4), dp(2), dp(4), dp(2))
        flashBtn = pill("⚡ OFF") { cycleFlash() }
        timerBtn = pill("⏱ OFF") { cycleTimer() }
        val gridBtn = pill("▦ GRID") { prefs.grid = !prefs.grid; gridView.visibility = if (prefs.grid) View.VISIBLE else View.GONE }
        val looksBtn = pill("🎨 LOOKS") { looksVisible = !looksVisible; updatePanels() }
        val setBtn = pill("⚙") { showSettings() }
        val anBtn = pill("📊 OFF") {}
        anBtn.setOnClickListener {
            prefs.analyzer = (prefs.analyzer + 1) % 4
            analyzer.level = prefs.analyzer
            anBtn.text = analyzerLabel(prefs.analyzer)
            styleSel(anBtn, prefs.analyzer != 0)
        }
        val lensBtn = pill("🔭 LENS") { cycleLens() }
        val infoBtn = pill("ℹ") { showCameraInfo() }
        for (b in listOf(flashBtn, timerBtn, anBtn, lensBtn, gridBtn, looksBtn, infoBtn, setBtn)) top.addView(b)
        root.addView(hscroll(top))
        refreshTopButtons()

        // ---- preview area
        val frame = FrameLayout(this)
        frame.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        previewView = PreviewView(this)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        frame.addView(previewView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        gridView = GridView(this)
        gridView.visibility = if (prefs.grid) View.VISIBLE else View.GONE
        gridView.isClickable = false
        frame.addView(gridView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        analyzer = AnalyzerView(this)
        analyzer.level = prefs.analyzer
        analyzer.isClickable = false
        frame.addView(analyzer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        anBtn.text = analyzerLabel(prefs.analyzer)
        styleSel(anBtn, prefs.analyzer != 0)

        infoTv = txt("", 11f, ACCENT)
        infoTv.setPadding(dp(8), dp(4), dp(8), dp(4))
        frame.addView(infoTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))

        suggestionTv = txt("", 12f, 0xFFFFC107.toInt())
        suggestionTv.setPadding(dp(12), dp(6), dp(12), dp(6))
        val sgb = GradientDrawable()
        sgb.cornerRadius = dp(14).toFloat()
        sgb.setColor(0xAA000000.toInt())
        suggestionTv.background = sgb
        suggestionTv.visibility = View.GONE
        suggestionTv.setOnClickListener { suggestMode?.let { m -> setMode(m) } }
        val sglp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        sglp.topMargin = dp(26)
        frame.addView(suggestionTv, sglp)

        zoomTv = txt("1.0x", 12f)
        zoomTv.setPadding(dp(10), dp(4), dp(10), dp(4))
        frame.addView(zoomTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        statusTv = txt("", 18f)
        statusTv.gravity = Gravity.CENTER
        statusTv.setPadding(dp(16), dp(10), dp(16), dp(10))
        val sbg = GradientDrawable()
        sbg.cornerRadius = dp(14).toFloat()
        sbg.setColor(0x99000000.toInt())
        statusTv.background = sbg
        statusTv.visibility = View.GONE
        frame.addView(statusTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        focusRing = View(this)
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setStroke(dp(2), ACCENT)
        ring.setColor(Color.TRANSPARENT)
        focusRing.background = ring
        focusRing.visibility = View.GONE
        frame.addView(focusRing, FrameLayout.LayoutParams(dp(70), dp(70), Gravity.TOP or Gravity.START))

        setupGestures()
        root.addView(frame)

        // ---- panels
        looksPanel = buildLooksPanel()
        proPanel = buildProPanel()
        videoPanel = buildVideoPanel()
        portraitPanel = buildPortraitPanel()
        lapsePanel = buildLapsePanel()
        root.addView(looksPanel)
        root.addView(proPanel)
        root.addView(videoPanel)
        root.addView(portraitPanel)
        root.addView(lapsePanel)

        // ---- mode selector
        val modes = hrow()
        modes.gravity = Gravity.CENTER
        for (m in Mode.values()) {
            val p = pill(m.label) { setMode(m) }
            modePills[m] = p
            modes.addView(p)
        }
        root.addView(hscroll(modes))

        // ---- shutter row
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(dp(16), dp(8), dp(16), dp(12))

        val thumbBox = FrameLayout(this)
        thumbBox.layoutParams = LinearLayout.LayoutParams(0, dp(60), 1f)
        thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        val tbg = GradientDrawable()
        tbg.cornerRadius = dp(12).toFloat()
        tbg.setColor(0x33FFFFFF)
        thumb.background = tbg
        thumb.clipToOutline = true
        thumb.outlineProvider = ViewOutlineProvider.BACKGROUND
        thumb.setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
        thumb.setOnLongClickListener { openLast(); true }
        thumbBox.addView(thumb, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER_VERTICAL or Gravity.START))
        busyTv = txt("", 12f, 0xFFFFC107.toInt())
        thumbBox.addView(busyTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL or Gravity.END))

        shutter = ShutterView(this)
        shutter.layoutParams = LinearLayout.LayoutParams(dp(78), dp(78))
        shutter.setOnClickListener { onShutter() }

        val flipBox = FrameLayout(this)
        flipBox.layoutParams = LinearLayout.LayoutParams(0, dp(60), 1f)
        val flip = txt("🔄", 26f)
        flip.gravity = Gravity.CENTER
        flip.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            bindCamera(false)
        }
        flipBox.addView(flip, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER_VERTICAL or Gravity.END))

        bottom.addView(thumbBox)
        bottom.addView(shutter)
        bottom.addView(flipBox)
        root.addView(bottom)

        setContentView(root)
        setMode(Mode.AUTO, rebind = false)
        refreshLookPills()
    }

    private fun buildLooksPanel(): LinearLayout {
        val p = vcol()
        val row = hrow()
        for (lk in Looks.ALL) {
            val pl = pill(lk.name) {
                prefs.lookId = lk.id
                refreshLookPills()
                applyLookPreview()
            }
            lookPills[lk.id] = pl
            row.addView(pl)
        }
        p.addView(hscroll(row))
        p.addView(sliderRow("Look %", 100, prefs.lookIntensity, { "$it%" }) {
            prefs.lookIntensity = it
            applyLookPreview()
        })
        return p
    }

    private fun refreshLookPills() {
        for ((id, v) in lookPills) styleSel(v, id == prefs.lookId)
    }

    private fun buildProPanel(): LinearLayout {
        val p = vcol()
        val chips = hrow()
        val aeBtn = pill("EXPO: AUTO") {}
        aeBtn.setOnClickListener {
            if (tuner?.hasManual != true) { toast("Is camera me manual exposure supported nahi"); return@setOnClickListener }
            proManualAE = !proManualAE
            aeBtn.text = if (proManualAE) "EXPO: MANUAL" else "EXPO: AUTO"
            styleSel(aeBtn, proManualAE)
            applyPro()
        }
        val afBtn = pill("FOCUS: AUTO") {}
        afBtn.setOnClickListener {
            proManualAF = !proManualAF
            afBtn.text = if (proManualAF) "FOCUS: MANUAL" else "FOCUS: AUTO"
            styleSel(afBtn, proManualAF)
            applyPro()
        }
        val procBtn = pill("PROCESS: OFF") {}
        procBtn.setOnClickListener {
            prefs.proProcess = !prefs.proProcess
            procBtn.text = if (prefs.proProcess) "PROCESS: ON" else "PROCESS: OFF"
            styleSel(procBtn, prefs.proProcess)
        }
        procBtn.text = if (prefs.proProcess) "PROCESS: ON" else "PROCESS: OFF"
        styleSel(procBtn, prefs.proProcess)
        chips.addView(aeBtn); chips.addView(afBtn); chips.addView(procBtn)
        p.addView(hscroll(chips))

        val wb = hrow()
        val wbItems = listOf(
            "WB AUTO" to null,
            "☀ DAY" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
            "☁ CLOUD" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
            "💡 TUNGSTEN" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
            "FLUORESCENT" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
        )
        val wbViews = ArrayList<TextView>()
        for ((i, item) in wbItems.withIndex()) {
            val v = pill(item.first) {}
            v.setOnClickListener {
                proAwb = item.second
                for ((j, o) in wbViews.withIndex()) styleSel(o, j == i)
                applyPro()
            }
            styleSel(v, i == 0)
            wbViews.add(v)
            wb.addView(v)
        }
        p.addView(hscroll(wb))

        p.addView(sliderRow("EV", 24, 12, { v ->
            val st = camera?.cameraInfo?.exposureState
            if (st == null) "0.0" else {
                val r = st.exposureCompensationRange
                val idx = r.lower + (v * (r.upper - r.lower) / 24f).roundToInt()
                String.format(Locale.US, "%+.1f", idx * st.exposureCompensationStep.toFloat())
            }
        }) { v ->
            val cam = camera
            val st = cam?.cameraInfo?.exposureState
            if (cam != null && st != null && st.isExposureCompensationSupported) {
                val r = st.exposureCompensationRange
                cam.cameraControl.setExposureCompensationIndex(r.lower + (v * (r.upper - r.lower) / 24f).roundToInt())
            }
        })
        p.addView(sliderRow("ISO", 100, proIso, { "${isoFromP(it)}" }) { proIso = it; applyPro() })
        p.addView(sliderRow("SHUTTER", 100, proShut, { fmtShutter(expFromP(it)) }) { proShut = it; applyPro() })
        p.addView(sliderRow("FOCUS", 100, proFocus, { if (it == 0) "∞" else "$it%" }) { proFocus = it; applyPro() })
        return p
    }

    private fun isoFromP(p: Int): Int {
        val r = tuner?.isoRange ?: return 100
        return (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
    }

    private fun expFromP(p: Int): Long {
        val r = tuner?.expRange ?: return 10_000_000L
        val hi = min(r.upper, 2_000_000_000L).toDouble()
        val lo = max(r.lower, 100_000L).toDouble()
        return (lo * (hi / lo).pow(p / 100.0)).toLong()
    }

    private fun applyPro() {
        val t = tuner ?: return
        if (proManualAE && t.hasManual) t.setManualExposure(isoFromP(proIso), expFromP(proShut)) else t.setAutoExposure()
        if (proManualAF) t.setManualFocus(proFocus / 100f * t.minFocus) else t.setAutoFocus()
        t.setAwb(proAwb)
        t.commit()
    }

    private fun buildVideoPanel(): LinearLayout {
        val p = vcol()
        val row = hrow()
        val res = ArrayList<TextView>()
        val names = listOf("4K", "FHD 1080p", "HD 720p")
        for ((i, n) in names.withIndex()) {
            val v = pill(n) {}
            v.setOnClickListener {
                prefs.videoRes = i
                for ((j, o) in res.withIndex()) styleSel(o, j == i)
                bindCamera(false)
            }
            styleSel(v, i == prefs.videoRes)
            res.add(v)
            row.addView(v)
        }
        val steady = pill("SUPER STEADY") {}
        steady.setOnClickListener {
            prefs.superSteady = !prefs.superSteady
            styleSel(steady, prefs.superSteady)
            reapplyTuning()
        }
        styleSel(steady, prefs.superSteady)
        val low = pill("LOW-LIGHT") {}
        low.setOnClickListener {
            prefs.videoLowLight = !prefs.videoLowLight
            styleSel(low, prefs.videoLowLight)
            reapplyTuning()
        }
        styleSel(low, prefs.videoLowLight)
        val f60 = pill("60 FPS") {}
        f60.setOnClickListener {
            prefs.video60 = !prefs.video60
            styleSel(f60, prefs.video60)
            bindCamera(false)
        }
        styleSel(f60, prefs.video60)
        val hdr10 = pill("HDR10") {}
        hdr10.setOnClickListener {
            prefs.videoHdr = !prefs.videoHdr
            styleSel(hdr10, prefs.videoHdr)
            bindCamera(false)
        }
        styleSel(hdr10, prefs.videoHdr)
        row.addView(steady); row.addView(low); row.addView(f60); row.addView(hdr10)
        p.addView(hscroll(row))
        return p
    }

    private fun buildPortraitPanel(): LinearLayout {
        val p = vcol()
        p.addView(sliderRow("Bokeh", 100, prefs.bokeh, { "$it%" }) { prefs.bokeh = it })
        val t = txt("Person ke saamne rakho. People detect hote hain, baaki background blur hota hai.", 11f, 0xFFAAAAAA.toInt())
        t.setPadding(dp(12), 0, dp(12), dp(4))
        p.addView(t)
        return p
    }

    private fun buildLapsePanel(): LinearLayout {
        val p = vcol()
        val r1 = hrow()
        val ints = listOf(2, 5, 10, 30, 60)
        val iv = ArrayList<TextView>()
        for ((i, sec) in ints.withIndex()) {
            val v = pill("${sec}s") {}
            v.setOnClickListener {
                prefs.lapseInterval = sec
                for ((j, o) in iv.withIndex()) styleSel(o, j == i)
            }
            styleSel(v, sec == prefs.lapseInterval)
            iv.add(v)
            r1.addView(v)
        }
        val r2 = hrow()
        val counts = listOf(30, 100, 300, 0)
        val cv = ArrayList<TextView>()
        for ((i, c) in counts.withIndex()) {
            val v = pill(if (c == 0) "∞ frames" else "$c frames") {}
            v.setOnClickListener {
                prefs.lapseCount = c
                for ((j, o) in cv.withIndex()) styleSel(o, j == i)
            }
            styleSel(v, c == prefs.lapseCount)
            cv.add(v)
            r2.addView(v)
        }
        p.addView(hscroll(r1))
        p.addView(hscroll(r2))
        return p
    }

    private fun analyzerLabel(l: Int): String = when (l) {
        1 -> "📊 HIST"
        2 -> "📊 +PEAK"
        3 -> "📊 +ZEBRA"
        else -> "📊 OFF"
    }

    private fun updatePanels() {
        looksPanel.visibility = if (looksVisible && mode != Mode.VIDEO && mode != Mode.LAPSE) View.VISIBLE else View.GONE
        proPanel.visibility = if (mode == Mode.PRO) View.VISIBLE else View.GONE
        videoPanel.visibility = if (mode == Mode.VIDEO) View.VISIBLE else View.GONE
        portraitPanel.visibility = if (mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        lapsePanel.visibility = if (mode == Mode.LAPSE) View.VISIBLE else View.GONE
    }

    private fun refreshTopButtons() {
        flashBtn.text = when (prefs.flash) { 1 -> "⚡ AUTO"; 2 -> "⚡ ON"; else -> "⚡ OFF" }
        timerBtn.text = if (prefs.timer == 0) "⏱ OFF" else "⏱ ${prefs.timer}s"
        styleSel(flashBtn, prefs.flash != 0)
        styleSel(timerBtn, prefs.timer != 0)
    }

    private fun cycleFlash() {
        prefs.flash = (prefs.flash + 1) % 3
        refreshTopButtons()
        applyFlash()
        reapplyTuning()
    }

    private fun cycleTimer() {
        prefs.timer = when (prefs.timer) { 0 -> 3; 3 -> 10; else -> 0 }
        refreshTopButtons()
    }

    private fun applyFlash() {
        if (mode == Mode.VIDEO) {
            camera?.cameraControl?.enableTorch(prefs.flash == 2)
        } else {
            imageCapture?.flashMode = when (prefs.flash) {
                1 -> ImageCapture.FLASH_MODE_AUTO
                2 -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }
    }

    private fun setStatus(t: String?) {
        if (t == null) {
            statusTv.visibility = View.GONE
        } else {
            statusTv.text = t
            statusTv.visibility = View.VISIBLE
        }
    }

    private fun refreshBusy() {
        busyTv.text = ""
    }

    private fun setMode(m: Mode, rebind: Boolean = true) {
        val wasVideo = mode == Mode.VIDEO
        mode = m
        for ((k, v) in modePills) styleSel(v, k == m)
        shutter.video = m == Mode.VIDEO
        updatePanels()
        if (rebind) {
            when (m) {
                Mode.ASTRO, Mode.TRAILS -> toast("Tripod pe rakho, andhere me; long exposure")
                Mode.PANO -> toast("Shutter dabao, dheere pan karo, dobara dabao = stop")
                Mode.SCAN -> toast("Document seedha rakho, achhi roshni me")
                Mode.PORTRAIT -> toast("Person ko frame me rakho")
                else -> {}
            }
        }
        if (rebind && cameraProvider != null) {
            val isVideo = m == Mode.VIDEO
            val needsRebind = wasVideo != isVideo || (!isVideo && (effectiveCapRes() != boundCapRes || fastCapture() != boundFast))
            if (needsRebind) bindCamera(false) else reapplyTuning()
        }
    }

    // ===================================================================== gestures
    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val z = cam.cameraInfo.zoomState.value ?: return true
                val nr = (z.zoomRatio * detector.scaleFactor).coerceIn(z.minZoomRatio, z.maxZoomRatio)
                cam.cameraControl.setZoomRatio(nr)
                return true
            }
        })
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        lastTapX = x; lastTapY = y; lastTapMs = System.currentTimeMillis()
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB
            ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
            cam.cameraControl.startFocusAndMetering(action)
        } catch (e: Exception) {
            Log.w(TAG, "focus", e)
        }
        focusRing.translationX = x - dp(35)
        focusRing.translationY = y - dp(35)
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.animate().alpha(0f).setDuration(900).start()
    }

    // ===================================================================== camera binding
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            cameraProvider = f.get()
            bindCamera(false)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun effectiveCapRes(): Int =
        if (mode == Mode.AUTO || mode == Mode.PRO || mode == Mode.LAPSE) prefs.capRes else min(prefs.capRes, 1)

    /** AUTO takes a quick multi-frame burst (noise-free merge) unless MAX direct-JPEG or flash is used. */
    private fun autoBurst(): Boolean = mode == Mode.AUTO && prefs.smartAuto && prefs.capRes != 2 && prefs.flash == 0

    private fun fastCapture(): Boolean = autoBurst() || mode == Mode.ULTRA || mode == Mode.NIGHT

    private fun isStackMode(): Boolean =
        autoBurst() || mode == Mode.ULTRA || mode == Mode.NIGHT || mode == Mode.ASTRO || mode == Mode.TRAILS || mode == Mode.PORTRAIT

    private fun bindCamera(safe: Boolean) {
        val provider = cameraProvider ?: return
        try {
            provider.unbindAll()
            val video = mode == Mode.VIDEO
            val ratio = if (video) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            val prevSel = ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build()
            val pb = Preview.Builder().setResolutionSelector(prevSel)
            Camera2Interop.Extender(pb).setSessionCaptureCallback(previewCb)
            val preview = pb.build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val sel = CameraSelector.Builder().requireLensFacing(lensFacing)
            val lid = lensId
            if (!safe && lid != null && lensFacing == CameraSelector.LENS_FACING_BACK) {
                sel.addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == lid } }
            }
            val selector = sel.build()

            if (video) {
                imageCapture = null
                val q = when (prefs.videoRes) { 0 -> Quality.UHD; 1 -> Quality.FHD; else -> Quality.HD }
                val qs = QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
                val rec = Recorder.Builder().setQualitySelector(qs).build()
                val vb = VideoCapture.Builder(rec)
                if (!safe) {
                    if (prefs.video60) tryInvoke(vb, "setTargetFrameRate", Range::class.java, Range(60, 60))
                    if (prefs.videoHdr) setHdr(vb)
                }
                val vc = vb.build()
                videoCapture = vc
                camera = provider.bindToLifecycle(this, selector, preview, vc)
            } else {
                videoCapture = null
                val target = when (effectiveCapRes()) {
                    0 -> Size(4000, 3000)
                    1 -> Size(4608, 3456)
                    else -> Size(9248, 6936)
                }
                boundCapRes = effectiveCapRes()
                boundFast = fastCapture()
                val icb = ImageCapture.Builder().setCaptureMode(
                    if (boundFast) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                )
                if (boundFast) icb.setJpegQuality(93)
                if (!safe) {
                    val rs = ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(
                            ResolutionStrategy(target, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        ).build()
                    icb.setResolutionSelector(rs)
                }
                val ic = icb.build()
                imageCapture = ic
                camera = provider.bindToLifecycle(this, selector, preview, ic)
            }
            onBound()
        } catch (e: Exception) {
            Log.e(TAG, "bind failed (safe=$safe)", e)
            if (!safe) { lensId = null; bindCamera(true) } else toast("Camera start nahi hua: ${e.message}")
        }
    }

    private fun onBound() {
        val cam = camera ?: return
        tuner = CameraTuner(cam)
        reapplyTuning()
        applyFlash()
        cam.cameraInfo.zoomState.removeObservers(this)
        cam.cameraInfo.zoomState.observe(this) { z ->
            zoomTv.text = String.format(Locale.US, "%.1fx", z.zoomRatio)
        }
        previewView.previewStreamState.removeObservers(this)
        previewView.previewStreamState.observe(this) { st ->
            if (st == PreviewView.StreamState.STREAMING) applyLookPreview()
        }
    }

    private fun reapplyTuning() {
        val t = tuner ?: return
        t.applyDefaults(
            stack = isStackMode(),
            video = mode == Mode.VIDEO,
            superSteady = prefs.superSteady,
            lowLightVideo = prefs.videoLowLight
        )
        if (mode == Mode.PRO) applyPro()
    }

    // ---- live (approximate) look preview through TextureView layer paint
    private fun findTextureView(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val r = findTextureView(v.getChildAt(i))
                if (r != null) return r
            }
        }
        return null
    }

    private fun applyLookPreview() {
        try {
            val tv = findTextureView(previewView) ?: return
            val look = Looks.byId(prefs.lookId)
            val t = prefs.lookIntensity / 100f
            val sat = if (look.mono) 1f - t else 1f + (look.sat - 1f) * t
            val c = 1f + (look.contrast - 1f) * t
            val off = 128f * (1f - c) + look.bright * t * 45f
            val temp = look.temp * t
            val cm = ColorMatrix()
            cm.setSaturation(max(0f, sat))
            cm.postConcat(ColorMatrix(floatArrayOf(
                c * (1f + 0.10f * temp), 0f, 0f, 0f, off,
                0f, c, 0f, 0f, off,
                0f, 0f, c * (1f - 0.10f * temp), 0f, off,
                0f, 0f, 0f, 1f, 0f
            )))
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(cm)
            tv.setLayerPaint(p)
        } catch (e: Exception) {
            Log.w(TAG, "look preview", e)
        }
    }

    // ===================================================================== shooting
    private fun onShutter() {
        if (mode == Mode.VIDEO) { toggleRecording(); return }
        if (mode == Mode.LAPSE) { toggleLapse(); return }
        if (mode == Mode.PANO) { togglePano(); return }
        if (shooting || imageCapture == null) return
        val delaySec = prefs.timer
        scope.launch {
            shooting = true
            shutter.busy = true
            try {
                if (delaySec > 0) {
                    for (s in delaySec downTo 1) { setStatus("$s"); delay(1000) }
                }
                when (mode) {
                    Mode.AUTO -> shootAuto()
                    Mode.ULTRA -> shootStack(6, ProcMode.STACK)
                    Mode.NIGHT -> shootNight()
                    Mode.HDR -> shootHdr()
                    Mode.PRO -> shootPro()
                    Mode.PORTRAIT -> shootPortrait()
                    Mode.ASTRO -> shootAstro(false)
                    Mode.TRAILS -> shootAstro(true)
                    Mode.SCAN -> shootScan()
                    else -> {}
                }
            } catch (e: Exception) {
                Log.e(TAG, "shoot", e)
                toast("Capture error: ${e.message}")
            } finally {
                shooting = false
                shutter.busy = false
                setStatus(null)
                applyFlash()
            }
        }
    }

    private fun frameFile(i: Int): File {
        val dir = File(cacheDir, "frames")
        dir.mkdirs()
        return File(dir, "f_${System.nanoTime()}_$i.jpg")
    }

    private suspend fun takePictureToFile(file: File): Boolean = suspendCancellableCoroutine { cont ->
        val ic = imageCapture
        if (ic == null) {
            cont.resume(false)
        } else {
            val o = ImageCapture.OutputFileOptions.Builder(file).build()
            ic.takePicture(o, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    if (cont.isActive) cont.resume(true)
                }
                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "takePicture", exception)
                    if (cont.isActive) cont.resume(false)
                }
            })
        }
    }

    private fun smartFrameCount(): Int {
        val iso = meta.iso
        val e = meta.expNs
        return when {
            iso <= 0 -> 4
            iso <= 150 && e < 8_000_000L -> 3
            iso <= 450 -> 4
            iso <= 1000 -> 5
            else -> 6
        }
    }

    /** Picks the most detailed, well-exposed, centre-weighted spot of the preview (unless the user tapped recently). */
    private fun pickFocusPoint(): Pair<Float, Float>? {
        val vw = previewView.width.toFloat()
        val vh = previewView.height.toFloat()
        if (vw <= 0f || vh <= 0f) return null
        if (System.currentTimeMillis() - lastTapMs < 15_000L) return Pair(lastTapX, lastTapY)
        val full = previewView.bitmap ?: return null
        val gw = 64
        val gh = max(8, (gw * full.height / full.width.toFloat()).roundToInt())
        val small = Bitmap.createScaledBitmap(full, gw, gh, true)
        if (small !== full) full.recycle()
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        small.recycle()
        val lum = FloatArray(gw * gh) {
            val p = px[it]
            0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
        }
        val cx = 8
        val cy = 6
        var best = -1f
        var bi = cx / 2
        var bj = cy / 2
        for (j in 0 until cy) {
            for (i in 0 until cx) {
                val x0 = i * gw / cx
                val x1 = (i + 1) * gw / cx
                val y0 = j * gh / cy
                val y1 = (j + 1) * gh / cy
                var e = 0f
                var m = 0f
                var n = 0
                for (y in y0 until min(y1, gh - 1)) {
                    for (x in x0 until min(x1, gw - 1)) {
                        val k = y * gw + x
                        e += abs(lum[k + 1] - lum[k]) + abs(lum[k + gw] - lum[k])
                        m += lum[k]
                        n++
                    }
                }
                if (n == 0) continue
                m /= n
                val dx = (i + 0.5f) / cx - 0.5f
                val dy = (j + 0.5f) / cy - 0.5f
                val centre = 1f - 0.9f * sqrt(dx * dx + dy * dy)
                val expo = if (m < 25f || m > 240f) 0.3f else 1f
                val score = e / n * centre * expo
                if (score > best) { best = score; bi = i; bj = j }
            }
        }
        if (best < 3f) return Pair(vw / 2f, vh / 2f)
        return Pair((bi + 0.5f) / cx * vw, (bj + 0.5f) / cy * vh)
    }

    /** Smart focus: lock AF/AE on the best spot and wait (max 1.5 s) before shooting. */
    private suspend fun smartFocus() {
        val cam = camera ?: return
        if (mode == Mode.PRO && proManualAF) return
        try {
            val pt = pickFocusPoint() ?: return
            val mp = previewView.meteringPointFactory.createPoint(pt.first, pt.second)
            val action = FocusMeteringAction.Builder(
                mp, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB
            ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
            val fut = cam.cameraControl.startFocusAndMetering(action)
            setStatus("Focus lock…")
            withTimeoutOrNull(1500L) {
                suspendCancellableCoroutine<Boolean> { c ->
                    fut.addListener({ if (c.isActive) c.resume(true) }, ContextCompat.getMainExecutor(this@MainActivity))
                }
            }
            delay(100)
        } catch (e: Exception) {
            Log.w(TAG, "smartFocus", e)
        }
    }

    private suspend fun shootAuto() {
        if (autoBurst()) {
            smartFocus()
            val files = burst(smartFrameCount(), "Hold steady")
            finishBurst(files, ProcMode.STACK)
            return
        }
        applyFlash()
        setStatus("Capturing…")
        val f = frameFile(0)
        if (!takePictureToFile(f)) { toast("Capture failed"); return }
        if (effectiveCapRes() == 2) {
            withContext(Dispatchers.IO) { saveFileToGallery(f) }
            f.delete()
        } else {
            enqueue(listOf(f), ProcMode.SINGLE)
        }
    }

    private suspend fun burst(n: Int, label: String): List<File> {
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        val files = ArrayList<File>()
        for (i in 0 until n) {
            setStatus("$label ${i + 1}/$n")
            val f = frameFile(i)
            if (takePictureToFile(f)) files.add(f)
        }
        return files
    }

    private suspend fun shootStack(n: Int, pm: ProcMode) {
        val files = burst(n, "Hold steady")
        finishBurst(files, pm)
    }

    private fun finishBurst(files: List<File>, pm: ProcMode, portrait: Boolean = false) {
        if (files.isEmpty()) { toast("Capture failed"); return }
        enqueue(files, if (files.size == 1) ProcMode.SINGLE else pm, portrait)
    }

    private suspend fun shootNight() {
        val t = tuner
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        var manual = false
        val ir = t?.isoRange
        val er = t?.expRange
        if (t != null && t.hasManual && ir != null && er != null && meta.iso > 0 && meta.expNs > 0) {
            val tripod = prefs.tripod
            val tMax = min(if (tripod) 3_500_000_000L else 125_000_000L, er.upper)
            val isoCap = min(if (tripod) 800 else 3200, ir.upper)
            val total = meta.iso.toDouble() * meta.expNs.toDouble() * (if (tripod) 2.2 else 1.7)
            val iso = (total / tMax).roundToInt().coerceIn(ir.lower, max(ir.lower, isoCap))
            val exp = (total / iso).toLong().coerceIn(er.lower, tMax)
            t.setManualExposure(iso, exp)
            t.commit()
            manual = true
            setStatus(if (tripod) "Shutter open… phone stable rakho" else "Light capture ho raha hai…")
            delay(350L + exp / 1_000_000L * (if (tripod) 1L else 2L))
        } else {
            val st = camera?.cameraInfo?.exposureState
            if (st != null && st.isExposureCompensationSupported) {
                camera?.cameraControl?.setExposureCompensationIndex(st.exposureCompensationRange.upper)
            }
            delay(400)
        }
        val files = try {
            burst(if (manual) (if (prefs.tripod) 3 else 6) else 7, if (manual && prefs.tripod) "Night • tripod, hilo mat" else "Night • hold steady")
        } finally {
            if (manual) { t?.setAutoExposure(); t?.commit() }
            camera?.cameraControl?.setExposureCompensationIndex(0)
        }
        finishBurst(files, ProcMode.NIGHT)
    }

    private suspend fun shootHdr() {
        val cam = camera ?: return
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported || st.exposureCompensationStep.toFloat() <= 0f) {
            shootStack(3, ProcMode.STACK)
            return
        }
        val step = st.exposureCompensationStep.toFloat()
        val r = st.exposureCompensationRange
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        val files = ArrayList<File>()
        try {
            for ((i, ev) in listOf(-2f, 0f, 2f).withIndex()) {
                val idx = (ev / step).roundToInt().coerceIn(r.lower, r.upper)
                cam.cameraControl.setExposureCompensationIndex(idx)
                setStatus("HDR ${i + 1}/3")
                delay(600)
                val f = frameFile(i)
                if (takePictureToFile(f)) files.add(f)
            }
        } finally {
            cam.cameraControl.setExposureCompensationIndex(0)
        }
        finishBurst(files, ProcMode.HDR)
    }

    private suspend fun shootPro() {
        applyFlash()
        setStatus("Capturing…")
        val f = frameFile(0)
        if (!takePictureToFile(f)) { toast("Capture failed"); return }
        if (!prefs.proProcess || effectiveCapRes() == 2) {
            withContext(Dispatchers.IO) { saveFileToGallery(f) }
            f.delete()
        } else {
            enqueue(listOf(f), ProcMode.SINGLE)
        }
    }

    private suspend fun shootPortrait() {
        val files = burst(3, "Portrait • hold steady")
        finishBurst(files, ProcMode.STACK, portrait = true)
    }

    private suspend fun shootScan() {
        applyFlash()
        setStatus("Scanning…")
        val f = frameFile(0)
        if (!takePictureToFile(f)) { toast("Capture failed"); return }
        enqueue(listOf(f), ProcMode.DOC)
    }

    private suspend fun shootAstro(trails: Boolean) {
        val t = tuner
        val ir = t?.isoRange
        val er = t?.expRange
        if (t == null || !t.hasManual || ir == null || er == null) {
            toast("Is phone par manual long-exposure available nahi — NIGHT mode (tripod) use karo")
            return
        }
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        val exp = min(if (trails) 3_000_000_000L else 4_000_000_000L, er.upper)
        val iso = min(if (trails) 800 else 1600, ir.upper).coerceAtLeast(ir.lower)
        t.setManualExposure(iso, exp)
        t.commit()
        setStatus("Phone stable rakho…")
        delay(1200)
        val files = try {
            burst(if (trails) 20 else 12, if (trails) "Trails" else "Stars")
        } finally {
            t.setAutoExposure()
            t.commit()
        }
        finishBurst(files, if (trails) ProcMode.TRAILS else ProcMode.ASTRO)
    }

    private fun toggleLapse() {
        val running = lapseJob
        if (running != null) {
            running.cancel()
            return
        }
        val count = prefs.lapseCount
        val interval = prefs.lapseInterval
        val st = stamp()
        shutter.recording = true
        lapseJob = scope.launch {
            var i = 0
            try {
                while (count == 0 || i < count) {
                    setStatus("⏱ Timelapse ${i + 1}" + (if (count > 0) "/$count" else ""))
                    val f = frameFile(i)
                    if (takePictureToFile(f)) {
                        val name = "LAPSE_${st}_" + String.format(Locale.US, "%04d", i) + ".jpg"
                        withContext(Dispatchers.IO) { saveFileToGallery(f, name) }
                        f.delete()
                    }
                    i++
                    delay(interval * 1000L)
                }
            } finally {
                shutter.recording = false
                setStatus(null)
                lapseJob = null
                toast("Timelapse: $i frames save hue")
            }
        }
    }

    private fun togglePano() {
        if (panoJob != null) {
            panoStop = true
            return
        }
        if (imageCapture == null) return
        panoStop = false
        shutter.recording = true
        panoJob = scope.launch {
            val files = ArrayList<File>()
            tuner?.lockAeAwb(true)
            imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
            try {
                while (!panoStop && files.size < 12) {
                    setStatus("Pano ${files.size + 1} — dheere pan karo\nSTOP = shutter")
                    val f = frameFile(files.size)
                    if (takePictureToFile(f)) files.add(f)
                    delay(150)
                }
            } finally {
                tuner?.lockAeAwb(false)
                shutter.recording = false
                setStatus(null)
                panoJob = null
            }
            if (files.size >= 2) {
                enqueue(files, ProcMode.SINGLE, pano = true)
            } else {
                for (f in files) f.delete()
                toast("Pano ke liye kam se kam 2 frames chahiye")
            }
        }
    }

    // ===================================================================== analysis / suggestions
    private fun analyzeFrame() {
        if (mode == Mode.VIDEO && recording != null) return
        val full = previewView.bitmap ?: return
        val fw = full.width
        val fh = full.height
        if (fw <= 0 || fh <= 0) return
        val sw = 96
        val sh = max(8, (sw * fh / fw.toFloat()).roundToInt())
        val small = Bitmap.createScaledBitmap(full, sw, sh, true)
        if (small !== full) full.recycle()
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        analyzer.aspect = fw.toFloat() / fh
        analyzer.update(px, sw, sh)

        val iso = meta.iso
        val e = meta.expNs
        val low = iso >= 1600 || e > 45_000_000L
        val dark = analyzer.meanLuma < 55f && iso > 800
        val hdrNeed = analyzer.highPct > 6f && analyzer.shadowPct > 18f
        var sug: Mode? = null
        if (mode == Mode.AUTO || mode == Mode.ULTRA) {
            if (low || dark) sug = Mode.NIGHT else if (hdrNeed) sug = Mode.HDR
        }
        if (sug != null && sug == suggestMode) suggestTicks++ else { suggestMode = sug; suggestTicks = 0 }
        if (sug == null) {
            suggestionTv.visibility = View.GONE
        } else {
            suggestionTv.text = if (sug == Mode.NIGHT) "🌙 Low light — NIGHT mode try karo (tap)" else "☀ High contrast — HDR try karo (tap)"
            suggestionTv.visibility = View.VISIBLE
        }
        if (prefs.autoScene && sug == Mode.NIGHT && mode == Mode.AUTO && suggestTicks >= 3 && !shooting) {
            suggestTicks = -20
            setMode(Mode.NIGHT)
            toast("Auto scene: low light → NIGHT")
        }
    }

    // ===================================================================== lens / info
    private fun cameraManager(): CameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private fun backLensIds(): List<String> = try {
        val cm = cameraManager()
        cm.cameraIdList.filter {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun lensLabel(id: String): String = try {
        val c = cameraManager().getCameraCharacteristics(id)
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
        val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        if (f != null && sz != null) {
            val eq = f * 43.27f / sqrt(sz.width * sz.width + sz.height * sz.height)
            "Camera $id • ${eq.roundToInt()}mm eq"
        } else "Camera $id"
    } catch (e: Exception) {
        "Camera $id"
    }

    private fun cycleLens() {
        if (lensFacing != CameraSelector.LENS_FACING_BACK) { toast("Front camera me lens switch nahi"); return }
        val ids = backLensIds()
        if (ids.size <= 1) {
            toast("Is phone par sirf 1 back camera apps ko mil raha hai (ℹ me dekho)")
            return
        }
        val cur = if (lensId == null) 0 else max(0, ids.indexOf(lensId))
        val next = (cur + 1) % ids.size
        lensId = if (next == 0) null else ids[next]
        toast(lensLabel(ids[next]))
        bindCamera(false)
    }

    private fun showCameraInfo() {
        val sb = StringBuilder()
        try {
            val cm = cameraManager()
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_BACK -> "BACK"
                    CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
                    else -> "EXTERNAL"
                }
                val lvl = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    0 -> "LIMITED"
                    1 -> "FULL"
                    2 -> "LEGACY"
                    3 -> "LEVEL_3"
                    else -> "?"
                }
                val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
                sb.append("━ ${lensLabel(id)}  [$facing] $lvl\n")
                val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val jpeg = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }
                val vid = map?.getOutputSizes(MediaRecorder::class.java)?.maxByOrNull { it.width.toLong() * it.height }
                if (jpeg != null) sb.append("  Max JPEG: ${jpeg.width}x${jpeg.height} (${jpeg.width.toLong() * jpeg.height / 1_000_000}MP)\n")
                if (vid != null) sb.append("  Max video: ${vid.width}x${vid.height}\n")
                sb.append("  Manual exposure: ${if (1 in caps) "YES" else "NO"}   RAW: ${if (3 in caps) "YES" else "NO"}   Burst: ${if (6 in caps) "YES" else "NO"}\n")
                val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                val eis = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                sb.append("  OIS: ${if (ois?.contains(1) == true) "YES" else "NO"}   EIS: ${if (eis?.contains(1) == true) "YES" else "NO"}\n")
                val fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                if (fps != null) sb.append("  FPS ranges: " + fps.joinToString(" ") { "${it.lower}-${it.upper}" } + "\n")
                val hs = map?.highSpeedVideoSizes
                if (hs != null && hs.isNotEmpty()) sb.append("  High-speed video sizes: ${hs.size}\n")
                if (Build.VERSION.SDK_INT >= 28) {
                    val ph = c.physicalCameraIds
                    if (ph.isNotEmpty()) sb.append("  Physical cameras: ${ph.joinToString()}\n")
                }
                sb.append("\n")
            }
        } catch (e: Exception) {
            sb.append("Error: ${e.message}")
        }
        val tv = txt(sb.toString(), 12f)
        tv.typeface = android.graphics.Typeface.MONOSPACE
        tv.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this).setTitle("Camera Info").setView(sv).setPositiveButton("OK", null).show()
    }

    private fun tryInvoke(target: Any, name: String, argType: Class<*>, arg: Any): Boolean = try {
        target.javaClass.getMethod(name, argType).invoke(target, arg)
        true
    } catch (e: Throwable) {
        false
    }

    private fun setHdr(vb: Any) {
        try {
            val cls = Class.forName("androidx.camera.core.DynamicRange")
            val hlg = cls.getField("HLG_10_BIT").get(null)
            vb.javaClass.getMethod("setDynamicRange", cls).invoke(vb, hlg)
        } catch (e: Throwable) {
            toast("HDR10 video is CameraX/phone par supported nahi")
        }
    }

    // ===================================================================== processing queue
    private fun buildParams(pm: ProcMode): ProcParams {
        val scale = when (prefs.outScale) { 0 -> 1f; 1 -> 1.5f; else -> 2f }
        return ProcParams(
            mode = pm,
            scale = scale,
            denoise = prefs.denoise / 100f,
            sharpness = prefs.sharp / 100f,
            detail = prefs.detail / 100f,
            shadowLift = prefs.lift / 100f,
            look = Looks.byId(prefs.lookId),
            lookIntensity = prefs.lookIntensity / 100f
        )
    }

    private fun orientationOf(f: File): Int = try {
        ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }

    private fun enqueue(files: List<File>, pm: ProcMode, portrait: Boolean = false, pano: Boolean = false) {
        val orient = orientationOf(files[0])
        val rot = degreesFor(orient)
        val params = buildParams(pm)
        val st = stamp()
        pendingJobs++
        refreshBusy()
        if (pendingJobs == 1) {
            try { ContextCompat.startForegroundService(this, Intent(this, ProcService::class.java)) } catch (e: Throwable) { Log.w(TAG, "svc", e) }
        }
        scope.launch(Dispatchers.Default) {
            procMutex.withLock {
                try {
                    val paths = files.map { it.absolutePath }
                    val cb: (String) -> Unit = { s ->
                        val pct = if (s.startsWith("Processing ")) (s.removePrefix("Processing ").removeSuffix("%").trim().toIntOrNull() ?: -1) else -1
                        val label = if (pct >= 0) "Processing $pct%" else s
                        ProcService.update(applicationContext, if (pendingJobs > 1) "$label  (+${pendingJobs - 1} in queue)" else label, pct)
                    }
                    val bmp = if (pano) Pano.stitch(paths, cb) else Engine.process(paths, params, cb)
                    if (portrait) {
                        cb("Portrait blur…")
                        try { Portrait.apply(bmp, rot, prefs.bokeh / 100f) } catch (t: Throwable) { Log.w(TAG, "portrait", t) }
                    }
                    if (prefs.watermark) {
                        try {
                            val d = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
                            Watermark.draw(bmp, rot, "Shot on UltraCam  •  $d")
                        } catch (t: Throwable) { Log.w(TAG, "watermark", t) }
                    }
                    val uri = saveBitmap(bmp, orient, st)
                    if (prefs.keepOriginal) saveFileToGallery(files[0], "ULTRACAM_${st}_ORIG.jpg")
                    makeThumb(bmp, orient, uri)
                    bmp.recycle()
                } catch (t: Throwable) {
                    Log.e(TAG, "process", t)
                    try { saveFileToGallery(files[0]) } catch (ignored: Throwable) { }
                    ui.post { toast("Processing fail (memory?) — basic photo save kar di") }
                } finally {
                    for (f in files) f.delete()
                }
            }
            withContext(Dispatchers.Main) {
                pendingJobs--
                refreshBusy()
                if (pendingJobs == 0) {
                    setStatus(null)
                    try { stopService(Intent(this@MainActivity, ProcService::class.java)) } catch (e: Throwable) { }
                    ProcService.done(applicationContext, "Photo ready ✓ — Gallery me save ho gayi")
                }
            }
        }
    }

    private fun setStatusSoft(s: String) {
        // processing progress is shown in the notification bar only; camera screen stays clean
    }

    // ===================================================================== saving
    private fun degreesFor(o: Int): Int = when (o) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90
        ExifInterface.ORIENTATION_ROTATE_180 -> 180
        ExifInterface.ORIENTATION_ROTATE_270 -> 270
        else -> 0
    }

    private fun imageValues(name: String): ContentValues {
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) {
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraCam")
            v.put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        return v
    }

    private fun finishPending(uri: Uri) {
        if (Build.VERSION.SDK_INT >= 29) {
            val u = ContentValues()
            u.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, u, null, null)
        }
    }

    private fun writeOrientation(uri: Uri, orientation: Int) {
        try {
            contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                val ex = ExifInterface(pfd.fileDescriptor)
                ex.setAttribute(ExifInterface.TAG_ORIENTATION, orientation.toString())
                ex.saveAttributes()
            }
        } catch (e: Exception) {
            Log.w(TAG, "exif write", e)
        }
    }

    private fun saveBitmap(bmp: Bitmap, orientation: Int, st: String): Uri? {
        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageValues("ULTRACAM_$st.jpg")
        ) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        writeOrientation(uri, orientation)
        finishPending(uri)
        return uri
    }

    private fun saveFileToGallery(file: File, name: String? = null) {
        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageValues(name ?: "ULTRACAM_${stamp()}_RAW.jpg")
        ) ?: return
        contentResolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
        finishPending(uri)
        try {
            val o = BitmapFactory.Options()
            o.inSampleSize = 16
            val small = BitmapFactory.decodeFile(file.absolutePath, o)
            if (small != null) makeThumbSmall(small, orientationOf(file), uri)
        } catch (e: Exception) { }
    }

    private fun makeThumb(bmp: Bitmap, orientation: Int, uri: Uri?) {
        val tw = 160
        val th = max(1, (bmp.height * tw / bmp.width.toFloat()).roundToInt())
        val small = Bitmap.createScaledBitmap(bmp, tw, th, true)
        makeThumbSmall(small, orientation, uri)
    }

    private fun makeThumbSmall(small: Bitmap, orientation: Int, uri: Uri?) {
        val m = Matrix()
        m.postRotate(degreesFor(orientation).toFloat())
        val rot = Bitmap.createBitmap(small, 0, 0, small.width, small.height, m, true)
        ui.post {
            thumb.setImageBitmap(rot)
            lastUri = uri
        }
    }

    private fun openLast() {
        val u = lastUri
        if (u == null) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
            } catch (e: Exception) { }
            return
        }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(u, "image/*")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            toast("Gallery open nahi hui")
        }
    }

    // ===================================================================== video
    private fun toggleRecording() {
        val r = recording
        if (r != null) {
            r.stop()
            recording = null
            return
        }
        val vc = videoCapture ?: return
        val cv = ContentValues()
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, "ULTRACAM_${stamp()}")
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/UltraCam")
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, out)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pr = pr.withAudioEnabled()
        }
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    shutter.recording = true
                    setStatus("● REC")
                }
                is VideoRecordEvent.Status -> {
                    val sec = ev.recordingStats.recordedDurationNanos / 1_000_000_000L
                    statusTv.text = String.format(Locale.US, "● REC %02d:%02d", sec / 60, sec % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    shutter.recording = false
                    setStatus(null)
                    recording = null
                    if (ev.hasError()) toast("Video error ${ev.error}") else toast("Video saved ✔")
                }
                else -> {}
            }
        }
    }

    // ===================================================================== settings
    private fun showSettings() {
        val sv = ScrollView(this)
        val box = vcol()
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        sv.addView(box)
        var rebind = false

        fun title(s: String) {
            val t = txt(s, 14f, ACCENT)
            t.setPadding(0, dp(12), 0, dp(4))
            box.addView(t)
        }

        fun choice(names: List<String>, cur: Int, onPick: (Int) -> Unit) {
            val row = hrow()
            val views = ArrayList<TextView>()
            for ((i, n) in names.withIndex()) {
                val v = pill(n) {}
                v.setOnClickListener {
                    onPick(i)
                    for ((j, o) in views.withIndex()) styleSel(o, j == i)
                }
                styleSel(v, i == cur)
                views.add(v)
                row.addView(v)
            }
            box.addView(hscroll(row))
        }

        fun toggle(label: String, cur: Boolean, onSet: (Boolean) -> Unit) {
            var state = cur
            val v = pill("") {}
            fun upd() { v.text = "$label: ${if (state) "ON" else "OFF"}"; styleSel(v, state) }
            v.setOnClickListener { state = !state; onSet(state); upd() }
            upd()
            box.addView(v)
        }

        title("Capture resolution")
        choice(listOf("12MP (4K+)", "16MP", "MAX 64MP direct"), prefs.capRes) { prefs.capRes = it; rebind = true }
        title("Output size (software upscale + super-res)")
        choice(listOf("Native", "1.5x Hi-Res", "2x Max (≤30MP)"), prefs.outScale) { prefs.outScale = it }
        title("Image engine")
        box.addView(sliderRow("Denoise", 100, prefs.denoise, { "$it" }) { prefs.denoise = it })
        box.addView(sliderRow("Sharpness", 100, prefs.sharp, { "$it" }) { prefs.sharp = it })
        box.addView(sliderRow("Detail", 100, prefs.detail, { "$it" }) { prefs.detail = it })
        box.addView(sliderRow("Shadows", 100, prefs.lift, { "$it" }) { prefs.lift = it })
        title("Night")
        toggle("Night Pro tripod (3 frames x ~3.5s, phone tika ke)", prefs.tripod) { prefs.tripod = it }
        title("Smart")
        toggle("Smart AUTO (multi-frame + AI focus)", prefs.smartAuto) { prefs.smartAuto = it; rebind = true }
        toggle("Auto scene (low light → NIGHT)", prefs.autoScene) { prefs.autoScene = it }
        title("Other")
        toggle("Original JPEG bhi save karo (Gallery compare)", prefs.keepOriginal) { prefs.keepOriginal = it }
        toggle("Watermark (Shot on UltraCam)", prefs.watermark) { prefs.watermark = it }
        title("Presets")
        val saveRow = hrow()
        val loadRow = hrow()
        for (i in 1..3) {
            saveRow.addView(pill("Save $i") { prefs.savePreset(i); toast("Preset $i saved") })
            loadRow.addView(pill("Load $i") {
                if (prefs.loadPreset(i)) {
                    toast("Preset $i loaded")
                    refreshLookPills()
                    refreshTopButtons()
                    analyzer.level = prefs.analyzer
                    rebind = true
                } else toast("Preset $i khali hai")
            })
        }
        box.addView(hscroll(saveRow))
        box.addView(hscroll(loadRow))
        box.addView(pill("ℹ Camera Info") { showCameraInfo() })

        AlertDialog.Builder(this)
            .setTitle("UltraCam Settings")
            .setView(sv)
            .setPositiveButton("OK") { _, _ -> if (rebind) bindCamera(false) }
            .show()
    }
}

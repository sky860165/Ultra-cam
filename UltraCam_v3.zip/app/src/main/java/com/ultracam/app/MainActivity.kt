package com.ultracam.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraInfo
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.sync.Semaphore
import kotlin.math.sqrt
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

private const val TAG = "UltraCam"
private val ACCENT: Int = Color.parseColor("#00E5FF")

private class LiveMeta {
    @Volatile var iso: Int = 0
    @Volatile var expNs: Long = 0L
}

private class GridView(ctx: Context) : View(ctx) {
    private val p = Paint().apply {
        color = 0x66FFFFFF
        strokeWidth = 2f
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, p)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, p)
        }
    }
}

private class ShutterView(ctx: Context) : View(ctx) {
    private val ring = Paint().apply { color = Color.WHITE; style = Paint.Style.STROKE; isAntiAlias = true }
    private val fill = Paint().apply { isAntiAlias = true }
    var video: Boolean = false
        set(v) { field = v; invalidate() }
    var recording: Boolean = false
        set(v) { field = v; invalidate() }
    var busy: Boolean = false
        set(v) { field = v; invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(cx, cy)
        ring.strokeWidth = r * 0.09f
        canvas.drawCircle(cx, cy, r * 0.90f, ring)
        fill.color = if (video) 0xFFE53935.toInt() else if (busy) 0xFFFFC107.toInt() else Color.WHITE
        if (recording) {
            val s = r * 0.42f
            canvas.drawRoundRect(RectF(cx - s, cy - s, cx + s, cy + s), 12f, 12f, fill)
        } else {
            canvas.drawCircle(cx, cy, r * 0.72f, fill)
        }
    }
}

@ExperimentalCamera2Interop
class MainActivity : AppCompatActivity() {

    enum class Mode(val label: String) {
        AUTO("AUTO"), ULTRA("ULTRA"), WIDE("ULTRA-WIDE"), NIGHT("NIGHT"), UNIGHT("ULTRA NIGHT"), HDR("HDR"), PORTRAIT("PORTRAIT"), PRO("PRO"),
        ASTRO("ASTRO"), TRAILS("TRAILS"), PANO("PANO"), SCAN("SCAN"), LAPSE("LAPSE"), VIDEO("VIDEO")
    }

    private lateinit var prefs: Prefs
    private lateinit var previewView: PreviewView
    private lateinit var statusTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var zoomTv: TextView
    private lateinit var focusRing: View
    private lateinit var gridView: GridView
    private lateinit var thumb: ImageView
    private lateinit var busyTv: TextView
    private lateinit var shutter: ShutterView
    private lateinit var flashBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var beautyBtn: TextView
    private lateinit var blurBtn: TextView
    private var fullBtn: TextView? = null
    private var outerRoot: FrameLayout? = null
    private var rootCol: LinearLayout? = null
    private var frameView: FrameLayout? = null
    private var fsSpacer: View? = null
    private var frameIdx = 1
    private var topSv: View? = null
    private var modesSv: View? = null
    private var bottomBar: View? = null
    private lateinit var detailBtn: TextView
    private lateinit var looksPanel: LinearLayout
    private lateinit var proPanel: LinearLayout
    private lateinit var videoPanel: LinearLayout
    private val modePills = HashMap<Mode, TextView>()
    private val lookPills = HashMap<String, TextView>()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var tuner: CameraTuner? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var mode = Mode.AUTO
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var looksVisible = true
    private var boundCapRes = -1
    private var boundFast = false
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var lastTapMs = 0L
    // last tapped focus point, 0..1 in the preview image (used by Focus blur)
    private var focusU = 0.5f
    private var focusV = 0.45f
    private var lensId: String? = null
    private lateinit var analyzer: AnalyzerView
    private lateinit var suggestionTv: TextView
    private lateinit var portraitPanel: LinearLayout
    private lateinit var lapsePanel: LinearLayout
    private lateinit var sensorManager: SensorManager
    private var lapseJob: Job? = null
    private var panoJob: Job? = null
    private var panoStop = false
    private var suggestMode: Mode? = null
    private var suggestTicks = 0
    private lateinit var screenFlash: View
    private var centerLuma = 128f
    // AI director state
    private var aiPlan: AiPlan = AiPlan.NEUTRAL
    private var aiPrevLuma: FloatArray? = null
    private var aiMotion = 0f
    private var aiShutter = ShutterBias.AUTO
    private var smoothLevel = 0f
    private var devDeg = 0
    private var rawWarned = false
    private val gyro by lazy { GyroMeter(sensorManager) }

    private lateinit var cameraExecutor: ExecutorService
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val procMutex = Mutex()
    private var pendingJobs = 0
    private var shooting = false
    private var lastUri: Uri? = null
    private val ui = Handler(Looper.getMainLooper())
    private val meta = LiveMeta()

    // PRO state
    private var proManualAE = false
    private var proIso = 35
    private var proShut = 50
    private var proManualAF = false
    private var proFocus = 0
    private var proAwb: Int? = null

    private val previewCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult
        ) {
            result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { meta.iso = it }
            result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { meta.expNs = it }
        }
    }

    private val infoTicker = object : Runnable {
        override fun run() {
            val iso = meta.iso
            val e = meta.expNs
            infoTv.text = if (iso > 0 && e > 0) "ISO $iso   ${fmtShutter(e)}   ${mode.label}" else mode.label
            ui.postDelayed(this, 500)
        }
    }

    private val orientationListener by lazy {
        object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                devDeg = (((orientation + 45) / 90) * 90) % 360
                val rot = when (orientation) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                imageCapture?.targetRotation = rot
                videoCapture?.targetRotation = rot
            }
        }
    }

    private val analysisTicker = object : Runnable {
        override fun run() {
            try { analyzeFrame() } catch (e: Throwable) { Log.w(TAG, "analyze", e) }
            ui.postDelayed(this, 900)
        }
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val deg = Math.toDegrees(Math.atan2(event.values[0].toDouble(), event.values[1].toDouble())).toFloat()
            smoothLevel += (deg - smoothLevel) * 0.2f
            analyzer.levelDeg = smoothLevel
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    // ===================================================================== lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = Prefs(this)
        cameraExecutor = Executors.newSingleThreadExecutor()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        buildUi()
        if (hasCameraPermission()) startCamera() else requestPerms()
        if (Build.VERSION.SDK_INT >= 33 && hasCameraPermission() &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    override fun onResume() {
        super.onResume()
        orientationListener.enable()
        ui.post(infoTicker)
        ui.postDelayed(analysisTicker, 1500)
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(sensorListener, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        orientationListener.disable()
        ui.removeCallbacks(infoTicker)
        ui.removeCallbacks(analysisTicker)
        sensorManager.unregisterListener(sensorListener)
        recording?.stop()
        recording = null
        if (::shutter.isInitialized) shutter.recording = false
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        scope.cancel()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event?.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, list.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 10) return
        if (hasCameraPermission()) startCamera() else toast("Camera permission chahiye")
    }

    // ===================================================================== helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

    private fun fmtShutter(ns: Long): String {
        val s = ns / 1e9
        return if (s >= 0.5) String.format(Locale.US, "%.1fs", s) else "1/${(1.0 / s).roundToInt()}"
    }

    private fun txt(text: String, sizeSp: Float = 13f, color: Int = Color.WHITE): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sizeSp
        t.setTextColor(color)
        return t
    }

    private fun styleSel(v: TextView, sel: Boolean) {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(if (sel) ACCENT else 0x33FFFFFF)
        v.background = bg
        v.setTextColor(if (sel) Color.BLACK else Color.WHITE)
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = txt(text, 12f)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(6), dp(12), dp(6))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(3), dp(2), dp(3), dp(2))
        t.layoutParams = lp
        styleSel(t, false)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun hscroll(row: LinearLayout): HorizontalScrollView {
        val sv = HorizontalScrollView(this)
        sv.isHorizontalScrollBarEnabled = false
        sv.addView(row)
        return sv
    }

    private fun hrow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun vcol(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        return r
    }

    private fun sliderRow(
        title: String, max: Int, init: Int, fmt: (Int) -> String, onChange: (Int) -> Unit
    ): LinearLayout {
        val row = hrow()
        row.setPadding(dp(8), dp(2), dp(8), dp(2))
        val t = txt(title, 12f)
        t.layoutParams = LinearLayout.LayoutParams(dp(74), ViewGroup.LayoutParams.WRAP_CONTENT)
        val v = txt(fmt(init), 12f, ACCENT)
        v.gravity = Gravity.END
        v.layoutParams = LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.WRAP_CONTENT)
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = init
        sb.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                v.text = fmt(progress)
                if (fromUser) onChange(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        row.addView(t); row.addView(sb); row.addView(v)
        return row
    }

    // ===================================================================== UI
    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        // ---- top bar
        val top = hrow()
        top.setPadding(dp(4), dp(2), dp(4), dp(2))
        flashBtn = pill("⚡ OFF") { cycleFlash() }
        timerBtn = pill("⏱ OFF") { cycleTimer() }
        val gridBtn = pill("▦ GRID") { prefs.grid = !prefs.grid; gridView.visibility = if (prefs.grid) View.VISIBLE else View.GONE }
        val looksBtn = pill("🎨 LOOKS") { looksVisible = !looksVisible; updatePanels() }
        val setBtn = pill("⚙") { showSettings() }
        val anBtn = pill("📊 OFF") {}
        anBtn.setOnClickListener {
            prefs.analyzer = (prefs.analyzer + 1) % 4
            analyzer.level = prefs.analyzer
            anBtn.text = analyzerLabel(prefs.analyzer)
            styleSel(anBtn, prefs.analyzer != 0)
        }
        val lensBtn = pill("🔭 LENS") { cycleLens() }
        beautyBtn = pill("✨ BEAUTY") { showBeauty(lensFacing == CameraSelector.LENS_FACING_FRONT) }
        blurBtn = pill("🌫 BLUR") { showBlur() }
        detailBtn = pill("🔍 DETAILS") { showDetails() }
        val infoBtn = pill("ℹ") { showCameraInfo() }
        val fb0 = pill("⛶ FULL") { prefs.fullScreen = !prefs.fullScreen; applyFullScreen() }
        fullBtn = fb0
        styleSel(fb0, prefs.fullScreen)
        for (b in listOf(flashBtn, timerBtn, fb0, beautyBtn, blurBtn, detailBtn, anBtn, lensBtn, gridBtn, looksBtn, infoBtn, setBtn)) top.addView(b)
        val topSc = hscroll(top)
        topSv = topSc
        root.addView(topSc)
        refreshTopButtons()

        // ---- preview area
        val frame = FrameLayout(this)
        frameView = frame
        rootCol = root
        frame.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        previewView = PreviewView(this)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        frame.addView(previewView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        gridView = GridView(this)
        gridView.visibility = if (prefs.grid) View.VISIBLE else View.GONE
        gridView.isClickable = false
        frame.addView(gridView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        analyzer = AnalyzerView(this)
        analyzer.level = prefs.analyzer
        analyzer.isClickable = false
        frame.addView(analyzer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        anBtn.text = analyzerLabel(prefs.analyzer)
        styleSel(anBtn, prefs.analyzer != 0)

        infoTv = txt("", 11f, ACCENT)
        infoTv.setPadding(dp(8), dp(4), dp(8), dp(4))
        frame.addView(infoTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        screenFlash = View(this)
        screenFlash.setBackgroundColor(0xFFFFFFFF.toInt())
        screenFlash.visibility = View.GONE
        screenFlash.isClickable = false

        suggestionTv = txt("", 12f, 0xFFFFC107.toInt())
        suggestionTv.setPadding(dp(12), dp(6), dp(12), dp(6))
        val sgb = GradientDrawable()
        sgb.cornerRadius = dp(14).toFloat()
        sgb.setColor(0xAA000000.toInt())
        suggestionTv.background = sgb
        suggestionTv.visibility = View.GONE
        suggestionTv.setOnClickListener { suggestMode?.let { m -> setMode(m) } }
        val sglp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        sglp.topMargin = dp(26)
        frame.addView(suggestionTv, sglp)

        zoomTv = txt("1.0x", 12f)
        zoomTv.setPadding(dp(10), dp(4), dp(10), dp(4))
        frame.addView(zoomTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        statusTv = txt("", 18f)
        statusTv.gravity = Gravity.CENTER
        statusTv.setPadding(dp(16), dp(10), dp(16), dp(10))
        val sbg = GradientDrawable()
        sbg.cornerRadius = dp(14).toFloat()
        sbg.setColor(0x99000000.toInt())
        statusTv.background = sbg
        statusTv.visibility = View.GONE
        frame.addView(statusTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        focusRing = View(this)
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setStroke(dp(2), ACCENT)
        ring.setColor(Color.TRANSPARENT)
        focusRing.background = ring
        focusRing.visibility = View.GONE
        frame.addView(focusRing, FrameLayout.LayoutParams(dp(70), dp(70), Gravity.TOP or Gravity.START))

        setupGestures()
        frameIdx = root.indexOfChild(frame).let { if (it < 0) 1 else it }
        root.addView(frame)
        frameIdx = root.indexOfChild(frame)
        fsSpacer = View(this)

        // ---- panels
        looksPanel = buildLooksPanel()
        proPanel = buildProPanel()
        videoPanel = buildVideoPanel()
        portraitPanel = buildPortraitPanel()
        lapsePanel = buildLapsePanel()
        root.addView(looksPanel)
        root.addView(proPanel)
        root.addView(videoPanel)
        root.addView(portraitPanel)
        root.addView(lapsePanel)

        // ---- mode selector
        val modes = hrow()
        modes.gravity = Gravity.CENTER
        for (m in Mode.values()) {
            val p = pill(m.label) { setMode(m) }
            modePills[m] = p
            modes.addView(p)
        }
        val modesSc = hscroll(modes)
        modesSv = modesSc
        root.addView(modesSc)

        // ---- shutter row
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.setPadding(dp(16), dp(8), dp(16), dp(12))

        val thumbBox = FrameLayout(this)
        thumbBox.layoutParams = LinearLayout.LayoutParams(0, dp(60), 1f)
        thumb = ImageView(this)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        val tbg = GradientDrawable()
        tbg.cornerRadius = dp(12).toFloat()
        tbg.setColor(0x33FFFFFF)
        thumb.background = tbg
        thumb.clipToOutline = true
        thumb.outlineProvider = ViewOutlineProvider.BACKGROUND
        thumb.setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
        thumb.setOnLongClickListener { openLast(); true }
        thumbBox.addView(thumb, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER_VERTICAL or Gravity.START))
        busyTv = txt("", 12f, 0xFFFFC107.toInt())
        thumbBox.addView(busyTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL or Gravity.END))

        shutter = ShutterView(this)
        shutter.layoutParams = LinearLayout.LayoutParams(dp(78), dp(78))
        shutter.setOnClickListener { onShutter() }

        val flipBox = FrameLayout(this)
        flipBox.layoutParams = LinearLayout.LayoutParams(0, dp(60), 1f)
        val flip = txt("🔄", 26f)
        flip.gravity = Gravity.CENTER
        flip.setOnClickListener {
            focusU = 0.5f; focusV = 0.45f
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            refreshBeautyBtn()
            bindCamera(false)
        }
        flipBox.addView(flip, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER_VERTICAL or Gravity.END))

        bottom.addView(thumbBox)
        bottom.addView(shutter)
        bottom.addView(flipBox)
        root.addView(bottom)
        bottomBar = bottom

        val outer = FrameLayout(this)
        outer.setBackgroundColor(Color.BLACK)
        outer.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        outerRoot = outer
        setContentView(outer)
        applyFullScreen()
        setMode(Mode.AUTO, rebind = false)
        refreshLookPills()
    }

    private fun buildLooksPanel(): LinearLayout {
        val p = vcol()
        val row = hrow()
        for (lk in Looks.ALL) {
            val pl = pill(lk.name) {
                prefs.lookId = lk.id
                refreshLookPills()
                applyLookPreview()
            }
            lookPills[lk.id] = pl
            row.addView(pl)
        }
        p.addView(hscroll(row))
        p.addView(sliderRow("Look %", 100, prefs.lookIntensity, { "$it%" }) {
            prefs.lookIntensity = it
            applyLookPreview()
        })
        return p
    }

    private fun refreshLookPills() {
        for ((id, v) in lookPills) styleSel(v, id == prefs.lookId)
    }

    private fun buildProPanel(): LinearLayout {
        val p = vcol()
        val chips = hrow()
        val aeBtn = pill("EXPO: AUTO") {}
        aeBtn.setOnClickListener {
            if (tuner?.hasManual != true) { toast("Is camera me manual exposure supported nahi"); return@setOnClickListener }
            proManualAE = !proManualAE
            aeBtn.text = if (proManualAE) "EXPO: MANUAL" else "EXPO: AUTO"
            styleSel(aeBtn, proManualAE)
            applyPro()
        }
        val afBtn = pill("FOCUS: AUTO") {}
        afBtn.setOnClickListener {
            proManualAF = !proManualAF
            afBtn.text = if (proManualAF) "FOCUS: MANUAL" else "FOCUS: AUTO"
            styleSel(afBtn, proManualAF)
            applyPro()
        }
        val procBtn = pill("PROCESS: OFF") {}
        procBtn.setOnClickListener {
            prefs.proProcess = !prefs.proProcess
            procBtn.text = if (prefs.proProcess) "PROCESS: ON" else "PROCESS: OFF"
            styleSel(procBtn, prefs.proProcess)
        }
        procBtn.text = if (prefs.proProcess) "PROCESS: ON" else "PROCESS: OFF"
        styleSel(procBtn, prefs.proProcess)
        chips.addView(aeBtn); chips.addView(afBtn); chips.addView(procBtn)
        p.addView(hscroll(chips))

        val wb = hrow()
        val wbItems = listOf(
            "WB AUTO" to null,
            "☀ DAY" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
            "☁ CLOUD" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
            "💡 TUNGSTEN" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
            "FLUORESCENT" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
        )
        val wbViews = ArrayList<TextView>()
        for ((i, item) in wbItems.withIndex()) {
            val v = pill(item.first) {}
            v.setOnClickListener {
                proAwb = item.second
                for ((j, o) in wbViews.withIndex()) styleSel(o, j == i)
                applyPro()
            }
            styleSel(v, i == 0)
            wbViews.add(v)
            wb.addView(v)
        }
        p.addView(hscroll(wb))

        p.addView(sliderRow("EV", 24, 12, { v ->
            val st = camera?.cameraInfo?.exposureState
            if (st == null) "0.0" else {
                val r = st.exposureCompensationRange
                val idx = r.lower + (v * (r.upper - r.lower) / 24f).roundToInt()
                String.format(Locale.US, "%+.1f", idx * st.exposureCompensationStep.toFloat())
            }
        }) { v ->
            val cam = camera
            val st = cam?.cameraInfo?.exposureState
            if (cam != null && st != null && st.isExposureCompensationSupported) {
                val r = st.exposureCompensationRange
                cam.cameraControl.setExposureCompensationIndex(r.lower + (v * (r.upper - r.lower) / 24f).roundToInt())
            }
        })
        p.addView(sliderRow("ISO", 100, proIso, { "${isoFromP(it)}" }) { proIso = it; applyPro() })
        p.addView(sliderRow("SHUTTER", 100, proShut, { fmtShutter(expFromP(it)) }) { proShut = it; applyPro() })
        p.addView(sliderRow("FOCUS", 100, proFocus, { if (it == 0) "∞" else "$it%" }) { proFocus = it; applyPro() })
        return p
    }

    private fun isoFromP(p: Int): Int {
        val r = tuner?.isoRange ?: return 100
        return (r.lower * (r.upper.toDouble() / r.lower).pow(p / 100.0)).roundToInt()
    }

    private fun expFromP(p: Int): Long {
        val r = tuner?.expRange ?: return 10_000_000L
        val hi = min(r.upper, 2_000_000_000L).toDouble()
        val lo = max(r.lower, 100_000L).toDouble()
        return (lo * (hi / lo).pow(p / 100.0)).toLong()
    }

    private fun applyPro() {
        val t = tuner ?: return
        if (proManualAE && t.hasManual) t.setManualExposure(isoFromP(proIso), expFromP(proShut)) else t.setAutoExposure()
        if (proManualAF) t.setManualFocus(proFocus / 100f * t.minFocus) else t.setAutoFocus()
        t.setAwb(proAwb)
        t.commit()
    }

    private fun buildVideoPanel(): LinearLayout {
        val p = vcol()
        val row = hrow()
        val res = ArrayList<TextView>()
        val names = listOf("4K", "FHD 1080p", "HD 720p")
        for ((i, n) in names.withIndex()) {
            val v = pill(n) {}
            v.setOnClickListener {
                prefs.videoRes = i
                for ((j, o) in res.withIndex()) styleSel(o, j == i)
                bindCamera(false)
            }
            styleSel(v, i == prefs.videoRes)
            res.add(v)
            row.addView(v)
        }
        val steady = pill("SUPER STEADY") {}
        steady.setOnClickListener {
            prefs.superSteady = !prefs.superSteady
            styleSel(steady, prefs.superSteady)
            reapplyTuning()
        }
        styleSel(steady, prefs.superSteady)
        val low = pill("LOW-LIGHT") {}
        low.setOnClickListener {
            prefs.videoLowLight = !prefs.videoLowLight
            styleSel(low, prefs.videoLowLight)
            reapplyTuning()
        }
        styleSel(low, prefs.videoLowLight)
        val f60 = pill("60 FPS") {}
        f60.setOnClickListener {
            prefs.video60 = !prefs.video60
            styleSel(f60, prefs.video60)
            bindCamera(false)
        }
        styleSel(f60, prefs.video60)
        val hdr10 = pill("HDR10") {}
        hdr10.setOnClickListener {
            prefs.videoHdr = !prefs.videoHdr
            styleSel(hdr10, prefs.videoHdr)
            bindCamera(false)
        }
        styleSel(hdr10, prefs.videoHdr)
        row.addView(steady); row.addView(low); row.addView(f60); row.addView(hdr10)
        p.addView(hscroll(row))
        return p
    }

    private fun buildPortraitPanel(): LinearLayout {
        val p = vcol()
        p.addView(sliderRow("Bokeh", 100, prefs.bokeh, { "$it%" }) { prefs.bokeh = it })
        val t = txt("Person ke saamne rakho. People detect hote hain, baaki background blur hota hai.", 11f, 0xFFAAAAAA.toInt())
        t.setPadding(dp(12), 0, dp(12), dp(4))
        p.addView(t)
        return p
    }

    private fun buildLapsePanel(): LinearLayout {
        val p = vcol()
        val r1 = hrow()
        val ints = listOf(2, 5, 10, 30, 60)
        val iv = ArrayList<TextView>()
        for ((i, sec) in ints.withIndex()) {
            val v = pill("${sec}s") {}
            v.setOnClickListener {
                prefs.lapseInterval = sec
                for ((j, o) in iv.withIndex()) styleSel(o, j == i)
            }
            styleSel(v, sec == prefs.lapseInterval)
            iv.add(v)
            r1.addView(v)
        }
        val r2 = hrow()
        val counts = listOf(30, 100, 300, 0)
        val cv = ArrayList<TextView>()
        for ((i, c) in counts.withIndex()) {
            val v = pill(if (c == 0) "∞ frames" else "$c frames") {}
            v.setOnClickListener {
                prefs.lapseCount = c
                for ((j, o) in cv.withIndex()) styleSel(o, j == i)
            }
            styleSel(v, c == prefs.lapseCount)
            cv.add(v)
            r2.addView(v)
        }
        p.addView(hscroll(r1))
        p.addView(hscroll(r2))
        return p
    }

    private fun analyzerLabel(l: Int): String = when (l) {
        1 -> "📊 HIST"
        2 -> "📊 +PEAK"
        3 -> "📊 +ZEBRA"
        else -> "📊 OFF"
    }

    private fun updatePanels() {
        looksPanel.visibility = if (looksVisible && mode != Mode.VIDEO && mode != Mode.LAPSE) View.VISIBLE else View.GONE
        proPanel.visibility = if (mode == Mode.PRO) View.VISIBLE else View.GONE
        videoPanel.visibility = if (mode == Mode.VIDEO) View.VISIBLE else View.GONE
        portraitPanel.visibility = if (mode == Mode.PORTRAIT) View.VISIBLE else View.GONE
        lapsePanel.visibility = if (mode == Mode.LAPSE) View.VISIBLE else View.GONE
    }

    private fun refreshTopButtons() {
        flashBtn.text = when (prefs.flash) { 1 -> "⚡ AUTO"; 2 -> "⚡ ON"; else -> "⚡ OFF" }
        timerBtn.text = if (prefs.timer == 0) "⏱ OFF" else "⏱ ${prefs.timer}s"
        styleSel(flashBtn, prefs.flash != 0)
        styleSel(timerBtn, prefs.timer != 0)
        refreshBeautyBtn()
    }

    private fun refreshBeautyBtn() {
        if (!::beautyBtn.isInitialized) return
        val front = lensFacing == CameraSelector.LENS_FACING_FRONT
        val on = prefs.beautyOn(front)
        beautyBtn.text = "✨ ${if (front) "FRONT" else "BACK"} ${if (on) "ON" else "OFF"}"
        styleSel(beautyBtn, on)
        refreshBlurDetailBtns()
    }

    private fun refreshBlurDetailBtns() {
        if (!::blurBtn.isInitialized || !::detailBtn.isInitialized) return
        blurBtn.text = if (prefs.focusBlur) "🌫 BLUR ${prefs.focusBlurAmt}%" else "🌫 BLUR OFF"
        styleSel(blurBtn, prefs.focusBlur)
        detailBtn.text = if (prefs.autoDetail) "🔍 DETAILS AUTO" else "🔍 DETAILS MANUAL"
        styleSel(detailBtn, prefs.autoDetail)
    }

    private fun cycleFlash() {
        prefs.flash = (prefs.flash + 1) % 3
        refreshTopButtons()
        if (mode != Mode.VIDEO && fastCapture() != boundFast) bindCamera(false)
        applyFlash()
        reapplyTuning()
        if (prefs.flash != 0 && lensFacing == CameraSelector.LENS_FACING_BACK && mode != Mode.PANO && mode != Mode.LAPSE && mode != Mode.VIDEO) {
            toast("Flash: multi-frame modes me LED steady torch ki tarah chalti hai")
        }
        if (prefs.flash != 0 && lensFacing == CameraSelector.LENS_FACING_FRONT) {
            toast("Front me LED flash nahi hota, screen flash use hoga")
        }
    }

    private fun cycleTimer() {
        prefs.timer = when (prefs.timer) { 0 -> 3; 3 -> 10; else -> 0 }
        refreshTopButtons()
    }

    private fun applyFlash() {
        if (mode == Mode.VIDEO) {
            camera?.cameraControl?.enableTorch(prefs.flash == 2)
        } else {
            imageCapture?.flashMode = when (prefs.flash) {
                1 -> ImageCapture.FLASH_MODE_AUTO
                2 -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }
    }

    private fun setStatus(t: String?) {
        if (t == null) {
            statusTv.visibility = View.GONE
        } else {
            statusTv.text = t
            statusTv.visibility = View.VISIBLE
        }
    }

    private fun refreshBusy() {
        busyTv.text = ""
    }

    private fun setMode(m: Mode, rebind: Boolean = true) {
        val wasVideo = mode == Mode.VIDEO
        mode = m
        for ((k, v) in modePills) styleSel(v, k == m)
        shutter.video = m == Mode.VIDEO
        updatePanels()
        if (rebind) {
            when (m) {
                Mode.ASTRO, Mode.TRAILS -> toast("Tripod pe rakho, andhere me; long exposure")
                Mode.PANO -> toast("Shutter dabao, dheere pan karo, dobara dabao = stop")
                Mode.SCAN -> toast("Document seedha rakho, achhi roshni me")
                Mode.PORTRAIT -> toast("Person ko frame me rakho")
                Mode.UNIGHT -> toast("ULTRA NIGHT: bahut andhere ke liye — phone 5-8 sec steady (tripod best)")
                Mode.WIDE -> toast("Main + ultra-wide dono se shoot hota hai — phone ko 3-4 sec steady rakho")
                else -> {}
            }
        }
        if (rebind && cameraProvider != null) {
            val isVideo = m == Mode.VIDEO
            val needsRebind = wasVideo != isVideo || (!isVideo && (effectiveCapRes() != boundCapRes || fastCapture() != boundFast))
            if (needsRebind) bindCamera(false) else reapplyTuning()
        }
    }

    // ===================================================================== gestures
    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val z = cam.cameraInfo.zoomState.value ?: return true
                val nr = (z.zoomRatio * detector.scaleFactor).coerceIn(z.minZoomRatio, z.maxZoomRatio)
                cam.cameraControl.setZoomRatio(nr)
                return true
            }
        })
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    /** Full-screen: preview fills the whole screen (controls float on top, status/nav bars hidden); photos are cropped to the screen shape when saved. */
    private fun applyFullScreen() {
        val on = prefs.fullScreen
        val fr = frameView ?: return
        val rc = rootCol ?: return
        val oc = outerRoot ?: return
        val sp = fsSpacer ?: return
        val inFull = fr.parent === oc
        val full = ViewGroup.LayoutParams.MATCH_PARENT
        if (on && !inFull) {
            rc.removeView(fr)
            oc.addView(fr, 0, FrameLayout.LayoutParams(full, full))
            rc.addView(sp, frameIdx.coerceIn(0, rc.childCount), LinearLayout.LayoutParams(full, 0, 1f))
        } else if (!on && inFull) {
            oc.removeView(fr)
            rc.removeView(sp)
            rc.addView(fr, frameIdx.coerceIn(0, rc.childCount), LinearLayout.LayoutParams(full, 0, 1f))
        }
        val scrim = if (on) 0x66000000 else 0
        rc.setBackgroundColor(if (on) Color.TRANSPARENT else Color.BLACK)
        rc.setPadding(0, if (on) dp(26) else 0, 0, 0)
        topSv?.setBackgroundColor(scrim)
        modesSv?.setBackgroundColor(scrim)
        bottomBar?.setBackgroundColor(scrim)
        val panelBg = if (on) 0x99000000.toInt() else 0
        for (v in listOf(looksPanel, proPanel, videoPanel, portraitPanel, lapsePanel)) v.setBackgroundColor(panelBg)
        previewView.scaleType = if (on) PreviewView.ScaleType.FILL_CENTER else PreviewView.ScaleType.FIT_CENTER
        fullBtn?.let { styleSel(it, on) }
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                window.attributes = lp
            }
            WindowCompat.setDecorFitsSystemWindows(window, !on)
            val ic = WindowInsetsControllerCompat(window, window.decorView)
            if (on) {
                ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ic.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                ic.show(WindowInsetsCompat.Type.systemBars())
            }
        } catch (t: Throwable) { Log.w(TAG, "fullscreen", t) }
    }

    /** Crop the finished photo to the screen shape (full-screen mode) so what you saw is what you get. */
    private fun cropToScreen(bmp: Bitmap, orientation: Int): Bitmap {
        val dm = resources.displayMetrics
        val sw = min(dm.widthPixels, dm.heightPixels).toFloat()
        val sh = max(dm.widthPixels, dm.heightPixels).toFloat()
        val rot = degreesFor(orientation)
        val swapped = rot == 90 || rot == 270
        val uw = if (swapped) bmp.height else bmp.width
        val uh = if (swapped) bmp.width else bmp.height
        val ta = if (uw >= uh) sh / sw else sw / sh          // target width/height of the upright photo
        val tgt = if (swapped) 1f / ta else ta                // same, in stored-bitmap terms
        val cur = bmp.width.toFloat() / bmp.height
        var cw = bmp.width
        var ch = bmp.height
        if (cur > tgt) cw = (bmp.height * tgt).roundToInt().coerceIn(8, bmp.width)
        else ch = (bmp.width / tgt).roundToInt().coerceIn(8, bmp.height)
        if (cw == bmp.width && ch == bmp.height) return bmp
        return Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch)
    }

    /** Preview (FIT_CENTER, portrait 4:3) view coordinates -> 0..1 position inside the image (front: mirrored preview). */
    private fun viewToImage(x: Float, y: Float): Pair<Float, Float> {
        val vw = previewView.width.toFloat()
        val vh = previewView.height.toFloat()
        if (vw <= 0f || vh <= 0f) return Pair(0.5f, 0.45f)
        val ar = 3f / 4f
        val cw: Float
        val ch: Float
        if (prefs.fullScreen) {
            // FILL_CENTER: image covers the view, edges are cropped
            if (vw / vh > ar) { cw = vw; ch = vw / ar } else { ch = vh; cw = vh * ar }
        } else {
            if (vw / vh > ar) { ch = vh; cw = vh * ar } else { cw = vw; ch = vw / ar }
        }
        val ox = (vw - cw) / 2f
        val oy = (vh - ch) / 2f
        var u = ((x - ox) / cw).coerceIn(0f, 1f)
        val v = ((y - oy) / ch).coerceIn(0f, 1f)
        if (lensFacing == CameraSelector.LENS_FACING_FRONT) u = 1f - u
        return Pair(u, v)
    }

    /** Last tapped focus point expressed in the UPRIGHT saved photo (accounts for how the phone was held). */
    private fun focusPointFor(rot: Int): Pair<Float, Float> {
        val so = try {
            currentCameraId()?.let { cameraManager().getCameraCharacteristics(it).get(CameraCharacteristics.SENSOR_ORIENTATION) } ?: 90
        } catch (e: Exception) { 90 }
        val extra = (((rot - so) % 360) + 360) % 360
        val u = focusU
        val v = focusV
        return when (extra) {
            90 -> Pair(1f - v, u)
            180 -> Pair(1f - u, 1f - v)
            270 -> Pair(v, 1f - u)
            else -> Pair(u, v)
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        lastTapX = x; lastTapY = y; lastTapMs = System.currentTimeMillis()
        val fp = viewToImage(x, y)
        focusU = fp.first; focusV = fp.second
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            val action = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB
            ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
            cam.cameraControl.startFocusAndMetering(action)
        } catch (e: Exception) {
            Log.w(TAG, "focus", e)
        }
        focusRing.translationX = x - dp(35)
        focusRing.translationY = y - dp(35)
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.animate().alpha(0f).setDuration(900).start()
    }

    // ===================================================================== camera binding
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            cameraProvider = f.get()
            bindCamera(false)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun effectiveCapRes(): Int =
        if (mode == Mode.AUTO || mode == Mode.PRO || mode == Mode.LAPSE) prefs.capRes else min(prefs.capRes, 1)

    /** AUTO takes a quick multi-frame burst (noise-free merge) unless MAX direct-JPEG or flash is used. */
    private fun autoBurst(): Boolean = mode == Mode.AUTO && prefs.smartAuto && prefs.capRes != 2 &&
        (prefs.flash == 0 || lensFacing == CameraSelector.LENS_FACING_FRONT)

    private fun fastCapture(): Boolean = autoBurst() || mode == Mode.ULTRA || mode == Mode.WIDE || mode == Mode.NIGHT || mode == Mode.UNIGHT

    private fun isStackMode(): Boolean =
        autoBurst() || mode == Mode.ULTRA || mode == Mode.WIDE || mode == Mode.NIGHT || mode == Mode.UNIGHT || mode == Mode.ASTRO || mode == Mode.TRAILS || mode == Mode.PORTRAIT

    private fun bindCamera(safe: Boolean) {
        val provider = cameraProvider ?: return
        try {
            provider.unbindAll()
            val video = mode == Mode.VIDEO
            val ratio = if (video) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
            else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            val prevSel = ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build()
            val pb = Preview.Builder().setResolutionSelector(prevSel)
            if (video && !safe && prefs.superSteady) tryInvoke(pb, "setPreviewStabilizationEnabled", java.lang.Boolean.TYPE, true)
            Camera2Interop.Extender(pb).setSessionCaptureCallback(previewCb)
            val preview = pb.build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val sel = CameraSelector.Builder().requireLensFacing(lensFacing)
            val lid = lensId
            if (!safe && lid != null && lensFacing == CameraSelector.LENS_FACING_BACK) {
                sel.addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == lid } }
            }
            val selector = sel.build()

            if (video) {
                imageCapture = null
                val q = when (prefs.videoRes) { 0 -> Quality.UHD; 1 -> Quality.FHD; else -> Quality.HD }
                val qs = QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
                val rec = Recorder.Builder().setQualitySelector(qs).build()
                val vb = VideoCapture.Builder(rec)
                if (!safe) {
                    // let CameraX pick the best stabilization the phone really supports (preview-stab / EIS)
                    tryInvoke(vb, "setVideoStabilizationEnabled", java.lang.Boolean.TYPE, prefs.superSteady)
                    if (prefs.video60) tryInvoke(vb, "setTargetFrameRate", Range::class.java, Range(60, 60))
                    if (prefs.videoHdr) setHdr(vb)
                }
                val vc = vb.build()
                videoCapture = vc
                camera = provider.bindToLifecycle(this, selector, preview, vc)
                try {
                    val ci = Camera2CameraInfo.from(camera!!.cameraInfo)
                    val vs = ci.getCameraCharacteristic(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                    val ois = ci.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                    val eis = vs?.contains(1) == true
                    val prv = vs?.contains(2) == true
                    val o = ois?.contains(1) == true
                    val msg = "Stabilization • EIS: ${if (eis) "haan" else "nahi"} • Preview-stab: ${if (prv) "haan" else "nahi"} • OIS: ${if (o) "haan" else "nahi"}"
                    Log.i(TAG, msg)
                    toast(msg)
                } catch (t: Throwable) { Log.w(TAG, "stab info", t) }
            } else {
                videoCapture = null
                val target = when (effectiveCapRes()) {
                    0 -> Size(4000, 3000)
                    1 -> Size(4608, 3456)
                    else -> Size(9248, 6936)
                }
                boundCapRes = effectiveCapRes()
                boundFast = fastCapture()
                val icb = ImageCapture.Builder().setCaptureMode(
                    if (boundFast) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                )
                if (boundFast) icb.setJpegQuality(93)
                if (!safe) {
                    val rs = ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                        .setResolutionStrategy(
                            ResolutionStrategy(target, ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        ).build()
                    icb.setResolutionSelector(rs)
                }
                val ic = icb.build()
                imageCapture = ic
                camera = provider.bindToLifecycle(this, selector, preview, ic)
            }
            onBound()
        } catch (e: Exception) {
            Log.e(TAG, "bind failed (safe=$safe)", e)
            if (!safe) { lensId = null; bindCamera(true) } else toast("Camera start nahi hua: ${e.message}")
        }
    }

    private fun onBound() {
        val cam = camera ?: return
        tuner = CameraTuner(cam)
        aiShutter = ShutterBias.AUTO
        reapplyTuning()
        applyFlash()
        cam.cameraInfo.zoomState.removeObservers(this)
        cam.cameraInfo.zoomState.observe(this) { z ->
            zoomTv.text = String.format(Locale.US, "%.1fx", z.zoomRatio)
        }
        previewView.previewStreamState.removeObservers(this)
        previewView.previewStreamState.observe(this) { st ->
            if (st == PreviewView.StreamState.STREAMING) applyLookPreview()
        }
    }

    private fun reapplyTuning() {
        val t = tuner ?: return
        t.allowLowFps = lensFacing == CameraSelector.LENS_FACING_BACK && mode != Mode.NIGHT && mode != Mode.UNIGHT
        t.applyDefaults(
            stack = isStackMode(),
            video = mode == Mode.VIDEO,
            superSteady = prefs.superSteady,
            lowLightVideo = prefs.videoLowLight
        )
        if (mode == Mode.PRO) applyPro()
    }

    // ---- live (approximate) look preview through TextureView layer paint
    private fun findTextureView(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val r = findTextureView(v.getChildAt(i))
                if (r != null) return r
            }
        }
        return null
    }

    private fun applyLookPreview() {
        try {
            val tv = findTextureView(previewView) ?: return
            val look = Looks.byId(prefs.lookId)
            val t = prefs.lookIntensity / 100f
            val sat = if (look.mono) 1f - t else 1f + (look.sat - 1f) * t
            val c = 1f + (look.contrast - 1f) * t
            val off = 128f * (1f - c) + look.bright * t * 45f
            val temp = look.temp * t
            val cm = ColorMatrix()
            cm.setSaturation(max(0f, sat))
            cm.postConcat(ColorMatrix(floatArrayOf(
                c * (1f + 0.10f * temp), 0f, 0f, 0f, off,
                0f, c, 0f, 0f, off,
                0f, 0f, c * (1f - 0.10f * temp), 0f, off,
                0f, 0f, 0f, 1f, 0f
            )))
            val p = Paint()
            p.colorFilter = ColorMatrixColorFilter(cm)
            tv.setLayerPaint(p)
        } catch (e: Exception) {
            Log.w(TAG, "look preview", e)
        }
    }

    // ===================================================================== shooting
    private fun onShutter() {
        if (mode == Mode.VIDEO) { toggleRecording(); return }
        if (mode == Mode.LAPSE) { toggleLapse(); return }
        if (mode == Mode.PANO) { togglePano(); return }
        if (shooting || imageCapture == null) return
        val delaySec = prefs.timer
        scope.launch {
            shooting = true
            shutter.busy = true
            try {
                if (delaySec > 0) {
                    for (s in delaySec downTo 1) { setStatus("$s"); delay(1000) }
                }
                val rawDone = if (rawModeOk(mode)) shootRaw() else false
                if (!rawDone) shootJpegPath()
            } catch (e: Exception) {
                Log.e(TAG, "shoot", e)
                toast("Capture error: ${e.message}")
            } finally {
                shooting = false
                shutter.busy = false
                setStatus(null)
                applyFlash()
            }
        }
    }

    /** Flash button state for THIS shot: ON = yes, AUTO = only when the scene is dark, OFF = no. Works in every mode. */
    private fun flashWanted(): Boolean = when (prefs.flash) {
        2 -> true
        1 -> meta.iso >= 800 || centerLuma < 80f
        else -> false
    }

    /** Modes that go through the RAW engine (PANO / LAPSE / TRAILS / VIDEO need a continuous camera session -> JPEG). */
    private fun rawModeOk(m: Mode): Boolean = m == Mode.AUTO || m == Mode.ULTRA || m == Mode.WIDE || m == Mode.NIGHT || m == Mode.UNIGHT ||
        m == Mode.HDR || m == Mode.PORTRAIT || m == Mode.PRO || m == Mode.ASTRO || m == Mode.SCAN

    /** JPEG fallback (used when RAW is unavailable / fails / mode has no RAW path). Front camera: soft screen flash in every mode. */
    private suspend fun shootJpegPath() {
        val front = lensFacing == CameraSelector.LENS_FACING_FRONT
        val sf = front && flashWanted() && mode != Mode.AUTO && mode != Mode.NIGHT && mode != Mode.UNIGHT
        if (sf) { setScreenFlash(true); delay(650) }
        try {
            when (mode) {
                Mode.AUTO -> shootAuto()
                Mode.ULTRA -> shootStack(4, ProcMode.STACK)
                Mode.WIDE -> shootWide()
                Mode.NIGHT -> shootNight(false)
                Mode.UNIGHT -> shootNight(true)
                Mode.HDR -> shootHdr()
                Mode.PRO -> shootPro()
                Mode.PORTRAIT -> shootPortrait()
                Mode.ASTRO -> shootAstro(false)
                Mode.TRAILS -> shootAstro(true)
                Mode.SCAN -> shootScan()
                else -> {}
            }
        } finally {
            if (sf) setScreenFlash(false)
        }
    }

    private fun frameFile(i: Int): File {
        val dir = File(cacheDir, "frames")
        dir.mkdirs()
        return File(dir, "f_${System.nanoTime()}_$i.jpg")
    }

    private suspend fun takePictureToFile(file: File): Boolean = suspendCancellableCoroutine { cont ->
        val ic = imageCapture
        if (ic == null) {
            cont.resume(false)
        } else {
            val o = ImageCapture.OutputFileOptions.Builder(file).build()
            ic.takePicture(o, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    if (cont.isActive) cont.resume(true)
                }
                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "takePicture", exception)
                    if (cont.isActive) cont.resume(false)
                }
            })
        }
    }

    private fun smartFrameCount(): Int {
        val iso = meta.iso
        val e = meta.expNs
        return when {
            iso <= 0 -> 4
            iso <= 150 && e < 8_000_000L -> 3
            iso <= 450 -> 4
            iso <= 1000 -> 5
            else -> 6
        }
    }

    /** Picks the most detailed, well-exposed, centre-weighted spot of the preview (unless the user tapped recently). */
    private fun pickFocusPoint(): Pair<Float, Float>? {
        val vw = previewView.width.toFloat()
        val vh = previewView.height.toFloat()
        if (vw <= 0f || vh <= 0f) return null
        if (System.currentTimeMillis() - lastTapMs < 15_000L) return Pair(lastTapX, lastTapY)
        // selfie: the face is almost always upper-centre; meter exposure + focus there
        if (lensFacing == CameraSelector.LENS_FACING_FRONT) return Pair(vw / 2f, vh * 0.45f)
        val full = previewView.bitmap ?: return null
        val gw = 64
        val gh = max(8, (gw * full.height / full.width.toFloat()).roundToInt())
        val small = Bitmap.createScaledBitmap(full, gw, gh, true)
        if (small !== full) full.recycle()
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)
        small.recycle()
        val lum = FloatArray(gw * gh) {
            val p = px[it]
            0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
        }
        val cx = 8
        val cy = 6
        var best = -1f
        var bi = cx / 2
        var bj = cy / 2
        for (j in 0 until cy) {
            for (i in 0 until cx) {
                val x0 = i * gw / cx
                val x1 = (i + 1) * gw / cx
                val y0 = j * gh / cy
                val y1 = (j + 1) * gh / cy
                var e = 0f
                var m = 0f
                var n = 0
                for (y in y0 until min(y1, gh - 1)) {
                    for (x in x0 until min(x1, gw - 1)) {
                        val k = y * gw + x
                        e += abs(lum[k + 1] - lum[k]) + abs(lum[k + gw] - lum[k])
                        m += lum[k]
                        n++
                    }
                }
                if (n == 0) continue
                m /= n
                val dx = (i + 0.5f) / cx - 0.5f
                val dy = (j + 0.5f) / cy - 0.5f
                val centre = 1f - 0.9f * sqrt(dx * dx + dy * dy)
                val expo = if (m < 25f || m > 240f) 0.3f else 1f
                val score = e / n * centre * expo
                if (score > best) { best = score; bi = i; bj = j }
            }
        }
        if (best < 3f) return Pair(vw / 2f, vh / 2f)
        return Pair((bi + 0.5f) / cx * vw, (bj + 0.5f) / cy * vh)
    }

    /** Smart focus: lock AF/AE on the best spot and wait (max 1.5 s) before shooting. */
    private suspend fun smartFocus() {
        val cam = camera ?: return
        if (mode == Mode.PRO && proManualAF) return
        try {
            val pt = pickFocusPoint() ?: return
            val mp = previewView.meteringPointFactory.createPoint(pt.first, pt.second)
            val action = FocusMeteringAction.Builder(
                mp, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE or FocusMeteringAction.FLAG_AWB
            ).setAutoCancelDuration(4, TimeUnit.SECONDS).build()
            val fut = cam.cameraControl.startFocusAndMetering(action)
            setStatus("Focus lock…")
            withTimeoutOrNull(1500L) {
                suspendCancellableCoroutine<Boolean> { c ->
                    fut.addListener({ if (c.isActive) c.resume(true) }, ContextCompat.getMainExecutor(this@MainActivity))
                }
            }
            delay(100)
        } catch (e: Exception) {
            Log.w(TAG, "smartFocus", e)
        }
    }

    /** Flash / no-flash fusion: 2 frames without flash, then 1 with flash; all merged (exposure fusion) into one photo. */
    private suspend fun shootFlashFusion(front: Boolean) {
        val files = ArrayList<File>()
        try {
            imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
            smartFocus()
            for (i in 0 until 2) {
                setStatus("Flash fusion • bina flash ${i + 1}/2")
                val f = frameFile(i)
                if (takePictureToFile(f)) files.add(f)
            }
            setStatus("Flash fusion • flash wali frame")
            val ff = frameFile(2)
            if (front) {
                setScreenFlash(true)
                delay(450)
            } else {
                imageCapture?.flashMode = ImageCapture.FLASH_MODE_ON
            }
            try {
                if (takePictureToFile(ff)) files.add(ff)
            } finally {
                if (front) setScreenFlash(false)
                imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
            }
        } finally {
            applyFlash()
        }
        when {
            files.size >= 3 -> finishBurst(files, ProcMode.HDR)
            files.size == 2 -> finishBurst(files, ProcMode.STACK)
            files.size == 1 -> finishBurst(files, ProcMode.SINGLE)
            else -> toast("Capture failed")
        }
    }

    private suspend fun shootAuto() {
        val isFront = lensFacing == CameraSelector.LENS_FACING_FRONT
        if (!isFront && prefs.smartAuto && prefs.flash != 0 && prefs.capRes != 2 &&
            camera?.cameraInfo?.hasFlashUnit() == true) {
            try { analyzeFrame() } catch (e: Exception) { Log.w(TAG, "fusion analyze", e) }
            val darkScene = meta.iso >= 800 || centerLuma < 80f
            if (prefs.flash == 2 || darkScene) {
                shootFlashFusion(isFront)
                return
            }
        }
        if (autoBurst()) {
            // ---- Auto Pilot: analyse the scene right now and pick the settings for THIS shot ----
            val front = lensFacing == CameraSelector.LENS_FACING_FRONT
            val useScreenFlash = front && (prefs.flash == 2 || (prefs.flash == 1 && (meta.iso >= 800 || centerLuma < 80f)))
            if (useScreenFlash) { setScreenFlash(true); delay(650) }
            try {
                try { analyzeFrame() } catch (e: Exception) { Log.w(TAG, "pilot analyze", e) }
                val cam = camera
                if (prefs.aiDirector) {
                    aiPlan = AiDirector.plan(currentStats(), prefs.bokeh / 100f)
                    setStatus("AI • " + aiPlan.reason)
                }
                val st = cam?.cameraInfo?.exposureState
                val evOk = st != null && st.isExposureCompensationSupported && st.exposureCompensationStep.toFloat() > 0f
                // 1) high-contrast scene: bracket instead of one blown frame
                if (!front && evOk && analyzer.highPct > 4f && analyzer.shadowPct > 8f && meta.iso < 1600) {
                    setStatus("Auto Pilot • HDR scene")
                    smartFocus()
                    shootHdr()
                    return
                }
                smartFocus()
                // 2) exposure: lift dark scenes / faces; protect highlights (shadows are lifted later in processing)
                val baseIdx = if (evOk) st!!.exposureCompensationIndex else 0
                var changed = false
                if (evOk && cam != null) {
                    val meanUsed = if (front) centerLuma else analyzer.meanLuma
                    val target = if (front) 100f else 105f
                    var ev = (Math.log((target / max(meanUsed, 8f)).toDouble()) / Math.log(2.0)).toFloat()
                    if (!front && analyzer.highPct > 5f) {
                        ev = min(ev, -(0.4f + min(analyzer.highPct, 20f) / 20f * 0.9f))
                    }
                    val maxUp = if (!front && analyzer.highPct > 3f) 0.3f else if (front) (if (useScreenFlash) 0.5f else 1.5f) else 1.3f
                    ev = ev.coerceIn(-1.3f, maxUp)
                    if (abs(ev) >= 0.3f) {
                        val rg = st!!.exposureCompensationRange
                        val idx = (baseIdx + ev / st.exposureCompensationStep.toFloat()).roundToInt().coerceIn(rg.lower, rg.upper)
                        cam.cameraControl.setExposureCompensationIndex(idx)
                        delay(350)
                        changed = true
                    }
                }
                try {
                    // 3) frames by noise level (front sensor is noisier -> one extra frame)
                    val nFrames = (if (useScreenFlash) 4 else if (prefs.aiDirector) aiPlan.frames else smartFrameCount() + (if (front) 1 else 0)).coerceAtMost(4)
                    val files = burst(nFrames, if (useScreenFlash) "Screen flash • selfie" else "Auto Pilot • hold steady")
                    finishBurst(files, ProcMode.STACK)
                } finally {
                    if (changed) camera?.cameraControl?.setExposureCompensationIndex(baseIdx)
                }
            } finally {
                if (useScreenFlash) setScreenFlash(false)
            }
            return
        }
        applyFlash()
        setStatus("Capturing…")
        val f = frameFile(0)
        if (!takePictureToFile(f)) { toast("Capture failed"); return }
        if (effectiveCapRes() == 2) {
            withContext(Dispatchers.IO) { saveFileToGallery(f) }
            f.delete()
        } else {
            enqueue(listOf(f), ProcMode.SINGLE)
        }
    }

    private suspend fun burst(n: Int, label: String): List<File> {
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        val files = ArrayList<File>()
        // multi-frame modes can't fire a real flash per frame; with flash ON use the LED as a steady torch instead
        val torch = flashWanted() && lensFacing == CameraSelector.LENS_FACING_BACK &&
            camera?.cameraInfo?.hasFlashUnit() == true
        if (torch) {
            camera?.cameraControl?.enableTorch(true)
            delay(400)
        }
        try {
            for (i in 0 until n) {
                setStatus("$label ${i + 1}/$n")
                val f = frameFile(i)
                if (takePictureToFile(f)) files.add(f)
            }
        } finally {
            if (torch) camera?.cameraControl?.enableTorch(false)
        }
        return files
    }

    private suspend fun shootStack(n: Int, pm: ProcMode) {
        val files = burst(n, "Hold steady")
        finishBurst(files, pm)
    }

    /**
     * ULTRA-WIDE mode: burst from the main lens, then a burst from the ultra-wide lens (CameraX if the phone lists it,
     * otherwise a direct Camera2 open of the hidden id). The two merged results are fused in enqueue():
     * ultra-wide field of view + main-lens detail in the middle. If the ultra-wide cannot be opened we fall back to a normal merge.
     */
    private suspend fun shootWide() {
        if (lensFacing == CameraSelector.LENS_FACING_FRONT) {
            toast("Ultra-wide sirf back camera me hai — normal ULTRA merge")
            shootStack(4, ProcMode.STACK)
            return
        }
        val lenses = try { Lenses.discover(cameraManager()) } catch (e: Throwable) { emptyList() }
        val curId = currentCameraId()
        val uw = lenses.firstOrNull { it.role == "Ultra-wide" && it.isImage }
        if (uw == null || uw.id == curId) {
            toast(if (uw == null) "Is phone me ultra-wide sensor nahi mila — normal ULTRA merge" else "Abhi ultra-wide hi selected hai — normal merge")
            shootStack(4, ProcMode.STACK)
            return
        }
        try { analyzeFrame() } catch (e: Exception) { Log.w(TAG, "wide analyze", e) }
        if (prefs.aiDirector) aiPlan = AiDirector.plan(currentStats(), prefs.bokeh / 100f)
        smartFocus()
        val nMain = (if (prefs.aiDirector) aiPlan.frames + 1 else smartFrameCount() + 1).coerceIn(4, 6)
        val nUw = (if (prefs.aiDirector) aiPlan.frames else smartFrameCount()).coerceIn(3, 5)
        val mainFiles = burst(nMain, "Wide 1/2 • main lens")
        if (mainFiles.isEmpty()) { toast("Capture failed"); return }

        var uwFiles: List<File> = emptyList()
        if (uw.usable) {
            val prev = lensId
            try {
                lensId = uw.id
                bindCamera(false)
                delay(1000)
                uwFiles = burst(nUw, "Wide 2/2 • ultra-wide lens")
            } finally {
                lensId = prev
                bindCamera(false)
            }
        } else {
            setStatus("Wide 2/2 • ultra-wide lens kholne ka try…")
            val sensorDev = devDeg
            cameraProvider?.unbindAll()
            delay(450)
            try {
                uwFiles = UwCapture.capture(cameraManager(), uw.id, nUw, sensorDev, File(cacheDir, "frames"), { s -> setStatus(s) })
            } catch (e: Throwable) {
                Log.w(TAG, "uw direct", e)
            }
            bindCamera(false)
        }
        if (uwFiles.isEmpty()) {
            toast("Phone ne ultra-wide camera app ko nahi diya — sirf main lens ka merge save ho raha hai")
            finishBurst(mainFiles, ProcMode.STACK)
            return
        }
        enqueue(mainFiles, ProcMode.STACK, wideFiles = uwFiles)
    }

    private fun finishBurst(files: List<File>, pm: ProcMode, portrait: Boolean = false) {
        if (files.isEmpty()) { toast("Capture failed"); return }
        enqueue(files, if (files.size == 1) ProcMode.SINGLE else pm, portrait)
    }

    /** Front camera has no flash: light the face with the (max brightness) screen. */
    private fun setScreenFlash(on: Boolean) {
        if (screenFlash.parent == null) {
            val content = findViewById<ViewGroup>(android.R.id.content)
            content.addView(screenFlash, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        screenFlash.bringToFront()
        // soft, neutral fill light (strength from Settings) — full white made faces yellow / shiny
        val a = (60 + 195 * prefs.frontFlash.coerceIn(20, 100) / 100).coerceIn(0, 255)
        val cool = prefs.frontFlashCool.coerceIn(0, 100) / 100f
        screenFlash.setBackgroundColor(Color.argb(a, (255 - 24 * cool).toInt(), (255 - 10 * cool).toInt(), 255))
        screenFlash.visibility = if (on) View.VISIBLE else View.GONE
        try {
            val st = camera?.cameraInfo?.exposureState
            if (st != null && st.isExposureCompensationSupported) {
                val step = st.exposureCompensationStep.toFloat()
                val idx = if (on && step > 0f) (-1f / step).roundToInt().coerceIn(st.exposureCompensationRange.lower, 0) else 0
                camera?.cameraControl?.setExposureCompensationIndex(idx)
            }
        } catch (t: Throwable) { Log.w(TAG, "flash ev", t) }
        val lp = window.attributes
        lp.screenBrightness = if (on) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }

    private suspend fun shootNight(ultra: Boolean) {
        // front: soft screen light only when the flash button is on/auto (no more always-on white flash)
        val fl = lensFacing == CameraSelector.LENS_FACING_FRONT && prefs.flash != 0
        if (fl) { setScreenFlash(true); delay(650) }
        try { shootNightCore(ultra) } finally { if (fl) setScreenFlash(false) }
    }

    private suspend fun shootNightCore(ultra: Boolean) {
        val t = tuner
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        var manual = false
        val ir = t?.isoRange
        val er = t?.expRange
        if (t != null && t.hasManual && ir != null && er != null && meta.iso > 0 && meta.expNs > 0) {
            val tripod = prefs.tripod
            val tMax = min(if (tripod) (if (ultra) 6_000_000_000L else 3_500_000_000L) else (if (ultra) 200_000_000L else 125_000_000L), er.upper)
            val isoCap = min(if (tripod) (if (ultra) 1600 else 800) else (if (ultra) 6400 else 3200), ir.upper)
            val total = meta.iso.toDouble() * meta.expNs.toDouble() * (if (tripod) (if (ultra) 3.2 else 2.2) else (if (ultra) 2.6 else 1.7))
            val iso = (total / tMax).roundToInt().coerceIn(ir.lower, max(ir.lower, isoCap))
            val exp = (total / iso).toLong().coerceIn(er.lower, tMax)
            t.setManualExposure(iso, exp)
            t.commit()
            manual = true
            setStatus(if (tripod) "Shutter open… phone stable rakho" else "Light capture ho raha hai…")
            delay(350L + exp / 1_000_000L * (if (tripod) 1L else 2L))
        } else {
            val st = camera?.cameraInfo?.exposureState
            if (st != null && st.isExposureCompensationSupported) {
                camera?.cameraControl?.setExposureCompensationIndex(st.exposureCompensationRange.upper)
            }
            delay(400)
        }
        val files = try {
            burst(if (manual) (if (prefs.tripod) (if (ultra) 4 else 3) else (if (ultra) 8 else 4)) else (if (ultra) 8 else 4), (if (ultra) "Ultra Night" else "Night") + (if (manual && prefs.tripod) " • tripod, hilo mat" else " • hold steady"))
        } finally {
            if (manual) { t?.setAutoExposure(); t?.commit() }
            camera?.cameraControl?.setExposureCompensationIndex(0)
        }
        finishBurst(files, ProcMode.NIGHT)
    }

    private suspend fun shootHdr() {
        val cam = camera ?: return
        val st = cam.cameraInfo.exposureState
        if (!st.isExposureCompensationSupported || st.exposureCompensationStep.toFloat() <= 0f) {
            shootStack(3, ProcMode.STACK)
            return
        }
        val step = st.exposureCompensationStep.toFloat()
        val r = st.exposureCompensationRange
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        val files = ArrayList<File>()
        val hdrTorch = flashWanted() && lensFacing == CameraSelector.LENS_FACING_BACK && camera?.cameraInfo?.hasFlashUnit() == true
        if (hdrTorch) { camera?.cameraControl?.enableTorch(true); delay(400) }
        try {
            for ((i, ev) in listOf(-2f, 0f, 2f).withIndex()) {
                val idx = (ev / step).roundToInt().coerceIn(r.lower, r.upper)
                cam.cameraControl.setExposureCompensationIndex(idx)
                setStatus("HDR ${i + 1}/3")
                delay(600)
                val f = frameFile(i)
                if (takePictureToFile(f)) files.add(f)
            }
        } finally {
            cam.cameraControl.setExposureCompensationIndex(0)
            if (hdrTorch) camera?.cameraControl?.enableTorch(false)
        }
        finishBurst(files, ProcMode.HDR)
    }

    private suspend fun shootPro() {
        applyFlash()
        setStatus("Capturing…")
        val f = frameFile(0)
        if (!takePictureToFile(f)) { toast("Capture failed"); return }
        if (!prefs.proProcess || effectiveCapRes() == 2) {
            withContext(Dispatchers.IO) { saveFileToGallery(f) }
            f.delete()
        } else {
            enqueue(listOf(f), ProcMode.SINGLE)
        }
    }

    private suspend fun shootPortrait() {
        val files = burst(3, "Portrait • hold steady")
        finishBurst(files, ProcMode.STACK, portrait = true)
    }

    private suspend fun shootScan() {
        applyFlash()
        setStatus("Scanning…")
        val f = frameFile(0)
        if (!takePictureToFile(f)) { toast("Capture failed"); return }
        enqueue(listOf(f), ProcMode.DOC)
    }

    private suspend fun shootAstro(trails: Boolean) {
        val t = tuner
        val ir = t?.isoRange
        val er = t?.expRange
        if (t == null || !t.hasManual || ir == null || er == null) {
            toast("Is phone par manual long-exposure available nahi — NIGHT mode (tripod) use karo")
            return
        }
        if (trails) {
            // RAW star trails: one open RAW session, 20 x 3 s back to back (no gap), each frame developed, then lighten-stacked
            val tExp = min(3_000_000_000L, er.upper)
            val tIso = min(800, ir.upper).coerceAtLeast(ir.lower)
            setStatus("Phone stable rakho…")
            delay(1200)
            val rawMap = java.util.concurrent.ConcurrentHashMap<Int, File>()
            val rawN = rawMultiShot(20, 0L, true, { true }, tIso, tExp, "Trails RAW") { idx, f -> rawMap[idx] = f }
            if (rawN >= 0) {
                if (rawN >= 1) finishBurst(rawMap.toSortedMap().values.toList(), ProcMode.TRAILS) else toast("RAW trails capture fail — dobara try karo")
                return
            }
        }
        imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
        val exp = min(if (trails) 3_000_000_000L else 4_000_000_000L, er.upper)
        val iso = min(if (trails) 800 else 1600, ir.upper).coerceAtLeast(ir.lower)
        t.setManualExposure(iso, exp)
        t.commit()
        setStatus("Phone stable rakho…")
        delay(1200)
        val files = try {
            burst(if (trails) 20 else 12, if (trails) "Trails" else "Stars")
        } finally {
            t.setAutoExposure()
            t.commit()
        }
        finishBurst(files, if (trails) ProcMode.TRAILS else ProcMode.ASTRO)
    }

    // ===================================================================== RAW multi-shot (PANO / LAPSE / TRAILS)
    /** One RAW frame -> developed JPEG file with EXIF orientation (every pano / lapse / trails frame is its own RAW develop). */
    private fun rawBurstToFile(b: RawBurst, exif: Int, f: File): Boolean {
        return try {
            val bm = developBurst(b, rawParams(false), "RAW frame")
            java.io.FileOutputStream(f).use { os -> bm.compress(Bitmap.CompressFormat.JPEG, 96, os) }
            bm.recycle()
            try {
                val ei = ExifInterface(f.absolutePath)
                ei.setAttribute(ExifInterface.TAG_ORIENTATION, exif.toString())
                ei.saveAttributes()
            } catch (t: Throwable) { Log.w(TAG, "exif", t) }
            true
        } catch (t: Throwable) {
            Log.w(TAG, "raw frame develop", t)
            false
        } finally {
            NativeRaw.destroy(b.handle)
            b.dng?.delete()
        }
    }

    /**
     * Keeps ONE Camera2 RAW session open and takes up to [shots] RAW frames. Each frame is developed to a JPEG file in the background
     * (max 2 at a time, so RAM stays bounded) and handed to [onFile]. Returns the number of frames made, or -1 when RAW is not
     * possible here (caller then falls back to the JPEG path).
     */
    private suspend fun rawMultiShot(
        shots: Int, gapMs: Long, lockExposure: Boolean, keepGoing: () -> Boolean,
        manualIso: Int = 0, manualExp: Long = 0L, label: String,
        onFile: suspend (Int, File) -> Unit
    ): Int {
        if (!prefs.rawEngine || !prefs.rawMulti || !NativeRaw.ok || prefs.capRes == 2) return -1
        val front = lensFacing == CameraSelector.LENS_FACING_FRONT
        val id = currentCameraId() ?: return -1
        val cm = cameraManager()
        if (!RawCapture.supported(cm, id)) return -1
        val sensorOri = try { cm.getCameraCharacteristics(id).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90 } catch (e: Exception) { 90 }
        val exif = RawCapture.exifFor(sensorOri, devDeg, front)
        RawCapture.wantSr = false
        val sem = Semaphore(2)
        val jobs = ArrayList<Job>()
        val made = java.util.concurrent.atomic.AtomicInteger(0)
        cameraProvider?.unbindAll()
        delay(350)
        try {
            RawCapture.capture(this, cm, id, FloatArray(1), false, gyro, cacheDir, false, exif,
                manualIso = manualIso, manualExpNs = manualExp,
                shots = shots, shotGapMs = gapMs, lockExposure = lockExposure, shouldContinue = keepGoing,
                onShot = { b, idx ->
                    sem.acquire()                                   // back-pressure: at most 2 frames being developed
                    val f = frameFile(idx)
                    jobs.add(scope.launch(Dispatchers.Default) {
                        try {
                            if (rawBurstToFile(b, exif, f)) {
                                made.incrementAndGet()
                                onFile(idx, f)
                                ui.post { setStatus("$label • RAW frame ${idx + 1} ✓") }
                            }
                        } finally { sem.release() }
                    })
                }) { s -> ui.post { setStatus("$label • $s") } }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (t: Throwable) {
            Log.w(TAG, "raw multi-shot", t)
        } finally {
            withContext(NonCancellable) {
                jobs.joinAll()
                bindCamera(false)
                try { ProcService.done(applicationContext, "$label — RAW frames ready ✓") } catch (ignored: Throwable) { }
            }
        }
        return made.get()
    }

    private fun toggleLapse() {
        val running = lapseJob
        if (running != null) {
            running.cancel()
            return
        }
        val count = prefs.lapseCount
        val interval = prefs.lapseInterval
        val st = stamp()
        shutter.recording = true
        lapseJob = scope.launch {
            var i = 0
            try {
                // RAW session first (every lapse frame = its own RAW develop); JPEG loop below is the fallback
                val rawMade = rawMultiShot(if (count == 0) Int.MAX_VALUE else count, interval * 1000L, false, { true }, label = "⏱ Timelapse") { idx, f ->
                    val name = "LAPSE_${st}_" + String.format(Locale.US, "%04d", idx) + ".jpg"
                    withContext(Dispatchers.IO) { saveFileToGallery(f, name) }
                    f.delete()
                }
                if (rawMade > 0) i = rawMade
                while (rawMade <= 0 && (count == 0 || i < count)) {
                    setStatus("⏱ Timelapse ${i + 1}" + (if (count > 0) "/$count" else ""))
                    val f = frameFile(i)
                    if (takePictureToFile(f)) {
                        val name = "LAPSE_${st}_" + String.format(Locale.US, "%04d", i) + ".jpg"
                        withContext(Dispatchers.IO) { saveFileToGallery(f, name) }
                        f.delete()
                    }
                    i++
                    delay(interval * 1000L)
                }
            } finally {
                shutter.recording = false
                setStatus(null)
                lapseJob = null
                toast("Timelapse: $i frames save hue")
            }
        }
    }

    private fun togglePano() {
        if (panoJob != null) {
            panoStop = true
            return
        }
        if (imageCapture == null) return
        panoStop = false
        shutter.recording = true
        panoJob = scope.launch {
            val files = ArrayList<File>()
            // RAW session first: exposure + white balance locked from the first frame, 12 RAW frames max, each developed on its own
            val rawMap = java.util.concurrent.ConcurrentHashMap<Int, File>()
            val rawN = try {
                rawMultiShot(12, 700L, true, { !panoStop }, label = "Pano RAW — dheere pan karo, STOP = shutter") { idx, f -> rawMap[idx] = f }
            } catch (e: kotlinx.coroutines.CancellationException) { shutter.recording = false; panoJob = null; throw e }
            if (rawN > 0) {
                files.addAll(rawMap.toSortedMap().values)
                shutter.recording = false
                setStatus(null)
                panoJob = null
            } else {
                tuner?.lockAeAwb(true)
                imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
                try {
                    while (!panoStop && files.size < 12) {
                        setStatus("Pano ${files.size + 1} — dheere pan karo\nSTOP = shutter")
                        val f = frameFile(files.size)
                        if (takePictureToFile(f)) files.add(f)
                        delay(150)
                    }
                } finally {
                    tuner?.lockAeAwb(false)
                    shutter.recording = false
                    setStatus(null)
                    panoJob = null
                }
            }
            if (files.size >= 2) {
                enqueue(files, ProcMode.SINGLE, pano = true)
            } else {
                for (f in files) f.delete()
                toast("Pano ke liye kam se kam 2 frames chahiye")
            }
        }
    }

    // ===================================================================== analysis / suggestions
    private fun currentStats() = SceneStats(
        iso = meta.iso, expNs = meta.expNs, meanLuma = analyzer.meanLuma, centerLuma = centerLuma,
        highPct = analyzer.highPct, shadowPct = analyzer.shadowPct, motion = aiMotion,
        front = lensFacing == CameraSelector.LENS_FACING_FRONT
    )

    private fun analyzeFrame() {
        if (mode == Mode.VIDEO && recording != null) return
        val full = previewView.bitmap ?: return
        val fw = full.width
        val fh = full.height
        if (fw <= 0 || fh <= 0) return
        val sw = 96
        val sh = max(8, (sw * fh / fw.toFloat()).roundToInt())
        val small = Bitmap.createScaledBitmap(full, sw, sh, true)
        if (small !== full) full.recycle()
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        small.recycle()
        run {
            var cs = 0L
            var cn = 0
            for (y in sh / 5 until sh * 7 / 10) {
                for (x in sw / 4 until sw * 3 / 4) {
                    val p = px[y * sw + x]
                    cs += (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8
                    cn++
                }
            }
            if (cn > 0) centerLuma = cs.toFloat() / cn
        }
        analyzer.aspect = fw.toFloat() / fh
        analyzer.update(px, sw, sh)

        // --- AI director: motion between preview ticks + live plan (shutter policy follows the scene) ---
        run {
            val lum = FloatArray(px.size)
            for (i in px.indices) {
                val p = px[i]
                lum[i] = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
            }
            val mo = AiDirector.motionScore(aiPrevLuma, lum)
            aiPrevLuma = lum
            aiMotion = aiMotion * 0.5f + mo * 0.5f
            if (prefs.aiDirector) {
                aiPlan = AiDirector.plan(currentStats(), prefs.bokeh / 100f)
                if (mode == Mode.AUTO && !shooting && aiPlan.shutter != aiShutter) {
                    aiShutter = aiPlan.shutter
                    tuner?.setShutterBias(aiShutter)
                }
            }
        }

        val iso = meta.iso
        val e = meta.expNs
        val low = iso >= 1600 || e > 45_000_000L
        val dark = analyzer.meanLuma < 55f && iso > 800
        val hdrNeed = analyzer.highPct > 6f && analyzer.shadowPct > 18f
        val veryDark = analyzer.meanLuma < 30f && iso >= 1600
        var sug: Mode? = null
        if (mode == Mode.AUTO || mode == Mode.ULTRA || mode == Mode.NIGHT) {
            if (veryDark) sug = Mode.UNIGHT
            else if (mode != Mode.NIGHT && (low || dark)) sug = Mode.NIGHT
            else if (mode != Mode.NIGHT && hdrNeed) sug = Mode.HDR
        }
        if (sug != null && sug == suggestMode) suggestTicks++ else { suggestMode = sug; suggestTicks = 0 }
        if (sug == null) {
            suggestionTv.visibility = View.GONE
        } else {
            suggestionTv.text = if (sug == Mode.UNIGHT) "🌌 Bahut andhera — ULTRA NIGHT try karo (tap)" else if (sug == Mode.NIGHT) "🌙 Low light — NIGHT mode try karo (tap)" else "☀ High contrast — HDR try karo (tap)"
            suggestionTv.visibility = View.VISIBLE
        }
        if (prefs.autoScene && (sug == Mode.NIGHT || sug == Mode.UNIGHT) && (mode == Mode.AUTO || (sug == Mode.UNIGHT && mode == Mode.NIGHT)) && suggestTicks >= 3 && !shooting) {
            suggestTicks = -20
            setMode(sug)
            toast(if (sug == Mode.UNIGHT) "Auto scene: bahut andhera → ULTRA NIGHT" else "Auto scene: low light → NIGHT")
        }
    }

    // ===================================================================== lens / info
    private fun cameraManager(): CameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private fun backLensIds(): List<String> = try {
        val cm = cameraManager()
        cm.cameraIdList.filter {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun lensLabel(id: String): String = try {
        val c = cameraManager().getCameraCharacteristics(id)
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
        val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        if (f != null && sz != null) {
            val eq = f * 43.27f / sqrt(sz.width * sz.width + sz.height * sz.height)
            "Camera $id • ${eq.roundToInt()}mm eq"
        } else "Camera $id"
    } catch (e: Exception) {
        "Camera $id"
    }

    private fun cycleLens() {
        if (lensFacing != CameraSelector.LENS_FACING_BACK) { toast("Front camera me lens switch nahi"); return }
        val lenses = try { Lenses.discover(cameraManager()) } catch (e: Throwable) { emptyList() }
        if (lenses.isEmpty()) { toast("Koi back camera nahi mila (ℹ me dekho)"); return }
        val usable = lenses.filter { it.usable }
        val names = ArrayList<String>()
        for (l in lenses) names.add((if (l.id == lensId || (lensId == null && l == usable.firstOrNull())) "●  " else "○  ") + l.label)
        names.add("📸  Shoot ALL lenses (har ON lens se 1 photo)")
        AlertDialog.Builder(this)
            .setTitle("Back cameras (${lenses.size} mile, ${usable.size} ON ho sakte hain)")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == lenses.size) { shootAllLenses(usable); return@setItems }
                val l = lenses[which]
                if (!l.usable) {
                    toast(if (!l.isImage) "Depth sensor photo nahi leta" else "Ye lens phone app ko nahi deta (MIUI). ℹ Camera Info me dikhega")
                    return@setItems
                }
                lensId = if (l == usable.firstOrNull()) null else l.id
                toast(l.label.substringBefore("\n"))
                bindCamera(false)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /** Switch through every lens CameraX can open and take one photo with each. */
    private fun shootAllLenses(usable: List<LensInfo>) {
        if (shooting || usable.isEmpty()) return
        val prevLens = lensId
        scope.launch {
            shooting = true
            try {
                for ((i, l) in usable.withIndex()) {
                    setStatus("Lens ${i + 1}/${usable.size} • ${l.role}")
                    lensId = if (i == 0) null else l.id
                    bindCamera(false)
                    delay(1200)
                    val f = frameFile(i)
                    if (takePictureToFile(f)) {
                        withContext(Dispatchers.IO) { saveFileToGallery(f, "ULTRACAM_${stamp()}_${l.role.replace('/', '_')}_cam${l.id}.jpg") }
                    }
                    f.delete()
                }
                toast("${usable.size} lens se photos save ho gayi")
            } catch (e: Throwable) {
                Log.w(TAG, "all lenses", e)
                toast("All-lens capture beech me ruk gaya")
            } finally {
                lensId = prevLens
                bindCamera(false)
                shooting = false
                setStatus(null)
            }
        }
    }

    private fun showCameraInfo() {
        val sb = StringBuilder()
        try {
            val cm = cameraManager()
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_BACK -> "BACK"
                    CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
                    else -> "EXTERNAL"
                }
                val lvl = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    0 -> "LIMITED"
                    1 -> "FULL"
                    2 -> "LEGACY"
                    3 -> "LEVEL_3"
                    else -> "?"
                }
                val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
                sb.append("━ ${lensLabel(id)}  [$facing] $lvl\n")
                val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                val jpeg = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }
                val vid = map?.getOutputSizes(MediaRecorder::class.java)?.maxByOrNull { it.width.toLong() * it.height }
                if (jpeg != null) sb.append("  Max JPEG: ${jpeg.width}x${jpeg.height} (${jpeg.width.toLong() * jpeg.height / 1_000_000}MP)\n")
                if (vid != null) sb.append("  Max video: ${vid.width}x${vid.height}\n")
                sb.append("  Manual exposure: ${if (1 in caps) "YES" else "NO"}   RAW: ${if (3 in caps) "YES" else "NO"}   Burst: ${if (6 in caps) "YES" else "NO"}\n")
                val rawSz = map?.getOutputSizes(ImageFormat.RAW_SENSOR)
                sb.append("  RAW sizes: " + (if (rawSz.isNullOrEmpty()) "none" else rawSz.sortedByDescending { it.width.toLong() * it.height }.take(3).joinToString { "${it.width}x${it.height}" }) + "\n")
                sb.append("  UltraCam RAW engine: ${if (RawCapture.supported(cm, id)) "USABLE ✓" else "not available on this camera id"}\n")
                val ois = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                val eis = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
                sb.append("  OIS: ${if (ois?.contains(1) == true) "YES" else "NO"}   EIS: ${if (eis?.contains(1) == true) "YES" else "NO"}\n")
                val fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                if (fps != null) sb.append("  FPS ranges: " + fps.joinToString(" ") { "${it.lower}-${it.upper}" } + "\n")
                val hs = map?.highSpeedVideoSizes
                if (hs != null && hs.isNotEmpty()) sb.append("  High-speed video sizes: ${hs.size}\n")
                if (Build.VERSION.SDK_INT >= 28) {
                    val ph = c.physicalCameraIds
                    if (ph.isNotEmpty()) sb.append("  Physical cameras: ${ph.joinToString()}\n")
                }
                sb.append("\n")
            }
        } catch (e: Exception) {
            sb.append("Error: ${e.message}")
        }
        val tv = txt(sb.toString(), 12f)
        tv.typeface = android.graphics.Typeface.MONOSPACE
        tv.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this).setTitle("Camera Info").setView(sv).setPositiveButton("OK", null).show()
    }

    private fun tryInvoke(target: Any, name: String, argType: Class<*>, arg: Any): Boolean = try {
        target.javaClass.getMethod(name, argType).invoke(target, arg)
        true
    } catch (e: Throwable) {
        false
    }

    private fun setHdr(vb: Any) {
        try {
            val cls = Class.forName("androidx.camera.core.DynamicRange")
            val hlg = cls.getField("HLG_10_BIT").get(null)
            vb.javaClass.getMethod("setDynamicRange", cls).invoke(vb, hlg)
        } catch (e: Throwable) {
            toast("HDR10 video is CameraX/phone par supported nahi")
        }
    }

    // ===================================================================== processing queue
    private fun buildParams(pm: ProcMode): ProcParams {
        val scale = when (prefs.outScale) { 0 -> 1f; 1 -> 1.5f; else -> 2f }
        val ai = if (prefs.aiDirector && (pm == ProcMode.STACK || pm == ProcMode.SINGLE || pm == ProcMode.HDR || pm == ProcMode.NIGHT)) aiPlan else AiPlan.NEUTRAL
        val real = prefs.realColor
        var dn = (prefs.denoise / 100f * ai.denoiseMul).coerceIn(0f, 1f)
        var sh = (prefs.sharp / 100f * ai.sharpMul).coerceIn(0f, 1f)
        var det = prefs.detail / 100f
        // Auto Details: balance detail vs noise from the light the sensor is getting right now
        if (prefs.autoDetail && (pm == ProcMode.STACK || pm == ProcMode.SINGLE || pm == ProcMode.HDR || pm == ProcMode.NIGHT)) {
            val t = AutoDetail.tune(meta.iso, meta.expNs, lensFacing == CameraSelector.LENS_FACING_FRONT, prefs.detailLevel, if (pm == ProcMode.NIGHT) (if (mode == Mode.UNIGHT) 10 else 7) else 1)
            dn = t.denoise
            sh = t.sharp
            det = t.detail
        }
        return ProcParams(
            mode = pm,
            scale = scale,
            denoise = dn,
            sharpness = sh,
            detail = det,
            shadowLift = if (real) min(prefs.lift / 100f, 0.2f) else prefs.lift / 100f,
            enhance = if (real) 0f else (prefs.enhance / 100f + ai.enhanceAdd).coerceIn(0f, 1f),
            look = Looks.byId(prefs.lookId),
            lookIntensity = if (real) 0f else prefs.lookIntensity / 100f,
            ultraNight = pm == ProcMode.NIGHT && mode == Mode.UNIGHT
        )
    }

    private fun orientationOf(f: File): Int = try {
        ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }

    // ---- Focus blur (adjustable background blur, all photo modes)
    private class FocusBlurCfg(val amt: Float, val mode: Int, val u: Float, val v: Float)

    private fun focusBlurCfg(rot: Int): FocusBlurCfg? {
        if (!prefs.focusBlur || prefs.focusBlurAmt < 4) return null
        val p = focusPointFor(rot)
        return FocusBlurCfg(prefs.focusBlurAmt / 100f, prefs.focusBlurMode, p.first, p.second)
    }

    private suspend fun applyFocusBlur(bmp: Bitmap, rot: Int, c: FocusBlurCfg) {
        // mode 0: person (AI) when one is found, otherwise the tapped focus point; mode 1: tapped focus point only
        if (c.mode == 0 && Portrait.applyIfPerson(bmp, rot, c.amt, 0.03f, 0.92f)) return
        Portrait.applyFocusPoint(bmp, rot, c.amt, c.u, c.v)
    }

    /** Main frames + ultra-wide frames -> one wide bitmap (main detail in the middle). Falls back to the main image alone. */
    private fun wideProcess(
        mainFiles: List<File>, uwFiles: List<File>, params: ProcParams, orient: Int, st: String, cb: (String) -> Unit
    ): Bitmap {
        cb("Main lens process…")
        val mainBmp = Engine.process(mainFiles.map { it.absolutePath }, params, cb)
        val first: Bitmap? = try {
            cb("Ultra-wide process…")
            Engine.process(uwFiles.map { it.absolutePath }, params.copy(scale = 1f), cb)
        } catch (t: Throwable) {
            Log.w(TAG, "uw process", t)
            null
        }
        if (first == null) return mainBmp
        var uwBmp: Bitmap = first
        // bring the ultra-wide into the same pixel orientation as the main frame (EXIF based)
        val delta = ((degreesFor(orientationOf(uwFiles[0])) - degreesFor(orient)) % 360 + 360) % 360
        if (delta != 0) {
            try {
                val m = Matrix()
                m.postRotate(delta.toFloat())
                val r = Bitmap.createBitmap(uwBmp, 0, 0, uwBmp.width, uwBmp.height, m, true)
                if (r !== uwBmp) {
                    uwBmp.recycle()
                    uwBmp = r
                }
            } catch (t: Throwable) {
                Log.w(TAG, "uw rotate", t)
            }
        }
        val fused: Bitmap? = try {
            WideFusion.fuse(mainBmp, uwBmp, cb)
        } catch (t: Throwable) {
            Log.w(TAG, "wide fuse", t)
            null
        }
        if (fused == null) {
            // could not match the two lenses: keep both pictures separately instead of losing the ultra-wide shot
            try { saveBitmap(uwBmp, orient, st + "_UW") } catch (t: Throwable) { Log.w(TAG, "uw save", t) }
            uwBmp.recycle()
            ui.post { toast("Dono lens match nahi hue — main aur ultra-wide alag alag save ki") }
            return mainBmp
        }
        mainBmp.recycle()
        uwBmp.recycle()
        return fused
    }

    private fun enqueue(files: List<File>, pm: ProcMode, portrait: Boolean = false, pano: Boolean = false, wideFiles: List<File>? = null) {
        val orient = orientationOf(files[0])
        val rot = degreesFor(orient)
        val params = buildParams(pm)
        val beautyCfg = if (!pano && (pm == ProcMode.STACK || pm == ProcMode.SINGLE || pm == ProcMode.HDR || pm == ProcMode.NIGHT))
            Beauty.cfgFrom(prefs, lensFacing == CameraSelector.LENS_FACING_FRONT) else null
        val fb = if (!pano && !portrait && (pm == ProcMode.STACK || pm == ProcMode.SINGLE || pm == ProcMode.HDR || pm == ProcMode.NIGHT)) focusBlurCfg(rot) else null
        val aiBokeh = if (fb == null && prefs.aiDirector && prefs.autoBlur && !portrait && !pano && (pm == ProcMode.STACK || pm == ProcMode.SINGLE)) aiPlan.bokeh else 0f
        val st = stamp()
        val colorFixOn = !pano && prefs.colorFix && lensFacing == CameraSelector.LENS_FACING_FRONT
        val colorFixAmt = prefs.colorFixAmt / 100f
        val cleanOn = !pano && (pm == ProcMode.STACK || pm == ProcMode.SINGLE || pm == ProcMode.HDR || pm == ProcMode.NIGHT) &&
            (prefs.cleanChroma > 0 || prefs.cleanLuma > 0)
        val cleanC = prefs.cleanChroma / 100f
        val cleanL = prefs.cleanLuma / 100f
        pendingJobs++
        refreshBusy()
        if (pendingJobs == 1) {
            try { ContextCompat.startForegroundService(this, Intent(this, ProcService::class.java)) } catch (e: Throwable) { Log.w(TAG, "svc", e) }
        }
        scope.launch(Dispatchers.Default) {
            procMutex.withLock {
                try {
                    val paths = files.map { it.absolutePath }
                    val cb: (String) -> Unit = { s ->
                        val pct = if (s.startsWith("Processing ")) (s.removePrefix("Processing ").removeSuffix("%").trim().toIntOrNull() ?: -1) else -1
                        val label = if (pct >= 0) "Processing $pct%" else s
                        ProcService.update(applicationContext, if (pendingJobs > 1) "$label  (+${pendingJobs - 1} in queue)" else label, pct)
                    }
                    val bmp = if (pano) Pano.stitch(paths, cb)
                    else if (wideFiles != null) wideProcess(files, wideFiles, params, orient, st, cb)
                    else Engine.process(paths, params, cb)
                    if (cleanOn) {
                        cb("Noise clean…")
                        try { Clean.apply(bmp, cleanC, cleanL) } catch (t: Throwable) { Log.w(TAG, "clean", t) }
                        if (cleanL > 0.02f) try { Denoise.apply(bmp, (0.5f + cleanL).coerceIn(0.5f, 1f)) } catch (t: Throwable) { Log.w(TAG, "nlm", t) }
                    }
                    if (colorFixOn) {
                        cb("Colour fix…")
                        try { ColorFix.apply(bmp, colorFixAmt) } catch (t: Throwable) { Log.w(TAG, "colorfix", t) }
                    }
                    if (beautyCfg != null) {
                        cb("Beauty…")
                        try { Beauty.apply(bmp, rot, beautyCfg) } catch (t: Throwable) { Log.w(TAG, "beauty", t) }
                    }
                    if (fb != null) {
                        cb("Focus blur…")
                        try { applyFocusBlur(bmp, rot, fb) } catch (t: Throwable) { Log.w(TAG, "focus blur", t) }
                    }
                    if (portrait) {
                        cb("Portrait blur…")
                        try { Portrait.apply(bmp, rot, prefs.bokeh / 100f) } catch (t: Throwable) { Log.w(TAG, "portrait", t) }
                    }
                    if (aiBokeh > 0.05f) {
                        try {
                            if (Portrait.applyIfPerson(bmp, rot, aiBokeh)) Log.i(TAG, "AI aperture: person found, background blurred")
                        } catch (t: Throwable) { Log.w(TAG, "ai bokeh", t) }
                    }
                    if (prefs.watermark) {
                        try {
                            val d = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
                            Watermark.draw(bmp, rot, "Shot on UltraCam  •  $d")
                        } catch (t: Throwable) { Log.w(TAG, "watermark", t) }
                    }
                    val uri = saveBitmap(bmp, orient, st, crop = !pano)
                    if (prefs.keepOriginal) saveFileToGallery(files[0], "ULTRACAM_${st}_ORIG.jpg")
                    makeThumb(bmp, orient, uri)
                    bmp.recycle()
                } catch (t: Throwable) {
                    Log.e(TAG, "process", t)
                    try { saveFileToGallery(files[0]) } catch (ignored: Throwable) { }
                    ui.post { toast("Processing fail (memory?) — basic photo save kar di") }
                } finally {
                    for (f in files) f.delete()
                    if (wideFiles != null) for (f in wideFiles) f.delete()
                }
            }
            withContext(Dispatchers.Main) {
                pendingJobs--
                refreshBusy()
                if (pendingJobs == 0) {
                    setStatus(null)
                    try { stopService(Intent(this@MainActivity, ProcService::class.java)) } catch (e: Throwable) { }
                    ProcService.done(applicationContext, "Photo ready ✓ — Gallery me save ho gayi")
                }
            }
        }
    }


    // ===================================================================== RAW path (Camera2 RAW_SENSOR burst -> native merge + develop)
    private fun currentCameraId(): String? = try {
        camera?.let { Camera2CameraInfo.from(it.cameraInfo).cameraId }
    } catch (e: Exception) { null }

    private suspend fun shootRaw(): Boolean {
        if (!prefs.rawEngine || !NativeRaw.ok || prefs.capRes == 2) return false     // MAX-res (64MP) is a direct JPEG by choice
        val front = lensFacing == CameraSelector.LENS_FACING_FRONT
        val id = currentCameraId() ?: return false
        val cm = cameraManager()
        if (!RawCapture.supported(cm, id)) {
            if (!rawWarned) { rawWarned = true; toast(if (front) "Front camera RAW nahi deta (phone ki limit) — JPEG multi-frame path chalega" else "Is lens par RAW nahi mila — JPEG path (halo-free) chalega") }
            return false
        }
        val t = tuner
        // ASTRO needs manual long exposure; without it the JPEG path shows the proper message
        if (mode == Mode.ASTRO && (t == null || !t.hasManual || t.isoRange == null || t.expRange == null)) return false
        try { analyzeFrame() } catch (e: Exception) { Log.w(TAG, "raw analyze", e) }
        if (prefs.aiDirector) aiPlan = AiDirector.plan(currentStats(), prefs.bokeh / 100f)

        // ---- flash: back = LED torch for the whole burst (steady light => frames merge), front = screen light
        val flashOn = flashWanted()
        val torch = flashOn && !front && camera?.cameraInfo?.hasFlashUnit() == true
        val screenFl = flashOn && front

        val zoom = if (mode == Mode.WIDE) 1f else (camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f)
        val hdrScene = mode == Mode.HDR || (mode == Mode.AUTO && analyzer.highPct > 4f && analyzer.shadowPct > 8f)
        var n = when (mode) {
            Mode.UNIGHT -> 8                     // ultra night: 8 frames
            Mode.NIGHT -> 4                      // everything else: max 4 frames (16 MP each) — faster, still clean
            Mode.ULTRA -> 4
            Mode.HDR -> 4
            Mode.PORTRAIT -> 4
            Mode.ASTRO -> 6
            Mode.PRO -> 4
            else -> if (prefs.aiDirector) aiPlan.frames.coerceIn(3, 4) else 4
        }
        // ---- PRO / ASTRO: fixed exposure / focus / white balance
        var manualIso = 0
        var manualExp = 0L
        var manualFocus = -1f
        var awb = -1
        if (mode == Mode.PRO && t != null) {
            if (proManualAE && t.hasManual) {
                manualIso = isoFromP(proIso)
                manualExp = expFromP(proShut)
                n = when {
                    manualExp >= 500_000_000L -> 1
                    manualExp >= 125_000_000L -> 2
                    manualExp >= 30_000_000L -> 4
                    else -> 6
                }
            }
            if (proManualAF && t.minFocus > 0f) manualFocus = proFocus / 100f * t.minFocus
            awb = proAwb ?: -1
        }
        if (mode == Mode.ASTRO && t != null) {
            val ir = t.isoRange!!
            val er = t.expRange!!
            manualExp = min(4_000_000_000L, er.upper)
            manualIso = min(1600, ir.upper).coerceAtLeast(ir.lower)
        }
        val evs = FloatArray(n) { k -> if (!hdrScene || k == 0) 0f else if (k % 2 == 1) -2f else 0f }
        val sensorOri = try { cm.getCameraCharacteristics(id).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90 } catch (e: Exception) { 90 }
        val exif = RawCapture.exifFor(sensorOri, devDeg, front)
        val longExp = mode == Mode.NIGHT || mode == Mode.UNIGHT
        // memory: super-res plane is skipped where it cannot help (moving stars) or where two bursts are alive at once (wide)
        RawCapture.wantSr = prefs.subPixelSr && mode != Mode.ASTRO && mode != Mode.WIDE

        var burst: RawBurst? = null
        var uwBurst: RawBurst? = null
        var uwExif = 0
        if (screenFl) { setScreenFlash(true); delay(650) }
        try {
            for (attempt in 0 until 2) {
                cameraProvider?.unbindAll()
                delay(if (attempt == 0) 350L else 800L)
                try {
                    burst = RawCapture.capture(this, cm, id, evs, longExp, gyro, cacheDir, prefs.saveDng, exif,
                        torch = torch, zoom = zoom, manualIso = manualIso, manualExpNs = manualExp,
                        manualFocus = manualFocus, awbMode = awb) { s -> ui.post { setStatus(s) } }
                } catch (e: Throwable) {
                    Log.e(TAG, "raw capture", e)
                }
                if (burst != null) break
            }
            // ---- ULTRA-WIDE: second RAW burst from the ultra-wide sensor (opened directly through Camera2)
            if (burst != null && mode == Mode.WIDE) {
                val uw = try { Lenses.discover(cm).firstOrNull { it.role == "Ultra-wide" && it.isImage && it.id != id } } catch (e: Throwable) { null }
                if (uw == null) {
                    toast("Is phone me ultra-wide sensor nahi mila — sirf main lens ka RAW merge")
                } else if (!RawCapture.supported(cm, uw.id)) {
                    toast("Ultra-wide lens RAW nahi deta — sirf main lens ka RAW merge")
                } else {
                    val uwOri = try { cm.getCameraCharacteristics(uw.id).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90 } catch (e: Exception) { 90 }
                    uwExif = RawCapture.exifFor(uwOri, devDeg, false)
                    setStatus("Wide 2/2 • ultra-wide RAW")
                    delay(300)
                    val nUw = 4
                    try {
                        uwBurst = RawCapture.capture(this, cm, uw.id, FloatArray(nUw), false, gyro, cacheDir, false, uwExif,
                            torch = torch) { s -> ui.post { setStatus(s) } }
                    } catch (e: Throwable) {
                        Log.w(TAG, "uw raw", e)
                    }
                    if (uwBurst == null) toast("Ultra-wide RAW open nahi hua — sirf main lens ka RAW merge")
                }
            }
        } finally {
            if (screenFl) setScreenFlash(false)
        }
        bindCamera(false)
        val mainBurst = burst
        if (mainBurst == null) {
            uwBurst?.let { NativeRaw.destroy(it.handle) }
            toast("RAW capture fail — JPEG se le raha hu")
            delay(600)
            return false
        }
        Log.i(TAG, "RAW burst ${mainBurst.frames}/$n frames • ${mainBurst.note}")
        setStatus("RAW merge • ${mainBurst.frames} frames")
        enqueueRaw(mainBurst, exif, hdrScene, uw = uwBurst, uwExif = uwExif,
            portrait = mode == Mode.PORTRAIT, scan = mode == Mode.SCAN, flashOn = flashOn)
        return true
    }

    private fun rawParams(hdrScene: Boolean, flashOn: Boolean = false, scan: Boolean = false): FloatArray {
        val ai = if (prefs.aiDirector) aiPlan else AiPlan.NEUTRAL
        val real = prefs.realColor                       // Ultra Natural: true-to-life colour, nothing boosted
        val pop = if (real) 0f else prefs.colorPop / 100f
        val enh = if (real) 0f else prefs.enhance / 100f
        // Auto Details: denoise / sharpness / detail from the light the sensor is getting (else the manual sliders + AI multipliers)
        var dn = (prefs.denoise / 100f * ai.denoiseMul).coerceIn(0f, 1f)
        var sh = (prefs.sharp / 100f * ai.sharpMul).coerceIn(0f, 1f)
        var det = prefs.detail / 100f
        if (prefs.autoDetail) {
            val night = mode == Mode.NIGHT || mode == Mode.UNIGHT
            val t = AutoDetail.tune(meta.iso, meta.expNs, lensFacing == CameraSelector.LENS_FACING_FRONT, prefs.detailLevel, if (mode == Mode.UNIGHT) 12 else if (night) 8 else 1)
            dn = t.denoise
            sh = t.sharp
            det = t.detail
        }
        val a = FloatArray(NativeRaw.P_COUNT)
        a[NativeRaw.P_EV] = 0f
        val lift = if (real) min(prefs.lift / 100f, 0.2f) else prefs.lift / 100f
        a[NativeRaw.P_SHADOWS] = (lift * 1.4f + (if (hdrScene) 0.15f else 0f)).coerceIn(0f, 1f)
        a[NativeRaw.P_HIGHLIGHTS] = if (hdrScene) 0.75f else 0.5f
        a[NativeRaw.P_CONTRAST] = if (real) 0.12f else (0.25f + 0.25f * enh).coerceIn(0f, 1f)
        a[NativeRaw.P_VIBRANCE] = if (real) 0f else (0.15f + 0.65f * pop).coerceIn(0f, 1f)
        a[NativeRaw.P_SATURATION] = if (real) 1f else 1f + 0.12f * pop
        a[NativeRaw.P_HUEBOOST] = pop
        a[NativeRaw.P_AWB] = if (mode == Mode.UNIGHT) 0.85f else if (mode == Mode.NIGHT) 0.7f else if (real) 0.3f else 0.5f
        a[NativeRaw.P_NR_LUMA] = dn
        a[NativeRaw.P_NR_CHROMA] = (0.35f + 0.5f * dn).coerceIn(0f, 1f)
        a[NativeRaw.P_SHARPEN] = sh
        a[NativeRaw.P_DECONV] = (0.25f + 0.45f * sh).coerceIn(0f, 1f)
        a[NativeRaw.P_CLARITY] = (det * 0.7f).coerceIn(0f, 1f)
        a[NativeRaw.P_DEHAZE] = (enh * 0.9f).coerceIn(0f, 1f)
        a[NativeRaw.P_WARMTH] = 0f
        if (flashOn) {
            // LED / screen light is warm and clips skin: stronger white-balance correction, slightly cooler, highlights protected
            a[NativeRaw.P_AWB] = max(a[NativeRaw.P_AWB], 0.6f)
            a[NativeRaw.P_WARMTH] = -0.45f
            a[NativeRaw.P_HIGHLIGHTS] = max(a[NativeRaw.P_HIGHLIGHTS], 0.75f)
        }
        if (scan) {
            // document: neutral colour, no pop, clean paper white (the DOC filter finishes it)
            a[NativeRaw.P_VIBRANCE] = 0f; a[NativeRaw.P_SATURATION] = 1f; a[NativeRaw.P_HUEBOOST] = 0f; a[NativeRaw.P_DEHAZE] = 0f
            a[NativeRaw.P_AWB] = max(a[NativeRaw.P_AWB], 0.6f)
        }
        if (mode == Mode.ASTRO) {
            a[NativeRaw.P_SHADOWS] = (a[NativeRaw.P_SHADOWS] + 0.2f).coerceIn(0f, 1f)
            a[NativeRaw.P_NR_LUMA] = (a[NativeRaw.P_NR_LUMA] * 1.2f + 0.1f).coerceIn(0f, 1f)
            a[NativeRaw.P_AWB] = 0.6f
        }
        if (mode == Mode.UNIGHT) {
            a[NativeRaw.P_SHADOWS] = (a[NativeRaw.P_SHADOWS] + 0.35f).coerceIn(0f, 1f)
            a[NativeRaw.P_NR_LUMA] = (a[NativeRaw.P_NR_LUMA] * 1.3f + 0.1f).coerceIn(0f, 1f)
            a[NativeRaw.P_NR_CHROMA] = (a[NativeRaw.P_NR_CHROMA] + 0.2f).coerceIn(0f, 1f)
            a[NativeRaw.P_VIBRANCE] = a[NativeRaw.P_VIBRANCE] * 0.7f
        }
        a[NativeRaw.P_SR] = if (prefs.subPixelSr) 1f else 0f
        return a
    }

    /** Develops a merged RAW burst into a bitmap (multi-threaded strips) and scales it back up when it was a zoom window. */
    private fun developBurst(b: RawBurst, prm: FloatArray, label: String): Bitmap {
        if (NativeRaw.prepare(b.handle, prm) != 0) throw IllegalStateException("raw prepare failed")
        var bm = Bitmap.createBitmap(b.outW, b.outH, Bitmap.Config.ARGB_8888)
        val rows = 96
        val starts = (0 until b.outH step rows).toList()
        val threads = min(4, max(2, Runtime.getRuntime().availableProcessors() / 2))
        val pool = Executors.newFixedThreadPool(threads)
        val doneCnt = java.util.concurrent.atomic.AtomicInteger(0)
        try {
            val tasks = starts.map { y0 ->
                java.util.concurrent.Callable<Boolean> {
                    val y1 = min(b.outH, y0 + rows)
                    val buf = IntArray((y1 - y0) * b.outW)
                    NativeRaw.strip(b.handle, y0, y1, buf)
                    val cur = bm
                    synchronized(cur) { cur.setPixels(buf, 0, b.outW, 0, y0, b.outW, y1 - y0) }
                    val pct = doneCnt.incrementAndGet() * 100 / starts.size
                    ProcService.update(applicationContext, "$label $pct%", pct)
                    true
                }
            }
            for (f in pool.invokeAll(tasks)) f.get()
        } finally { pool.shutdown() }
        if (b.baseW > b.outW + 8 || b.baseH > b.outH + 8) {
            try {
                ProcService.update(applicationContext, "Zoom detail…", -1)
                val up = try { Upscale.resize(bm, b.baseW, b.baseH) } catch (t: Throwable) {
                    Log.w(TAG, "lanczos failed, bilinear fallback", t)
                    Bitmap.createScaledBitmap(bm, b.baseW, b.baseH, true)
                }
                if (up !== bm) { bm.recycle(); bm = up }
            } catch (t: Throwable) { Log.w(TAG, "zoom upscale", t) }
        }
        return bm
    }

    private fun enqueueRaw(
        b: RawBurst, orient: Int, hdrScene: Boolean,
        uw: RawBurst? = null, uwExif: Int = 0, portrait: Boolean = false, scan: Boolean = false, flashOn: Boolean = false
    ) {
        val rot = degreesFor(orient)
        val prm = rawParams(hdrScene, flashOn, scan)
        val front = lensFacing == CameraSelector.LENS_FACING_FRONT
        val fb = if (scan || portrait) null else focusBlurCfg(rot)
        val aiBokeh = if (!scan && !portrait && fb == null && prefs.aiDirector && prefs.autoBlur) aiPlan.bokeh else 0f
        val beautyCfg = if (scan) null else Beauty.cfgFrom(prefs, front)
        val colorFixOn = !scan && prefs.colorFix && front
        val colorFixAmt = prefs.colorFixAmt / 100f
        val cleanOnRaw = !scan && (prefs.cleanChroma > 0 || prefs.cleanLuma > 0)
        val cleanC = prefs.cleanChroma / 100f
        val cleanL = prefs.cleanLuma / 100f
        val bokehAmt = prefs.bokeh / 100f
        val docParams = if (scan) buildParams(ProcMode.DOC) else null
        val currentMode = mode
        val st = stamp()
        pendingJobs++
        refreshBusy()
        if (pendingJobs == 1) {
            try { ContextCompat.startForegroundService(this, Intent(this, ProcService::class.java)) } catch (e: Throwable) { Log.w(TAG, "svc", e) }
        }
        scope.launch(Dispatchers.Default) {
            procMutex.withLock {
                try {
                    ProcService.update(applicationContext, "RAW develop…", -1)
                    var bm = developBurst(b, prm, "Processing")
                    // ---- ULTRA-WIDE: develop the second RAW burst, match it to the main frame and fuse
                    if (uw != null) {
                        val cbw: (String) -> Unit = { s -> ProcService.update(applicationContext, s, -1) }
                        var uwBmp: Bitmap? = try { developBurst(uw, prm, "Ultra-wide") } catch (t: Throwable) { Log.w(TAG, "uw develop", t); null }
                        if (uwBmp != null) {
                            val delta = ((degreesFor(uwExif) - degreesFor(orient)) % 360 + 360) % 360
                            if (delta != 0) {
                                try {
                                    val m = Matrix()
                                    m.postRotate(delta.toFloat())
                                    val r = Bitmap.createBitmap(uwBmp, 0, 0, uwBmp.width, uwBmp.height, m, true)
                                    if (r !== uwBmp) { uwBmp.recycle(); uwBmp = r }
                                } catch (t: Throwable) { Log.w(TAG, "uw rotate", t) }
                            }
                            val fused: Bitmap? = try { WideFusion.fuse(bm, uwBmp!!, cbw) } catch (t: Throwable) { Log.w(TAG, "wide fuse", t); null }
                            if (fused == null) {
                                try { saveBitmap(uwBmp!!, orient, st + "_UW") } catch (t: Throwable) { Log.w(TAG, "uw save", t) }
                                uwBmp!!.recycle()
                                ui.post { toast("Dono lens match nahi hue — main aur ultra-wide alag alag save ki") }
                            } else {
                                bm.recycle()
                                uwBmp!!.recycle()
                                bm = fused
                            }
                        }
                    }
                    // ---- SCAN: RAW develop -> lossless-ish temp JPEG -> the document filter (flatten + contrast)
                    if (scan && docParams != null) {
                        ProcService.update(applicationContext, "Document…", -1)
                        val tmp = File(cacheDir, "scan_${System.nanoTime()}.jpg")
                        try {
                            java.io.FileOutputStream(tmp).use { os -> bm.compress(Bitmap.CompressFormat.JPEG, 100, os) }
                            val doc = Engine.process(listOf(tmp.absolutePath), docParams) { s -> ProcService.update(applicationContext, s, -1) }
                            bm.recycle()
                            bm = doc
                        } catch (t: Throwable) { Log.w(TAG, "scan filter", t) } finally { tmp.delete() }
                    }
                    if (cleanOnRaw) {
                        ProcService.update(applicationContext, "Noise clean…", -1)
                        try { Clean.apply(bm, cleanC, cleanL) } catch (t: Throwable) { Log.w(TAG, "clean", t) }
                        if (cleanL > 0.02f) try { Denoise.apply(bm, (0.5f + cleanL).coerceIn(0.5f, 1f)) } catch (t: Throwable) { Log.w(TAG, "nlm", t) }
                    }
                    if (colorFixOn) {
                        ProcService.update(applicationContext, "Colour fix…", -1)
                        try { ColorFix.apply(bm, colorFixAmt) } catch (t: Throwable) { Log.w(TAG, "colorfix", t) }
                    }
                    if (beautyCfg != null) {
                        ProcService.update(applicationContext, "Beauty…", -1)
                        try { Beauty.apply(bm, rot, beautyCfg) } catch (t: Throwable) { Log.w(TAG, "beauty", t) }
                    }
                    if (fb != null) {
                        ProcService.update(applicationContext, "Focus blur…", -1)
                        try { applyFocusBlur(bm, rot, fb) } catch (t: Throwable) { Log.w(TAG, "focus blur", t) }
                    }
                    if (portrait) {
                        ProcService.update(applicationContext, "Portrait blur…", -1)
                        try { Portrait.apply(bm, rot, bokehAmt) } catch (t: Throwable) { Log.w(TAG, "portrait", t) }
                    }
                    if (aiBokeh > 0.05f && currentMode != Mode.NIGHT && currentMode != Mode.UNIGHT) {
                        try { Portrait.applyIfPerson(bm, rot, aiBokeh) } catch (t: Throwable) { Log.w(TAG, "ai bokeh", t) }
                    }
                    if (prefs.watermark) {
                        try {
                            val d = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
                            Watermark.draw(bm, rot, "Shot on UltraCam RAW  •  $d")
                        } catch (t: Throwable) { Log.w(TAG, "watermark", t) }
                    }
                    val uri = saveBitmap(bm, orient, st, crop = true)
                    if (prefs.saveDng && b.dng != null) saveDngToGallery(b.dng, "ULTRACAM_${st}.dng")
                    makeThumb(bm, orient, uri)
                    bm.recycle()
                } catch (t: Throwable) {
                    Log.e(TAG, "raw process", t)
                    try { if (b.dng != null) saveDngToGallery(b.dng, "ULTRACAM_${st}.dng") } catch (ignored: Throwable) { }
                    ui.post { toast("RAW processing fail (memory?) — DNG save ho gayi agar thi") }
                } finally {
                    NativeRaw.destroy(b.handle)
                    if (uw != null) NativeRaw.destroy(uw.handle)
                    b.dng?.delete()
                }
            }
            withContext(Dispatchers.Main) {
                pendingJobs--
                refreshBusy()
                if (pendingJobs == 0) {
                    setStatus(null)
                    try { stopService(Intent(this@MainActivity, ProcService::class.java)) } catch (e: Throwable) { }
                    ProcService.done(applicationContext, "RAW photo ready ✓ — Gallery me save ho gayi")
                }
            }
        }
    }

    private fun saveDngToGallery(file: File, name: String) {
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng")
        if (Build.VERSION.SDK_INT >= 29) {
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraCam")
            v.put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
        contentResolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
        finishPending(uri)
    }

    private fun setStatusSoft(s: String) {
        // processing progress is shown in the notification bar only; camera screen stays clean
    }

    // ===================================================================== saving
    private fun degreesFor(o: Int): Int = when (o) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90
        ExifInterface.ORIENTATION_ROTATE_180 -> 180
        ExifInterface.ORIENTATION_ROTATE_270 -> 270
        else -> 0
    }

    private fun imageValues(name: String): ContentValues {
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) {
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/UltraCam")
            v.put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        return v
    }

    private fun finishPending(uri: Uri) {
        if (Build.VERSION.SDK_INT >= 29) {
            val u = ContentValues()
            u.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, u, null, null)
        }
    }

    private fun writeOrientation(uri: Uri, orientation: Int) {
        try {
            contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                val ex = ExifInterface(pfd.fileDescriptor)
                ex.setAttribute(ExifInterface.TAG_ORIENTATION, orientation.toString())
                ex.saveAttributes()
            }
        } catch (e: Exception) {
            Log.w(TAG, "exif write", e)
        }
    }

    private fun saveBitmap(bmp0: Bitmap, orientation: Int, st: String, crop: Boolean = false): Uri? {
        val bmp = if (crop && prefs.fullScreen) { try { cropToScreen(bmp0, orientation) } catch (t: Throwable) { bmp0 } } else bmp0
        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageValues("ULTRACAM_$st.jpg")
        ) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        if (bmp !== bmp0) bmp.recycle()
        writeOrientation(uri, orientation)
        finishPending(uri)
        return uri
    }

    private fun saveFileToGallery(file: File, name: String? = null) {
        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, imageValues(name ?: "ULTRACAM_${stamp()}_RAW.jpg")
        ) ?: return
        contentResolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
        finishPending(uri)
        try {
            val o = BitmapFactory.Options()
            o.inSampleSize = 16
            val small = BitmapFactory.decodeFile(file.absolutePath, o)
            if (small != null) makeThumbSmall(small, orientationOf(file), uri)
        } catch (e: Exception) { }
    }

    private fun makeThumb(bmp: Bitmap, orientation: Int, uri: Uri?) {
        val tw = 160
        val th = max(1, (bmp.height * tw / bmp.width.toFloat()).roundToInt())
        val small = Bitmap.createScaledBitmap(bmp, tw, th, true)
        makeThumbSmall(small, orientation, uri)
    }

    private fun makeThumbSmall(small: Bitmap, orientation: Int, uri: Uri?) {
        val m = Matrix()
        m.postRotate(degreesFor(orientation).toFloat())
        val rot = Bitmap.createBitmap(small, 0, 0, small.width, small.height, m, true)
        ui.post {
            thumb.setImageBitmap(rot)
            lastUri = uri
        }
    }

    private fun openLast() {
        val u = lastUri
        if (u == null) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
            } catch (e: Exception) { }
            return
        }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(u, "image/*")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            toast("Gallery open nahi hui")
        }
    }

    // ===================================================================== video
    private fun toggleRecording() {
        val r = recording
        if (r != null) {
            r.stop()
            recording = null
            return
        }
        val vc = videoCapture ?: return
        val cv = ContentValues()
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, "ULTRACAM_${stamp()}")
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/UltraCam")
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, out)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pr = pr.withAudioEnabled()
        }
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    shutter.recording = true
                    setStatus("● REC")
                }
                is VideoRecordEvent.Status -> {
                    val sec = ev.recordingStats.recordedDurationNanos / 1_000_000_000L
                    statusTv.text = String.format(Locale.US, "● REC %02d:%02d", sec / 60, sec % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    shutter.recording = false
                    setStatus(null)
                    recording = null
                    if (ev.hasError()) toast("Video error ${ev.error}") else toast("Video saved ✔")
                }
                else -> {}
            }
        }
    }

    // ===================================================================== settings
    private fun showBeauty(front: Boolean) {
        val sv = ScrollView(this)
        val box = vcol()
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        sv.addView(box)
        var dlg: AlertDialog? = null

        fun toggleRow(label: String, cur: Boolean, onSet: (Boolean) -> Unit) {
            var state = cur
            val v = pill("") {}
            fun upd() { v.text = "$label: ${if (state) "ON" else "OFF"}"; styleSel(v, state) }
            v.setOnClickListener { state = !state; onSet(state); upd(); refreshBeautyBtn() }
            upd()
            box.addView(v)
        }

        val head = txt(if (front) "FRONT camera" else "BACK camera", 14f, ACCENT)
        head.setPadding(0, dp(4), 0, dp(4))
        box.addView(head)
        toggleRow("Beauty (master)", prefs.beautyOn(front)) { prefs.setBeautyOn(front, it) }
        toggleRow("AI Auto-Beauty (face dekh ke strength khud set)", prefs.beautyAi(front)) { prefs.setBeautyAi(front, it) }
        box.addView(sliderRow("Beauty POWER (sab effects ka strength, 100 = normal)", 200, prefs.beautyPower, { "$it%" }) { prefs.beautyPower = it })
        for (f in Beauty.FEATURES) {
            val sep = txt("", 6f)
            box.addView(sep)
            toggleRow(f.label, prefs.beautyFeatOn(front, f.id, f.defOn)) { prefs.setBeautyFeatOn(front, f.id, it) }
            box.addView(sliderRow("Amount", 100, prefs.beautyAmt(front, f.id, f.defAmt), { "$it" }) { prefs.setBeautyAmt(front, f.id, it) })
        }
        val note = txt("Beauty photo save hote waqt lagti hai (live preview me nahi dikhti). Group photo me har face par lagti hai.", 11f)
        note.setPadding(0, dp(10), 0, dp(4))
        box.addView(note)
        box.addView(pill(if (front) "Switch to BACK camera settings" else "Switch to FRONT camera settings") {
            dlg?.dismiss()
            showBeauty(!front)
        })
        dlg = AlertDialog.Builder(this)
            .setTitle("✨ Beauty")
            .setView(sv)
            .setPositiveButton("OK") { _, _ -> refreshBeautyBtn() }
            .show()
    }

    private fun showBlur() {
        val sv = ScrollView(this)
        val box = vcol()
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        sv.addView(box)
        val onBtn = pill("") {}
        fun updOn() {
            onBtn.text = "Focus blur: ${if (prefs.focusBlur) "ON" else "OFF"}"
            styleSel(onBtn, prefs.focusBlur)
        }
        onBtn.setOnClickListener { prefs.focusBlur = !prefs.focusBlur; updOn(); refreshBlurDetailBtns() }
        updOn()
        box.addView(onBtn)
        box.addView(sliderRow("Blur", 100, prefs.focusBlurAmt, { "$it%" }) {
            prefs.focusBlurAmt = it
            refreshBlurDetailBtns()
        })
        val row = hrow()
        val views = ArrayList<TextView>()
        val names = listOf("Person (AI)", "Focus point (tap)")
        for ((i, n) in names.withIndex()) {
            val v = pill(n) {}
            v.setOnClickListener {
                prefs.focusBlurMode = i
                for ((j, o) in views.withIndex()) styleSel(o, j == i)
            }
            styleSel(v, i == prefs.focusBlurMode)
            views.add(v)
            row.addView(v)
        }
        box.addView(hscroll(row))
        val note = txt(
            "Person (AI): insaan milne par uska background blur; insaan na mile to jahan tap karke focus kiya wahi sharp rehta hai, baaki blur.\n" +
                "Focus point: preview me jahan tap karoge (focus ring), uske aaspaas sharp, baaki blur.\n" +
                "Blur photo save hote waqt lagta hai (live preview me nahi dikhta). Sab photo modes + RAW me chalta hai. 0% = bahut halka, 100% = bahut strong.",
            11f
        )
        note.setPadding(0, dp(10), 0, dp(4))
        box.addView(note)
        AlertDialog.Builder(this)
            .setTitle("🌫 Focus Blur")
            .setView(sv)
            .setPositiveButton("OK") { _, _ -> refreshBlurDetailBtns() }
            .show()
    }

    private fun showDetails() {
        val sv = ScrollView(this)
        val box = vcol()
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        sv.addView(box)
        val live = txt("", 12f, ACCENT)
        live.setPadding(0, dp(8), 0, dp(8))
        fun refreshLive() {
            if (!prefs.autoDetail) {
                live.text = "Manual mode: Settings > Image engine ke Denoise / Sharpness / Detail sliders chalenge."
                return
            }
            val front = lensFacing == CameraSelector.LENS_FACING_FRONT
            val t = AutoDetail.tune(meta.iso, meta.expNs, front, prefs.detailLevel)
            val sensor = if (meta.iso > 0 && meta.expNs > 0L) "ISO ${meta.iso}  ${fmtShutter(meta.expNs)}" else "sensor reading aa rahi hai…"
            live.text = "Abhi light: ${t.label} ($sensor)\n" +
                "→ denoise ${(t.denoise * 100).roundToInt()}  •  sharpness ${(t.sharp * 100).roundToInt()}  •  detail ${(t.detail * 100).roundToInt()}"
        }
        val onBtn = pill("") {}
        fun updOn() {
            onBtn.text = "Auto Details: ${if (prefs.autoDetail) "ON" else "OFF"}"
            styleSel(onBtn, prefs.autoDetail)
            refreshLive()
        }
        onBtn.setOnClickListener { prefs.autoDetail = !prefs.autoDetail; updOn(); refreshBlurDetailBtns() }
        box.addView(onBtn)
        box.addView(live)
        box.addView(sliderRow("Level", 100, prefs.detailLevel, { "$it" }) {
            prefs.detailLevel = it
            refreshLive()
        })
        val note = txt(
            "Auto Details har photo se pehle dekhta hai ki sensor ko kitni light mil rahi hai (ISO x shutter):\n" +
                "• Tez roshni: noise kam hota hai, isliye detail + sharpness zyada, denoise halka\n" +
                "• Low light: noise zyada hota hai, isliye detail thodi kam rakhta hai aur denoise zyada, taaki noise sharp na ho\n" +
                "Level slider: 0 = zyada smooth / clean, 50 = balanced, 100 = maximum detail (low light me asar apne aap kam ho jaata hai). " +
                "Tap karke focus karoge to wahi jagah ki light/focus pe exposure lagta hai, aur details utne hi kaam aate hain jitni light mili.",
            11f
        )
        note.setPadding(0, dp(10), 0, dp(4))
        box.addView(note)
        updOn()
        AlertDialog.Builder(this)
            .setTitle("🔍 Details")
            .setView(sv)
            .setPositiveButton("OK") { _, _ -> refreshBlurDetailBtns() }
            .show()
    }

    private fun showSettings() {
        val sv = ScrollView(this)
        val box = vcol()
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        sv.addView(box)
        var rebind = false

        fun title(s: String) {
            val t = txt(s, 14f, ACCENT)
            t.setPadding(0, dp(12), 0, dp(4))
            box.addView(t)
        }

        fun choice(names: List<String>, cur: Int, onPick: (Int) -> Unit) {
            val row = hrow()
            val views = ArrayList<TextView>()
            for ((i, n) in names.withIndex()) {
                val v = pill(n) {}
                v.setOnClickListener {
                    onPick(i)
                    for ((j, o) in views.withIndex()) styleSel(o, j == i)
                }
                styleSel(v, i == cur)
                views.add(v)
                row.addView(v)
            }
            box.addView(hscroll(row))
        }

        fun toggle(label: String, cur: Boolean, onSet: (Boolean) -> Unit) {
            var state = cur
            val v = pill("") {}
            fun upd() { v.text = "$label: ${if (state) "ON" else "OFF"}"; styleSel(v, state) }
            v.setOnClickListener { state = !state; onSet(state); upd() }
            upd()
            box.addView(v)
        }

        title("Capture resolution")
        choice(listOf("12MP (4K+)", "16MP", "MAX 64MP direct"), prefs.capRes) { prefs.capRes = it; rebind = true }
        title("Output size (software upscale + super-res)")
        choice(listOf("Native", "1.5x Hi-Res", "2x Max (≤30MP)"), prefs.outScale) { prefs.outScale = it }
        title("Image engine")
        box.addView(sliderRow("Denoise", 100, prefs.denoise, { "$it" }) { prefs.denoise = it })
        box.addView(sliderRow("Sharpness", 100, prefs.sharp, { "$it" }) { prefs.sharp = it })
        box.addView(sliderRow("Detail", 100, prefs.detail, { "$it" }) { prefs.detail = it })
        box.addView(sliderRow("Shadows", 100, prefs.lift, { "$it" }) { prefs.lift = it })
        box.addView(sliderRow("Enhance (Google Photos style)", 100, prefs.enhance, { "$it" }) { prefs.enhance = it })
        title("Details (auto)")
        toggle("Auto Details (light dekh ke detail / noise balance; upar ke Denoise-Sharp-Detail sliders tab ignore)", prefs.autoDetail) {
            prefs.autoDetail = it
            refreshBlurDetailBtns()
        }
        box.addView(sliderRow("Detail lvl", 100, prefs.detailLevel, { "$it" }) { prefs.detailLevel = it })
        box.addView(sliderRow("Chroma noise clean (rang-birange dots hatata hai)", 100, prefs.cleanChroma, { "$it" }) { prefs.cleanChroma = it })
        box.addView(sliderRow("Grain clean (flat jagah; zyada = smooth, kam detail)", 100, prefs.cleanLuma, { "$it" }) { prefs.cleanLuma = it })
        box.addView(pill("🔍 Live details panel") { showDetails() })
        title("Focus blur")
        box.addView(pill("🌫 Focus blur settings (strength + person / tap point)") { showBlur() })
        title("Screen")
        toggle("Full screen (poori screen preview + photo screen ke shape me crop)", prefs.fullScreen) { prefs.fullScreen = it; applyFullScreen() }
        title("Front flash")
        box.addView(sliderRow("Flash %", 100, prefs.frontFlash, { "$it" }) { prefs.frontFlash = it.coerceIn(20, 100) })
        box.addView(sliderRow("Flash cool tint (face yellow ho to badhao)", 100, prefs.frontFlashCool, { "$it" }) { prefs.frontFlashCool = it })
        toggle("Selfie colour fix (yellow / orange cast hatata hai, save hote waqt)", prefs.colorFix) { prefs.colorFix = it }
        box.addView(sliderRow("Colour fix strength", 100, prefs.colorFixAmt, { "$it" }) { prefs.colorFixAmt = it })
        title("Night")
        toggle("Night Pro tripod (NIGHT 3 frames x ~3.5s, ULTRA NIGHT 4 x ~6s — phone tika ke)", prefs.tripod) { prefs.tripod = it }
        title("Smart")
        toggle("AI Director (light • shutter • frames • aperture blur • enhance)", prefs.aiDirector) { prefs.aiDirector = it }
        toggle("Smart AUTO (multi-frame + AI focus)", prefs.smartAuto) { prefs.smartAuto = it; rebind = true }
        toggle("Auto scene (low light → NIGHT)", prefs.autoScene) { prefs.autoScene = it }
        toggle("Auto background blur (insaan milne par, front + back)", prefs.autoBlur) { prefs.autoBlur = it }
        title("RAW engine (sab modes)")
        toggle("RAW burst merge + develop (JPEG se kahin behtar)", prefs.rawEngine) { prefs.rawEngine = it }
        toggle("RAW PANO / LAPSE / TRAILS bhi (chalte waqt live preview band rehta hai)", prefs.rawMulti) { prefs.rawMulti = it }
        toggle("DNG bhi save karo (Lightroom / Snapseed edit)", prefs.saveDng) { prefs.saveDng = it }
        toggle("Sub-pixel super-res (RAW: zyada detail, thoda slow + RAM)", prefs.subPixelSr) { prefs.subPixelSr = it }
        box.addView(sliderRow("Color pop (sky / hariyali)", 100, prefs.colorPop, { "$it" }) { prefs.colorPop = it })
        title("Beauty (face milna zaroori; photo save hote waqt lagta hai)")
        box.addView(pill("✨ Front camera beauty settings") { showBeauty(true) })
        box.addView(pill("✨ Back camera beauty settings") { showBeauty(false) })
        title("Other")
        toggle("Original JPEG bhi save karo (Gallery compare)", prefs.keepOriginal) { prefs.keepOriginal = it }
        toggle("Watermark (Shot on UltraCam)", prefs.watermark) { prefs.watermark = it }
        title("Presets")
        val saveRow = hrow()
        val loadRow = hrow()
        for (i in 1..3) {
            saveRow.addView(pill("Save $i") { prefs.savePreset(i); toast("Preset $i saved") })
            loadRow.addView(pill("Load $i") {
                if (prefs.loadPreset(i)) {
                    toast("Preset $i loaded")
                    refreshLookPills()
                    refreshTopButtons()
                    analyzer.level = prefs.analyzer
                    rebind = true
                } else toast("Preset $i khali hai")
            })
        }
        box.addView(hscroll(saveRow))
        box.addView(hscroll(loadRow))
        box.addView(pill("ℹ Camera Info") { showCameraInfo() })

        AlertDialog.Builder(this)
            .setTitle("UltraCam Settings")
            .setView(sv)
            .setPositiveButton("OK") { _, _ -> if (rebind) bindCamera(false) }
            .show()
    }
}

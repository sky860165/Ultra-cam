package com.ultracam.app

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** A colour "tune". shadow/high are RGB offsets (0..255 scale) for split toning. */
class Look(
    val id: String,
    val name: String,
    val sat: Float = 1f,
    val vib: Float = 0f,
    val contrast: Float = 1f,
    val bright: Float = 0f,
    val temp: Float = 0f,
    val tint: Float = 0f,
    val fade: Float = 0f,
    val shadow: FloatArray = floatArrayOf(0f, 0f, 0f),
    val high: FloatArray = floatArrayOf(0f, 0f, 0f),
    val mono: Boolean = false,
    val vignette: Float = 0f,
    val grain: Float = 0f
)

object Looks {
    val NATURAL = Look("natural", "Natural")

    val ALL: List<Look> = listOf(
        NATURAL,
        Look("vivid", "Vivid", sat = 1.25f, vib = 0.30f, contrast = 1.15f),
        Look("hdrpop", "HDR Pop", sat = 1.20f, vib = 0.20f, contrast = 1.30f, bright = 0.05f),
        Look("cinema", "Cinematic", sat = 1.05f, contrast = 1.22f, fade = 0.03f,
            shadow = floatArrayOf(-8f, 4f, 14f), high = floatArrayOf(14f, 5f, -10f), vignette = 0.20f),
        Look("golden", "Golden", sat = 1.12f, temp = 0.55f, contrast = 1.08f, high = floatArrayOf(10f, 4f, -6f)),
        Look("cool", "Cool Blue", sat = 1.05f, temp = -0.55f, contrast = 1.06f),
        Look("sunset", "Sunset", sat = 1.28f, temp = 0.70f, contrast = 1.12f, high = floatArrayOf(16f, 2f, -12f)),
        Look("bw", "B&W", contrast = 1.25f, mono = true),
        Look("noir", "Noir", contrast = 1.75f, mono = true, vignette = 0.45f, bright = -0.1f),
        Look("film", "Film", sat = 0.95f, contrast = 1.10f, fade = 0.05f, grain = 0.35f,
            shadow = floatArrayOf(-4f, 3f, 8f), high = floatArrayOf(10f, 4f, -6f)),
        Look("vintage", "Vintage", sat = 0.80f, temp = 0.30f, contrast = 0.98f, fade = 0.10f,
            vignette = 0.35f, grain = 0.45f),
        Look("pastel", "Pastel", sat = 0.88f, contrast = 0.86f, bright = 0.22f, fade = 0.08f),
        Look("moody", "Moody", sat = 0.85f, contrast = 1.28f, bright = -0.25f,
            shadow = floatArrayOf(-6f, 2f, 14f), vignette = 0.30f),
        Look("portrait", "Portrait", sat = 0.96f, vib = 0.12f, temp = 0.15f, contrast = 0.96f, bright = 0.08f),
        Look("food", "Food", sat = 1.30f, vib = 0.20f, temp = 0.22f, contrast = 1.15f),
        Look("cyber", "Cyberpunk", sat = 1.30f, contrast = 1.32f, tint = 0.30f,
            shadow = floatArrayOf(6f, -6f, 26f), high = floatArrayOf(18f, -4f, 10f)),
        Look("velvia", "Landscape", sat = 1.40f, vib = 0.20f, contrast = 1.22f),
        Look("matte", "Matte", sat = 0.90f, contrast = 0.95f, fade = 0.09f),
        Look("leica", "Classic Mono-Pop", sat = 0.90f, contrast = 1.26f, fade = 0.02f, vignette = 0.22f),
        Look("neon", "Night Neon", sat = 1.35f, vib = 0.25f, contrast = 1.20f, bright = 0.1f,
            shadow = floatArrayOf(-4f, 0f, 16f))
    )

    fun byId(id: String): Look = ALL.firstOrNull { it.id == id } ?: NATURAL
}

/** Look blended by intensity t (0..1), prepared for fast per-pixel use. */
class LookRuntime(look: Look, private val t: Float) {
    private fun l(a: Float, b: Float): Float = a + (b - a) * t

    private val sat = l(1f, look.sat)
    private val vib = l(0f, look.vib)
    private val vignette = l(0f, look.vignette)
    private val grain = l(0f, look.grain)
    private val monoAmt = if (look.mono) t else 0f
    private val shR = look.shadow[0] * t
    private val shG = look.shadow[1] * t
    private val shB = look.shadow[2] * t
    private val hiR = look.high[0] * t
    private val hiG = look.high[1] * t
    private val hiB = look.high[2] * t
    private val wr: Float
    private val wg: Float
    private val wb: Float
    private val lut = FloatArray(256)

    init {
        val temp = l(0f, look.temp)
        val tint = l(0f, look.tint)
        wr = 1f + 0.12f * temp + 0.05f * tint
        wb = 1f - 0.12f * temp + 0.05f * tint
        wg = 1f - 0.08f * tint
        val contrast = l(1f, look.contrast)
        val bright = l(0f, look.bright)
        val fade = l(0f, look.fade)
        val ev = 2f.pow(bright)
        val k = (contrast - 1f) * 1.3f
        for (i in 0..255) {
            var x = (i / 255f) * ev
            x = min(1f, max(0f, x))
            val s = x * x * (3f - 2f * x)
            var y = x + k * (s - x)
            y = min(1f, max(0f, y))
            y = fade + y * (1f - fade)
            lut[i] = y * 255f
        }
    }

    private fun tone(v: Float): Float {
        val c = if (v < 0f) 0f else if (v > 255f) 255f else v
        val i = c.toInt()
        val f = c - i
        val a = lut[i]
        val b = lut[if (i < 255) i + 1 else 255]
        return a + (b - a) * f
    }

    fun apply(r0: Float, g0: Float, b0: Float, x: Int, y: Int, w: Int, h: Int): Int {
        var r = tone(r0 * wr)
        var g = tone(g0 * wg)
        var b = tone(b0 * wb)
        val lum = 0.299f * r + 0.587f * g + 0.114f * b
        if (monoAmt > 0f) {
            r += (lum - r) * monoAmt
            g += (lum - g) * monoAmt
            b += (lum - b) * monoAmt
        }
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val s0 = (mx - mn) / (mx + 1f)
        val sf = sat + vib * (1f - s0)
        r = lum + (r - lum) * sf
        g = lum + (g - lum) * sf
        b = lum + (b - lum) * sf
        val ln = min(1f, max(0f, lum / 255f))
        val wsh = (1f - ln) * (1f - ln)
        val whi = ln * ln
        r += shR * wsh + hiR * whi
        g += shG * wsh + hiG * whi
        b += shB * wsh + hiB * whi
        if (vignette > 0f) {
            val nx = (x.toFloat() / w - 0.5f) * 2f
            val ny = (y.toFloat() / h - 0.5f) * 2f
            val d = (nx * nx + ny * ny) * 0.5f
            val f = 1f - vignette * d * d * 1.6f
            r *= f; g *= f; b *= f
        }
        if (grain > 0f) {
            var hh = x * 374761393 + y * 668265263
            hh = (hh xor (hh ushr 13)) * 1274126177
            hh = hh xor (hh ushr 16)
            val n = ((hh and 0xFFFF) / 32768f - 1f) * grain * 9f
            r += n; g += n; b += n
        }
        val ri = if (r < 0f) 0 else if (r > 255f) 255 else r.toInt()
        val gi = if (g < 0f) 0 else if (g > 255f) 255 else g.toInt()
        val bi = if (b < 0f) 0 else if (b > 255f) 255 else b.toInt()
        return (0xFF shl 24) or (ri shl 16) or (gi shl 8) or bi
    }
}

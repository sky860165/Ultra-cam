package com.ultracam.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.ColorSpaceTransform
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Result of a RAW burst: a native pipe that already holds the merged Bayer data. Call NativeRaw.destroy(handle) when done. */
class RawBurst(
    val handle: Long,
    val outW: Int,
    val outH: Int,
    val sensorOrientation: Int,
    val frames: Int,
    val dng: File?,
    val note: String,
    /** full (un-zoomed) output size: the developed bitmap is scaled back up to this when zoom > 1 */
    val baseW: Int = outW,
    val baseH: Int = outH
)

/**
 * Camera2 RAW_SENSOR burst. CameraX must be unbound before calling (the camera device is opened directly).
 * Frames are merged incrementally inside the native engine, so memory stays at ~1 reference frame + accumulators.
 */
object RawCapture {
    /** set by the UI before capture(): enable the native sub-pixel super-resolution plane for this burst */
    @Volatile var wantSr: Boolean = false

    private const val TAG = "RawCapture"

    /** RAW capability + a usable RAW size + (optionally) the colour matrices needed to develop it. */
    fun supported(cm: CameraManager, id: String): Boolean = try {
        val c = cm.getCameraCharacteristics(id)
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val cfa = c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT)
        (caps.contains(3) || map?.getOutputSizes(ImageFormat.RAW_SENSOR)?.isNotEmpty() == true) &&
            map?.getOutputSizes(ImageFormat.RAW_SENSOR)?.isNotEmpty() == true && cfa != null && cfa in 0..3 &&
            c.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL) != null
    } catch (e: Exception) { false }

    private fun matrix(t: ColorSpaceTransform?): FloatArray? {
        if (t == null) return null
        val o = FloatArray(9)
        for (r in 0 until 3) for (c in 0 until 3) o[r * 3 + c] = t.getElement(c, r).toFloat()
        return o
    }

    /**
     * @param evs  per-frame exposure offset in stops (index 0 must be 0 = reference). size == frame count.
     * @param longExposure allow long shutter when the phone is steady (night)
     */
    @SuppressLint("MissingPermission")
    suspend fun capture(
        ctx: Context, cm: CameraManager, id: String, evs: FloatArray, longExposure: Boolean,
        gyro: GyroMeter, cacheDir: File, wantDng: Boolean, deviceExifOrientation: Int,
        torch: Boolean = false,              // LED torch ON for the whole burst (steady light => all frames merge cleanly)
        zoom: Float = 1f,                    // > 1: only the centre window is developed (then scaled back up by the caller)
        manualIso: Int = 0, manualExpNs: Long = 0L,   // PRO / ASTRO: fixed exposure
        manualFocus: Float = -1f,            // diopters, < 0 = autofocus
        awbMode: Int = -1,                   // -1 = auto
        // ---- multi-shot session (PANO / LAPSE / TRAILS): the camera stays open, `shots` independent bursts are taken
        shots: Int = 1,
        shotGapMs: Long = 0L,                // pause between shots (timelapse interval)
        lockExposure: Boolean = false,       // later shots reuse the exposure of the first one (pano / star trails)
        shouldContinue: (() -> Boolean)? = null,
        onShot: (suspend (RawBurst, Int) -> Unit)? = null,   // owner of the burst afterwards (must destroy it); capture returns null
        status: (String) -> Unit
    ): RawBurst? = withContext(Dispatchers.Default) {
        val chars = cm.getCameraCharacteristics(id)
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return@withContext null
        val rawSizes = map.getOutputSizes(ImageFormat.RAW_SENSOR) ?: return@withContext null
        val sorted = rawSizes.sortedBy { it.width.toLong() * it.height }
        val rawSize = sorted.lastOrNull { it.width.toLong() * it.height <= 21_000_000L } ?: sorted.first()
        val n = evs.size
        val cfa = chars.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: return@withContext null
        val whiteStatic = chars.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL) ?: 1023
        val sensorOri = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val manual = caps.contains(1)
        val isoRange = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val expRange = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val minFocus = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val physSize = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        val tsRealtime = chars.get(CameraCharacteristics.SENSOR_INFO_TIMESTAMP_SOURCE) == 1
        val pixel = chars.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)
        val active = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        val fm1 = matrix(chars.get(CameraCharacteristics.SENSOR_FORWARD_MATRIX1))
        val fm2 = matrix(chars.get(CameraCharacteristics.SENSOR_FORWARD_MATRIX2))
        val cm1 = matrix(chars.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM1))
        val cm2 = matrix(chars.get(CameraCharacteristics.SENSOR_COLOR_TRANSFORM2))
        val cc1 = matrix(chars.get(CameraCharacteristics.SENSOR_CALIBRATION_TRANSFORM1))
        val cc2 = matrix(chars.get(CameraCharacteristics.SENSOR_CALIBRATION_TRANSFORM2))
        val ill1 = (chars.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT1) as Number?)?.toInt() ?: 21
        val ill2 = (chars.get(CameraCharacteristics.SENSOR_REFERENCE_ILLUMINANT2) as Number?)?.toInt() ?: ill1
        val blackPattern = chars.get(CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN)

        // crop to the active array only when the RAW buffer is the full pixel array (includes optical black)
        var cropX = 0; var cropY = 0; var outW = rawSize.width and 1.inv(); var outH = rawSize.height and 1.inv()
        if (pixel != null && active != null && rawSize.width == pixel.width && rawSize.height == pixel.height &&
            (active.width() < pixel.width || active.height() < pixel.height)) {
            cropX = active.left and 1.inv(); cropY = active.top and 1.inv()
            outW = active.width() and 1.inv(); outH = active.height() and 1.inv()
        }

        val baseW = outW
        val baseH = outH
        if (zoom > 1.03f) {
            val cw = ((outW / zoom).toInt() and 1.inv()).coerceAtLeast(64)
            val ch = ((outH / zoom).toInt() and 1.inv()).coerceAtLeast(64)
            cropX += ((outW - cw) / 2) and 1.inv()
            cropY += ((outH - ch) / 2) and 1.inv()
            outW = cw; outH = ch
        }
        val useTorch = torch && chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val manualAE = manual && manualIso > 0 && manualExpNs > 0L && isoRange != null && expRange != null
        val manualAF = manualFocus >= 0f && minFocus > 0f

        val thread = HandlerThread("ultracam-raw").also { it.start() }
        val handler = Handler(thread.looper)
        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var reader: ImageReader? = null
        var dummyTex: SurfaceTexture? = null
        var dummySurf: Surface? = null
        var handle = 0L
        var dngFile: File? = null
        var note = ""
        try {
            status("RAW • camera khul raha hai")
            device = suspendCancellableCoroutine { cont ->
                cm.openCamera(id, object : CameraDevice.StateCallback() {
                    override fun onOpened(c: CameraDevice) { if (cont.isActive) cont.resume(c) else c.close() }
                    override fun onDisconnected(c: CameraDevice) { c.close(); if (cont.isActive) cont.resumeWithException(IllegalStateException("camera disconnected")) }
                    override fun onError(c: CameraDevice, e: Int) { c.close(); if (cont.isActive) cont.resumeWithException(IllegalStateException("camera error $e")) }
                }, handler)
            }
            val dev = device!!
            val rdr = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 3)
            reader = rdr
            val rawSurface = rdr.surface
            val prevSizes = map.getOutputSizes(SurfaceTexture::class.java)
            val prevSize = prevSizes?.filter { it.width >= 640 && it.width <= 1280 }?.minByOrNull { it.width.toLong() * it.height }
                ?: prevSizes?.minByOrNull { it.width.toLong() * it.height }
            val tex = SurfaceTexture(0)
            if (prevSize != null) tex.setDefaultBufferSize(prevSize.width, prevSize.height)
            dummyTex = tex
            val prevSurface = Surface(tex)
            dummySurf = prevSurface

            session = suspendCancellableCoroutine { cont ->
                dev.createCaptureSession(listOf(prevSurface, rawSurface), object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) { if (cont.isActive) cont.resume(s) }
                    override fun onConfigureFailed(s: CameraCaptureSession) { if (cont.isActive) cont.resumeWithException(IllegalStateException("RAW session configure failed")) }
                }, handler)
            }
            val ses = session!!

            // ---- 3A on the dummy preview stream
            val lastPrevRef = java.util.concurrent.atomic.AtomicReference<TotalCaptureResult?>(null)
            val pb = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            pb.addTarget(prevSurface)
            pb.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            if (manualAF) {
                pb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                pb.set(CaptureRequest.LENS_FOCUS_DISTANCE, manualFocus.coerceIn(0f, minFocus))
            } else if (minFocus > 0f) pb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            if (useTorch) pb.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
            if (awbMode >= 0) pb.set(CaptureRequest.CONTROL_AWB_MODE, awbMode)
            if (manualAE) {
                pb.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                pb.set(CaptureRequest.SENSOR_EXPOSURE_TIME, manualExpNs.coerceIn(expRange!!.lower, expRange.upper))
                pb.set(CaptureRequest.SENSOR_SENSITIVITY, manualIso.coerceIn(isoRange!!.lower, isoRange.upper))
            }
            val prevCb = object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) { lastPrevRef.set(res) }
            }
            ses.setRepeatingRequest(pb.build(), prevCb, handler)
            gyro.start()
            status("RAW • exposure set ho raha hai")
            val t0 = SystemClock.elapsedRealtime()
            var okCount = 0
            val waitMs = if (useTorch) 2600L else 1800L
            while (SystemClock.elapsedRealtime() - t0 < waitMs) {
                delay(60)
                if (manualAE) { if (SystemClock.elapsedRealtime() - t0 > 500) break else continue }
                val st = lastPrevRef.get()?.get(CaptureResult.CONTROL_AE_STATE)
                val aeOk = st == CaptureResult.CONTROL_AE_STATE_CONVERGED || st == CaptureResult.CONTROL_AE_STATE_LOCKED
                // under the LED the white balance must settle too, otherwise the burst comes out yellow
                val awbSt = lastPrevRef.get()?.get(CaptureResult.CONTROL_AWB_STATE)
                val awbOk = !useTorch || awbSt == null || awbSt == CaptureResult.CONTROL_AWB_STATE_CONVERGED || awbSt == CaptureResult.CONTROL_AWB_STATE_LOCKED
                if (aeOk && awbOk) okCount++ else okCount = 0
                if (okCount >= 4 && SystemClock.elapsedRealtime() - t0 > (if (useTorch) 900 else 600)) break
            }
            if (minFocus > 0f && !manualAF) {
                try {
                    val ab = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                    ab.addTarget(prevSurface)
                    ab.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    if (useTorch) ab.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
                    ab.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
                    ses.capture(ab.build(), prevCb, handler)
                    val ta = SystemClock.elapsedRealtime()
                    while (SystemClock.elapsedRealtime() - ta < 1300) {
                        delay(60)
                        val af = lastPrevRef.get()?.get(CaptureResult.CONTROL_AF_STATE)
                        if (af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED || af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) break
                    }
                } catch (e: Exception) { Log.w(TAG, "af", e) }
            }
            // wait a moment for the hand to settle (gyro), max ~600 ms
            if (gyro.available) {
                val tg = SystemClock.elapsedRealtime()
                while (SystemClock.elapsedRealtime() - tg < 600 && gyro.recentPeak(120) > 0.12f) delay(40)
            }
            var lastBurst: RawBurst? = null
            var lockedT = 0L
            var lockedIso = 0
            for (shotIdx in 0 until shots) {
            if (shotIdx > 0) {
                if (shouldContinue != null && !shouldContinue()) break
                if (shotGapMs > 0) delay(shotGapMs)
                if (shouldContinue != null && !shouldContinue()) break
            }
            handle = 0L; dngFile = null; note = ""
            val steady = !gyro.available || gyro.recentPeak(400) < 0.05f

            // ---- exposure plan: shorter exposure + more frames when handheld (like HDR+), long when on a tripod at night
            val prev = lastPrevRef.get()
            val tAe = prev?.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 16_000_000L
            val isoAe = prev?.get(CaptureResult.SENSOR_SENSITIVITY) ?: 200
            val maxExpNs = if (longExposure && steady) 250_000_000L else if (steady) 100_000_000L else 40_000_000L
            var tPlan = min(tAe, maxExpNs)
            var isoPlan = (isoAe.toDouble() * tAe.toDouble() / tPlan.toDouble()).toInt()
            if (isoRange != null) {
                if (isoPlan > isoRange.upper) { isoPlan = isoRange.upper; tPlan = (tAe.toDouble() * isoAe / isoPlan).toLong() }
                if (isoPlan < isoRange.lower) isoPlan = isoRange.lower
            }
            if (expRange != null) tPlan = tPlan.coerceIn(expRange.lower, expRange.upper)
            if (manualAE) {
                tPlan = manualExpNs.coerceIn(expRange!!.lower, expRange.upper)
                isoPlan = manualIso.coerceIn(isoRange!!.lower, isoRange.upper)
            }
            if (lockExposure) {
                if (shotIdx == 0) { lockedT = tPlan; lockedIso = isoPlan } else { tPlan = lockedT; isoPlan = lockedIso }
            }

            fun buildReq(k: Int): CaptureRequest {
                val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                b.addTarget(rawSurface)
                b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                b.set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE, CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE_ON)
                b.set(CaptureRequest.CONTROL_AWB_LOCK, true)
                if (manualAF) {
                    b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                    b.set(CaptureRequest.LENS_FOCUS_DISTANCE, manualFocus.coerceIn(0f, minFocus))
                } else if (minFocus > 0f) b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                if (useTorch) b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
                if (awbMode >= 0) b.set(CaptureRequest.CONTROL_AWB_MODE, awbMode)
                if (manual && isoRange != null && expRange != null) {
                    var t = tPlan.toDouble() * 2.0.pow(evs[k].toDouble())
                    var iso = isoPlan.toDouble()
                    if (t < expRange.lower) { iso *= t / expRange.lower; t = expRange.lower.toDouble() }
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                    b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, t.toLong().coerceIn(expRange.lower, expRange.upper))
                    b.set(CaptureRequest.SENSOR_SENSITIVITY, iso.toInt().coerceIn(isoRange.lower, isoRange.upper))
                } else {
                    b.set(CaptureRequest.CONTROL_AE_LOCK, true)
                }
                return b.build()
            }

            // ---- burst: pipeline depth 2, each frame is merged natively as soon as it arrives
            val lock = Any()
            val images = ConcurrentHashMap<Long, Image>()
            val results = ConcurrentHashMap<Long, TotalCaptureResult>()
            val startNs = ConcurrentHashMap<Long, Long>()
            var tryProcessRef: (Long) -> Unit = { }
            var submitted = 0
            var processed = 0
            var failures = 0
            var refProduct = 0.0
            var rawW = rawSize.width
            val done = CompletableDeferred<Unit>()

            fun submitNext() {
                if (submitted >= n) return
                val k = submitted
                submitted++
                try {
                    ses.capture(buildReq(k), object : CameraCaptureSession.CaptureCallback() {
                        override fun onCaptureStarted(s: CameraCaptureSession, r: CaptureRequest, timestamp: Long, frameNumber: Long) {
                            startNs[timestamp] = if (tsRealtime) timestamp else SystemClock.elapsedRealtimeNanos()
                        }
                        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                            val ts = res.get(CaptureResult.SENSOR_TIMESTAMP) ?: return
                            results[ts] = res
                            tryProcessRef(ts)
                        }
                        override fun onCaptureFailed(s: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
                            synchronized(lock) { failures++; processed++; if (processed >= n) { done.complete(Unit) } else { submitNext() }; Unit }
                        }
                    }, handler)
                } catch (e: Exception) {
                    Log.w(TAG, "submit", e)
                    synchronized(lock) { failures++; processed++; if (processed >= n) done.complete(Unit); Unit }
                }
            }

            fun createPipe(res: TotalCaptureResult): Long {
                val white = (res.get(CaptureResult.SENSOR_DYNAMIC_WHITE_LEVEL) ?: whiteStatic).toFloat()
                val dyn = res.get(CaptureResult.SENSOR_DYNAMIC_BLACK_LEVEL)
                val black = FloatArray(4) { k ->
                    dyn?.getOrNull(k) ?: (blackPattern?.getOffsetForIndex(k % 2, k / 2)?.toFloat() ?: 64f)
                }
                var s = 0.0; var o = 0.0; var cnt = 0
                res.get(CaptureResult.SENSOR_NOISE_PROFILE)?.forEach { p -> s += p.first; o += p.second; cnt++ }
                val noiseS = if (cnt > 0) (s / cnt).toFloat() else 0.0008f
                val noiseO = if (cnt > 0) (o / cnt).toFloat() else 4e-6f
                val nc = res.get(CaptureResult.SENSOR_NEUTRAL_COLOR_POINT)
                val neutral = if (nc != null && nc.size >= 3) floatArrayOf(nc[0].toFloat(), nc[1].toFloat(), nc[2].toFloat()) else floatArrayOf(0.5f, 1f, 0.6f)
                val cal = NativeRaw.calib(fm1, fm2, cm1, cm2, cc1, cc2, ill1, ill2, neutral)
                note = "cct=${cal[12].toInt()}K fm=${cal[13].toInt()} iso=$isoPlan exp=${tPlan / 1_000_000}ms ${if (steady) "steady" else "handheld"}"
                val ci = intArrayOf(rawSize.width, rawSize.height, cfa, cropX, cropY, outW, outH)
                val cf = FloatArray(19)
                for (k in 0 until 4) cf[k] = black[k]
                cf[4] = white
                for (k in 0 until 3) cf[5 + k] = cal[k]
                for (k in 0 until 9) cf[8 + k] = cal[3 + k]
                cf[17] = noiseS; cf[18] = noiseO
                val h = NativeRaw.create(ci, cf)
                if (h != 0L) {
                    NativeRaw.enableSr(h, if (wantSr) 1 else 0)
                    val lsm = res.get(CaptureResult.STATISTICS_LENS_SHADING_CORRECTION_MAP)
                    if (lsm != null && lsm.columnCount >= 2 && lsm.rowCount >= 2) {
                        val mw = lsm.columnCount; val mh = lsm.rowCount
                        val g = FloatArray(4 * mw * mh)
                        for (c in 0 until 4) for (y in 0 until mh) for (x in 0 until mw) g[(c * mh + y) * mw + x] = lsm.getGainFactor(c, x, y)
                        NativeRaw.shading(h, g, mw, mh)
                    }
                }
                return h
            }

            fun tryProcess(ts: Long) {
                synchronized(lock) {
                    val img = images[ts] ?: return
                    val res = results[ts] ?: return
                    images.remove(ts); results.remove(ts)
                    try {
                        val plane = img.planes[0]
                        val k = processed
                        val expT = res.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: tPlan
                        val iso = res.get(CaptureResult.SENSOR_SENSITIVITY) ?: isoPlan
                        val product = expT.toDouble() * iso.toDouble()
                        if (handle == 0L) {
                            handle = createPipe(res)
                            refProduct = product
                            if (handle != 0L && wantDng) {
                                try {
                                    val f = File(cacheDir, "ref_${System.currentTimeMillis()}.dng")
                                    val d = DngCreator(chars, res)
                                    try {
                                        d.setOrientation(deviceExifOrientation)
                                        FileOutputStream(f).use { os -> d.writeImage(os, img) }
                                    } finally { d.close() }
                                    dngFile = f
                                } catch (e: Exception) { Log.w(TAG, "dng", e) }
                            }
                        }
                        if (handle != 0L) {
                            val gain = (refProduct / max(1.0, product)).toFloat()
                            val dyn = res.get(CaptureResult.SENSOR_DYNAMIC_BLACK_LEVEL)
                            // gyro-based motion blur estimate for this frame
                            var w = 1f
                            if (gyro.available) {
                                val s0 = startNs[ts] ?: SystemClock.elapsedRealtimeNanos()
                                val peak = gyro.peakBetween(s0, s0 + expT)
                                val fl = res.get(CaptureResult.LENS_FOCAL_LENGTH) ?: 0f
                                if (peak >= 0f && fl > 0f && physSize != null) {
                                    val focalPx = fl / physSize.width * rawW
                                    val blurPx = peak * (expT / 1e9f) * focalPx
                                    w = if (blurPx > 9f) 0.02f else 1f / (1f + (blurPx / 1.3f) * (blurPx / 1.3f))
                                }
                            }
                            val r = NativeRaw.addFrame(handle, plane.buffer, plane.rowStride, gain, w, dyn)
                            if (r != 0) { Log.w(TAG, "addFrame $k -> $r"); failures++ }
                            status("RAW • frame ${min(n, k + 1)}/$n")
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "process", e); failures++
                    } finally {
                        img.close()
                        startNs.remove(ts)
                        processed++
                        if (processed >= n) done.complete(Unit) else submitNext()
                    }
                    Unit
                }
            }

            tryProcessRef = { ts -> tryProcess(ts) }
            rdr.setOnImageAvailableListener({ r ->
                val img = try { r.acquireNextImage() } catch (e: Exception) { null }
                if (img != null) {
                    images[img.timestamp] = img
                    tryProcessRef(img.timestamp)
                }
            }, handler)

            status("RAW • burst ($n frames) — hold steady")
            submitNext(); submitNext()
            val ok = withTimeoutOrNull(4000L + n * (1500L + tPlan / 1_000_000L)) { done.await(); true } ?: false
            if (!ok) note += " timeout"
            val got = if (handle != 0L) NativeRaw.frames(handle) else 0
            if (got < 1) {
                if (handle != 0L) { NativeRaw.destroy(handle); handle = 0L }
                if (onShot == null) return@withContext null
                continue                                   // multi-shot: skip a failed shot, keep the session
            }
            val h = handle
            handle = 0L
            val rb = RawBurst(h, outW, outH, sensorOri, got, dngFile, note, baseW, baseH)
            if (onShot != null) onShot(rb, shotIdx) else lastBurst = rb
            }   // end of shot loop
            lastBurst
        } catch (e: Exception) {
            Log.e(TAG, "raw burst failed", e)
            if (handle != 0L) { NativeRaw.destroy(handle); handle = 0L }
            null
        } finally {
            gyro.stop()
            try { session?.close() } catch (e: Exception) { }
            try { device?.close() } catch (e: Exception) { }
            try { reader?.close() } catch (e: Exception) { }
            try { dummySurf?.release() } catch (e: Exception) { }
            try { dummyTex?.release() } catch (e: Exception) { }
            thread.quitSafely()
        }
    }

    fun exifFor(sensorOrientation: Int, deviceDeg: Int, front: Boolean = false): Int {
        val d = if (front) (sensorOrientation - deviceDeg + 360) % 360 else (sensorOrientation + deviceDeg + 360) % 360
        return when (d) {
            90 -> ExifInterface.ORIENTATION_ROTATE_90
            180 -> ExifInterface.ORIENTATION_ROTATE_180
            270 -> ExifInterface.ORIENTATION_ROTATE_270
            else -> ExifInterface.ORIENTATION_NORMAL
        }
    }
}

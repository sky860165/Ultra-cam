package com.ultracam.app

import java.nio.ByteBuffer

/** JNI bridge to the RAW part of libultracam_native.so (Bayer-domain burst merge + develop). */
object NativeRaw {
    val ok: Boolean get() = NativeEngine.ok

    // ci: w, h, cfa, cropX, cropY, outW, outH
    // cf: black[4], white, wb[3], ccm[9], noiseS, noiseO
    external fun create(ci: IntArray, cf: FloatArray): Long
    external fun destroy(h: Long)
    /** sub-pixel super-resolution (green plane); call right after create, before the first addFrame */
    external fun enableSr(h: Long, on: Int)
    external fun shading(h: Long, gains: FloatArray, mw: Int, mh: Int)
    external fun addFrame(h: Long, data: ByteBuffer, strideBytes: Int, expGain: Float, motionW: Float, black4: FloatArray?): Int
    external fun prepare(h: Long, params: FloatArray): Int
    external fun strip(h: Long, y0: Int, y1: Int, out: IntArray)
    external fun info(h: Long, what: Int): Float
    external fun frames(h: Long): Int
    /** returns [wb R,G,B, ccm x9, cct, usedForwardMatrix] */
    external fun calib(fm1: FloatArray?, fm2: FloatArray?, cm1: FloatArray?, cm2: FloatArray?, cc1: FloatArray?, cc2: FloatArray?,
                       ill1: Int, ill2: Int, neutral: FloatArray): FloatArray

    // parameter slots (must match raw.hpp)
    const val P_EV = 0
    const val P_SHADOWS = 1
    const val P_HIGHLIGHTS = 2
    const val P_CONTRAST = 3
    const val P_VIBRANCE = 4
    const val P_SATURATION = 5
    const val P_HUEBOOST = 6
    const val P_AWB = 7
    const val P_NR_LUMA = 8
    const val P_NR_CHROMA = 9
    const val P_SHARPEN = 10
    const val P_DECONV = 11
    const val P_CLARITY = 12
    const val P_DEHAZE = 13
    const val P_WARMTH = 14
    const val P_SR = 15
    const val P_COUNT = 16
}

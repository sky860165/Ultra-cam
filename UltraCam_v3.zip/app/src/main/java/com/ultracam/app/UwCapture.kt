package com.ultracam.app

import android.annotation.SuppressLint
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.Surface
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.abs

/**
 * Shoots JPEG frames from one specific camera id straight through Camera2.
 * Used for the ultra-wide sensor: many phones (MIUI) do not list it in cameraIdList, so CameraX cannot bind it,
 * but opening the hidden id directly sometimes still works. If the phone refuses, an empty list comes back.
 * CameraX must be unbound before calling this (most phones allow only one back camera open at a time).
 */
object UwCapture {
    private const val TAG = "UltraCamUW"

    private fun pickSize(sizes: Array<Size>): Size? {
        val s43 = sizes.filter { abs(it.width.toFloat() / it.height - 4f / 3f) < 0.03f }
        val pool = if (s43.isNotEmpty()) s43 else sizes.toList()
        return pool.maxByOrNull { it.width.toLong() * it.height }
    }

    private fun pickYuv(map: StreamConfigurationMap): Size? =
        map.getOutputSizes(ImageFormat.YUV_420_888)
            ?.filter { it.width <= 1280 && it.height <= 960 }
            ?.maxByOrNull { it.width.toLong() * it.height }

    @SuppressLint("MissingPermission")
    suspend fun capture(
        cm: CameraManager, id: String, n: Int, devDeg: Int, dir: File, status: (String) -> Unit
    ): List<File> {
        val files = ArrayList<File>()
        val ht = HandlerThread("uw-cam")
        ht.start()
        val h = Handler(ht.looper)
        val devHolder = arrayOfNulls<CameraDevice>(1)
        val sessHolder = arrayOfNulls<CameraCaptureSession>(1)
        var jpegReader: ImageReader? = null
        var yuvReader: ImageReader? = null
        try {
            dir.mkdirs()
            val cc = cm.getCameraCharacteristics(id)
            val map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return files
            val jsizes = map.getOutputSizes(ImageFormat.JPEG) ?: return files
            val size = pickSize(jsizes) ?: return files

            // ---- open the camera (this is the step a phone may refuse)
            val dev: CameraDevice = withTimeoutOrNull(5000L) {
                suspendCancellableCoroutine<CameraDevice?> { cont ->
                    try {
                        cm.openCamera(id, object : CameraDevice.StateCallback() {
                            override fun onOpened(d: CameraDevice) {
                                devHolder[0] = d
                                if (cont.isActive) cont.resume(d)
                            }
                            override fun onDisconnected(d: CameraDevice) {
                                d.close()
                                if (cont.isActive) cont.resume(null)
                            }
                            override fun onError(d: CameraDevice, error: Int) {
                                Log.w(TAG, "camera $id error $error")
                                d.close()
                                if (cont.isActive) cont.resume(null)
                            }
                        }, h)
                    } catch (e: Throwable) {
                        Log.w(TAG, "open $id refused", e)
                        if (cont.isActive) cont.resume(null)
                    }
                }
            } ?: return files

            // ---- streams: JPEG for the stills + a small YUV stream that lets AE / AF settle first
            val jr = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 3)
            jpegReader = jr
            val ysz = pickYuv(map)
            val yr = if (ysz != null) ImageReader.newInstance(ysz.width, ysz.height, ImageFormat.YUV_420_888, 3) else null
            yuvReader = yr
            if (yr != null) {
                yr.setOnImageAvailableListener(object : ImageReader.OnImageAvailableListener {
                    override fun onImageAvailable(r: ImageReader) {
                        try { r.acquireLatestImage()?.close() } catch (e: Throwable) { }
                    }
                }, h)
            }
            val chan = Channel<ByteArray>(Channel.UNLIMITED)
            jr.setOnImageAvailableListener(object : ImageReader.OnImageAvailableListener {
                override fun onImageAvailable(r: ImageReader) {
                    try {
                        val im = r.acquireNextImage() ?: return
                        val buf = im.planes[0].buffer
                        val bytes = ByteArray(buf.remaining())
                        buf.get(bytes)
                        im.close()
                        chan.trySend(bytes)
                    } catch (e: Throwable) {
                        Log.w(TAG, "jpeg read", e)
                    }
                }
            }, h)

            val surfaces = ArrayList<Surface>()
            surfaces.add(jr.surface)
            if (yr != null) surfaces.add(yr.surface)
            val sess: CameraCaptureSession = withTimeoutOrNull(5000L) {
                suspendCancellableCoroutine<CameraCaptureSession?> { cont ->
                    try {
                        dev.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                sessHolder[0] = s
                                if (cont.isActive) cont.resume(s)
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) {
                                if (cont.isActive) cont.resume(null)
                            }
                        }, h)
                    } catch (e: Throwable) {
                        Log.w(TAG, "session", e)
                        if (cont.isActive) cont.resume(null)
                    }
                }
            } ?: return files

            val afModes = cc.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            val hasCaf = afModes != null && afModes.contains(CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)

            // ---- warm-up (AE / AF converge)
            if (yr != null) {
                val pb = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                pb.addTarget(yr.surface)
                pb.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                pb.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                if (hasCaf) pb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                sess.setRepeatingRequest(pb.build(), null, h)
                delay(1100)
            }

            // ---- still request: best noise reduction / edge / distortion correction the sensor offers
            val sensorOri = cc.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val jpegOri = (sensorOri + devDeg + 360) % 360
            val rb = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            rb.addTarget(jr.surface)
            rb.set(CaptureRequest.JPEG_ORIENTATION, jpegOri)
            rb.set(CaptureRequest.JPEG_QUALITY, 96.toByte())
            rb.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
            rb.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            if (hasCaf) rb.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            val nr = cc.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
            if (nr != null && nr.contains(CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)) {
                rb.set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
            }
            val ed = cc.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
            if (ed != null && ed.contains(CaptureRequest.EDGE_MODE_HIGH_QUALITY)) {
                rb.set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
            }
            if (Build.VERSION.SDK_INT >= 28) {
                val dm = cc.get(CameraCharacteristics.DISTORTION_CORRECTION_AVAILABLE_MODES)
                if (dm != null && dm.contains(CaptureRequest.DISTORTION_CORRECTION_MODE_HIGH_QUALITY)) {
                    rb.set(CaptureRequest.DISTORTION_CORRECTION_MODE, CaptureRequest.DISTORTION_CORRECTION_MODE_HIGH_QUALITY)
                }
            }

            for (i in 0 until n) {
                status("Ultra-wide ${i + 1}/$n")
                try {
                    sess.capture(rb.build(), null, h)
                } catch (e: Throwable) {
                    Log.w(TAG, "capture", e)
                    break
                }
                val bytes = withTimeoutOrNull(8000L) { chan.receive() } ?: break
                val f = File(dir, "uw_${System.nanoTime()}_$i.jpg")
                f.writeBytes(bytes)
                files.add(f)
                delay(80)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            Log.w(TAG, "uw capture failed", t)
        } finally {
            try { sessHolder[0]?.close() } catch (e: Throwable) { }
            try { devHolder[0]?.close() } catch (e: Throwable) { }
            try { jpegReader?.close() } catch (e: Throwable) { }
            try { yuvReader?.close() } catch (e: Throwable) { }
            try { ht.quitSafely() } catch (e: Throwable) { }
        }
        return files
    }
}

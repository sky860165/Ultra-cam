package com.ultracam.app

import android.graphics.Bitmap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sin

/**
 * Lanczos-3 upscaler (separable, edge clamped). Used for RAW zoom: the centre window is developed at native resolution and then
 * scaled back to the full output size. Much crisper than the bilinear Bitmap.createScaledBitmap, no ringing visible at 1.1x - 5x.
 */
object Upscale {
    private class Taps(val start: IntArray, val w: Array<FloatArray>)

    private fun lz(x: Float): Float {
        val ax = abs(x)
        if (ax >= 3f) return 0f
        if (ax < 1e-5f) return 1f
        val p = (PI * ax).toFloat()
        return 3f * sin(p) * sin(p / 3f) / (p * p)
    }

    /** 6 taps per output sample (upscaling: kernel is not widened) */
    private fun taps(srcN: Int, dstN: Int): Taps {
        val scale = srcN.toFloat() / dstN
        val start = IntArray(dstN)
        val ws = Array(dstN) { FloatArray(6) }
        for (i in 0 until dstN) {
            val c = (i + 0.5f) * scale - 0.5f
            val s = floor(c).toInt() - 2
            start[i] = s
            var sum = 0f
            for (k in 0 until 6) { val v = lz(c - (s + k)); ws[i][k] = v; sum += v }
            if (sum > 1e-6f) for (k in 0 until 6) ws[i][k] /= sum
        }
        return Taps(start, ws)
    }

    private fun c8(v: Float): Int = if (v <= 0f) 0 else if (v >= 255f) 255 else (v + 0.5f).toInt()

    fun resize(src: Bitmap, dw: Int, dh: Int): Bitmap {
        val sw = src.width
        val sh = src.height
        if (dw <= sw && dh <= sh) return Bitmap.createScaledBitmap(src, dw, dh, true)
        val tx = taps(sw, dw)
        val ty = taps(sh, dh)
        val tmp = IntArray(dw * sh)
        // pass 1: horizontal
        Par.rows(0, sh) { ya, yb ->
            val line = IntArray(sw)
            for (y in ya until yb) {
                synchronized(src) { src.getPixels(line, 0, sw, 0, y, sw, 1) }
                val o = y * dw
                for (x in 0 until dw) {
                    val s = tx.start[x]
                    val w = tx.w[x]
                    var r = 0f; var g = 0f; var b = 0f
                    for (k in 0 until 6) {
                        var xi = s + k
                        if (xi < 0) xi = 0 else if (xi >= sw) xi = sw - 1
                        val p = line[xi]
                        val wk = w[k]
                        r += wk * ((p shr 16) and 255); g += wk * ((p shr 8) and 255); b += wk * (p and 255)
                    }
                    tmp[o + x] = (0xFF shl 24) or (c8(r) shl 16) or (c8(g) shl 8) or c8(b)
                }
            }
        }
        // pass 2: vertical
        val out = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
        Par.rows(0, dh) { ya, yb ->
            val ar = FloatArray(dw); val ag = FloatArray(dw); val ab = FloatArray(dw)
            val buf = IntArray(dw)
            for (y in ya until yb) {
                java.util.Arrays.fill(ar, 0f); java.util.Arrays.fill(ag, 0f); java.util.Arrays.fill(ab, 0f)
                val s = ty.start[y]
                val w = ty.w[y]
                for (k in 0 until 6) {
                    var yi = s + k
                    if (yi < 0) yi = 0 else if (yi >= sh) yi = sh - 1
                    val wk = w[k]
                    val base = yi * dw
                    for (x in 0 until dw) {
                        val p = tmp[base + x]
                        ar[x] += wk * ((p shr 16) and 255); ag[x] += wk * ((p shr 8) and 255); ab[x] += wk * (p and 255)
                    }
                }
                for (x in 0 until dw) buf[x] = (0xFF shl 24) or (c8(ar[x]) shl 16) or (c8(ag[x]) shl 8) or c8(ab[x])
                synchronized(out) { out.setPixels(buf, 0, dw, 0, y, dw, 1) }
            }
        }
        return out
    }
}

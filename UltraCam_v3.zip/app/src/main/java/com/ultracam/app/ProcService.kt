package com.ultracam.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Keeps the process alive while photos are processed and shows progress in the notification bar only. */
class ProcService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel(this)
        try {
            startForeground(NOTIF_ID, build(this, "Processing…", -1))
        } catch (e: Throwable) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        const val CH = "ultracam_proc"
        const val NOTIF_ID = 4711
        const val DONE_ID = 4712

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(CH) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(CH, "Photo processing", NotificationManager.IMPORTANCE_LOW)
                    )
                }
            }
        }

        fun build(ctx: Context, text: String, pct: Int): Notification {
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("UltraCam")
                .setContentText(text)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setContentIntent(open)
            if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
            return b.build()
        }

        fun update(ctx: Context, text: String, pct: Int) {
            try {
                ensureChannel(ctx)
                NotificationManagerCompat.from(ctx).notify(NOTIF_ID, build(ctx, text, pct))
            } catch (e: Throwable) { }
        }

        fun done(ctx: Context, text: String) {
            try {
                ensureChannel(ctx)
                val n = NotificationCompat.Builder(ctx, CH)
                    .setSmallIcon(android.R.drawable.ic_menu_camera)
                    .setContentTitle("UltraCam")
                    .setContentText(text)
                    .setAutoCancel(true)
                    .setTimeoutAfter(4000)
                    .build()
                NotificationManagerCompat.from(ctx).notify(DONE_ID, n)
            } catch (e: Throwable) { }
        }
    }
}

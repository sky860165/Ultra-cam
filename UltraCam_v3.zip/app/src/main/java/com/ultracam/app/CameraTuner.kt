package com.ultracam.app

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.util.Log
import android.util.Range
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera

/** Low level Camera2 controls on top of CameraX (manual exposure, focus, NR, stabilization...). */
@ExperimentalCamera2Interop
class CameraTuner(private val camera: Camera) {

    private val info = Camera2CameraInfo.from(camera.cameraInfo)
    private val opts = LinkedHashMap<CaptureRequest.Key<*>, Any>()

    private fun <T> chr(k: CameraCharacteristics.Key<T>): T? =
        try { info.getCameraCharacteristic(k) } catch (e: Exception) { null }

    val isoRange: Range<Int>? = chr(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
    val expRange: Range<Long>? = chr(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    val minFocus: Float = chr(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    private val caps: IntArray? = chr(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
    private val fpsRanges: Array<Range<Int>>? = chr(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)

    /** MANUAL_SENSOR capability = 1 */
    val hasManual: Boolean = caps?.contains(1) == true && isoRange != null && expRange != null

    @Suppress("UNCHECKED_CAST")
    private fun <T> put(key: CaptureRequest.Key<T>, v: T) {
        opts[key] = v as Any
    }

    private fun drop(key: CaptureRequest.Key<*>) {
        opts.remove(key)
    }

    fun commit() {
        try {
            val b = CaptureRequestOptions.Builder()
            for ((k, v) in opts) {
                @Suppress("UNCHECKED_CAST")
                val key = k as CaptureRequest.Key<Any>
                b.setCaptureRequestOption(key, v)
            }
            Camera2CameraControl.from(camera.cameraControl).setCaptureRequestOptions(b.build())
        } catch (e: Exception) {
            Log.w("CameraTuner", "commit failed", e)
        }
    }

    private fun fpsUpper30LowestLower(): Range<Int>? =
        fpsRanges?.filter { it.upper == 30 && it.lower >= 10 }?.minByOrNull { it.lower }

    /** Baseline quality settings for the chosen use. */
    fun applyDefaults(stack: Boolean, video: Boolean, superSteady: Boolean, lowLightVideo: Boolean) {
        opts.clear()

        val nr = chr(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES)
        val wantNr = if (stack) CaptureRequest.NOISE_REDUCTION_MODE_MINIMAL
        else CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY
        if (!video && nr?.contains(wantNr) == true) put(CaptureRequest.NOISE_REDUCTION_MODE, wantNr)

        val edge = chr(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES)
        val wantEdge = if (stack) CaptureRequest.EDGE_MODE_FAST else CaptureRequest.EDGE_MODE_HIGH_QUALITY
        if (!video && edge?.contains(wantEdge) == true) put(CaptureRequest.EDGE_MODE, wantEdge)

        val ab = chr(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES)
        if (ab?.contains(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY) == true) {
            put(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE,
                CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)
        }

        val ois = chr(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
        if (ois?.contains(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON) == true) {
            put(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
        }

        if (video) {
            val vs = chr(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)
            var m = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            if (superSteady && Build.VERSION.SDK_INT >= 33 && vs?.contains(2) == true) {
                m = 2 // PREVIEW_STABILIZATION
            } else if (vs?.contains(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) {
                m = CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON
            }
            if (m != CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_OFF) {
                put(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, m)
            }
            if (lowLightVideo) {
                fpsUpper30LowestLower()?.let { put(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
            }
        }
        commit()
    }

    // ----- manual exposure -----
    fun setManualExposure(iso: Int, expNs: Long) {
        put(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        put(CaptureRequest.SENSOR_SENSITIVITY, iso)
        put(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs)
        put(CaptureRequest.SENSOR_FRAME_DURATION, expNs + 10_000_000L)
    }

    fun setAutoExposure() {
        drop(CaptureRequest.CONTROL_AE_MODE)
        drop(CaptureRequest.SENSOR_SENSITIVITY)
        drop(CaptureRequest.SENSOR_EXPOSURE_TIME)
        drop(CaptureRequest.SENSOR_FRAME_DURATION)
    }

    // ----- manual focus (diopters: 0 = infinity, minFocus = closest) -----
    fun setManualFocus(diopter: Float) {
        put(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
        put(CaptureRequest.LENS_FOCUS_DISTANCE, diopter)
    }

    fun setAutoFocus() {
        drop(CaptureRequest.CONTROL_AF_MODE)
        drop(CaptureRequest.LENS_FOCUS_DISTANCE)
    }

    fun setAwb(mode: Int?) {
        if (mode == null) drop(CaptureRequest.CONTROL_AWB_MODE)
        else put(CaptureRequest.CONTROL_AWB_MODE, mode)
    }

    fun lockAeAwb(lock: Boolean) {
        if (lock) {
            put(CaptureRequest.CONTROL_AE_LOCK, true)
            put(CaptureRequest.CONTROL_AWB_LOCK, true)
        } else {
            drop(CaptureRequest.CONTROL_AE_LOCK)
            drop(CaptureRequest.CONTROL_AWB_LOCK)
        }
        commit()
    }
}

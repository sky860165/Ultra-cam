// UltraCam native engine.
// Everything hot (resample, frame merge, local alignment, denoise, tone-map, sharpen, look) lives here.
// Loops are written branch-light on flat float planes so clang auto-vectorises them to NEON (-O3 -ffast-math).
#include "engine.hpp"

#include <algorithm>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <memory>
#include <vector>

#include "pool.hpp"

#define RESTRICT __restrict__
#if defined(__clang__)
#define UC_VEC _Pragma("clang loop vectorize(enable) interleave(enable)")
#else
#define UC_VEC
#endif

namespace uc {

float g_sharpLimInv = 1.f / 34.f;   // soft limit on sharpening overshoot (test hook: 0 disables)
float g_chromaK = 0.25f;            // weight of the chroma difference in merge weights (test hook: 0 = luma only)

namespace {

constexpr int BS = 32;        // local-alignment block size
constexpr int SRCH = 3;       // local-alignment search radius

inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ---------------------------------------------------------------- parallel helpers
template <class F>
inline void prows(int from, int to, int width, F&& f) {
    int minChunk = std::max(1, 32768 / std::max(1, width));
    Pool::get().run(from, to, minChunk, std::function<void(int, int)>(std::forward<F>(f)));
}

// ---------------------------------------------------------------- fast math (vectorisable, ~1e-6 rel. error)
inline float fast_log2(float x) {
    uint32_t b;
    std::memcpy(&b, &x, 4);
    int e = (int)((b >> 23) & 255) - 127;
    b = (b & 0x007FFFFFu) | 0x3F800000u;
    float m;
    std::memcpy(&m, &b, 4);
    float adj = m > 1.41421356f ? 1.f : 0.f;
    m = m * (1.f - 0.5f * adj);
    float t = (m - 1.f) / (m + 1.f);
    float t2 = t * t;
    float p = t * (2.88539008f + t2 * (0.96179669f + t2 * (0.57707801f + t2 * 0.41219858f)));
    return (float)e + adj + p;
}

inline float fast_exp2(float x) {
    x = x < -126.f ? -126.f : (x > 126.f ? 126.f : x);
    float t = x + 0.5f;
    int xi = (int)t;
    xi -= (t < (float)xi) ? 1 : 0;
    float f = x - (float)xi;  // [-0.5, 0.5]
    float z = f * 0.69314718f;
    float p = 1.f + z * (1.f + z * (0.5f + z * (0.16666667f + z * (0.041666668f + z * (0.008333334f + z * 0.0013888889f)))));
    uint32_t b = (uint32_t)(xi + 127) << 23;
    float s;
    std::memcpy(&s, &b, 4);
    return p * s;
}

inline void catmull(float t, float* w) {
    float t2 = t * t, t3 = t2 * t;
    w[0] = -0.5f * t3 + t2 - 0.5f * t;
    w[1] = 1.5f * t3 - 2.5f * t2 + 1.f;
    w[2] = -1.5f * t3 + 2.f * t2 + 0.5f * t;
    w[3] = 0.5f * t3 - 0.5f * t2;
}

inline float shoulder(float v) {
    float t = (v - 232.f) * (1.f / 23.f);
    t = t < 0.f ? 0.f : t;
    float sh = 232.f + 23.f * (t / (1.f + t));
    float r = v < 232.f ? v : sh;
    return v <= 0.f ? 0.f : r;
}

float* falloc(size_t n) {
    void* p = nullptr;
    if (posix_memalign(&p, 64, n * sizeof(float) + 64) != 0) return nullptr;
    std::memset(p, 0, n * sizeof(float));
    return (float*)p;
}
template <class T>
T* talloc(size_t n) {
    void* p = nullptr;
    if (posix_memalign(&p, 64, n * sizeof(T) + 64) != 0) return nullptr;
    std::memset(p, 0, n * sizeof(T));
    return (T*)p;
}

// ---------------------------------------------------------------- box blur (replicate edges), cache-friendly
void boxBlur(const float* src, float* dst, float* tmp, int w, int h, int r) {
    const float inv = 1.f / (float)(2 * r + 1);
    prows(0, h, w, [&](int a, int b) {
        for (int y = a; y < b; y++) {
            const float* s = src + (size_t)y * w;
            float* t = tmp + (size_t)y * w;
            float acc = 0.f;
            for (int k = -r; k <= r; k++) acc += s[clampi(k, 0, w - 1)];
            for (int x = 0; x < w; x++) {
                t[x] = acc * inv;
                int ad = std::min(w - 1, x + r + 1);
                int sb = std::max(0, x - r);
                acc += s[ad] - s[sb];
            }
        }
    });
    constexpr int CW = 128;
    const int nc = (w + CW - 1) / CW;
    Pool::get().run(0, nc, 1, [&](int ca, int cb) {
        float acc[CW];
        for (int c = ca; c < cb; c++) {
            const int xa = c * CW;
            const int len = std::min(w, xa + CW) - xa;
            for (int i = 0; i < len; i++) acc[i] = 0.f;
            for (int k = -r; k <= r; k++) {
                const float* tr = tmp + (size_t)clampi(k, 0, h - 1) * w + xa;
                for (int i = 0; i < len; i++) acc[i] += tr[i];
            }
            for (int y = 0; y < h; y++) {
                float* d = dst + (size_t)y * w + xa;
                for (int i = 0; i < len; i++) d[i] = acc[i] * inv;
                const float* ta = tmp + (size_t)std::min(h - 1, y + r + 1) * w + xa;
                const float* tb = tmp + (size_t)std::max(0, y - r) * w + xa;
                for (int i = 0; i < len; i++) acc[i] += ta[i] - tb[i];
            }
        }
    });
}

void blurTwice(const float* src, float* dst, float* tmp, int w, int h, int r) {
    boxBlur(src, dst, tmp, w, h, r);
    boxBlur(dst, dst, tmp, w, h, r);
}

void luma8(const uint32_t* src, uint8_t* dst, int w, int nr) {
    prows(0, nr, w, [&](int a, int b) {
        const size_t i0 = (size_t)a * w, i1 = (size_t)b * w;
        for (size_t i = i0; i < i1; i++) {
            uint32_t p = src[i];
            dst[i] = (uint8_t)((77u * ((p >> 16) & 255u) + 150u * ((p >> 8) & 255u) + 29u * (p & 255u)) >> 8);
        }
    });
}

inline unsigned sad8(const uint8_t* RESTRICT a, const uint8_t* RESTRICT b, int len) {
    unsigned s = 0;
    for (int i = 0; i < len; i++) s += (unsigned)std::abs((int)a[i] - (int)b[i]);
    return s;
}

}  // namespace

struct Look {
    float sat, vib, vign, grain, mono, shR, shG, shB, hiR, hiG, hiB, wr, wg, wb, k, ev, fade, lo, invr;
};

// ====================================================================== pipeline state
struct Pipe {
    int w, h, wo, ho, n, ref, capRows, bw, bh, sharpR, midR, nSlots;
    bool isHdr, isTrails, isDoc, merge, local;
    float s, dn, sharpAmt, coreT, midAmt, detailB, lift, wbR, wbB, gain;
    float noiseSigma = -1.f;
    size_t cap = 0;
    std::vector<float> base, sigma, fw;
    Look lk{};
    std::vector<int> bx0, by0;
    std::vector<float> bxf, byf;
    float toneLut[1024];
    float *rP = nullptr, *gP = nullptr, *bP = nullptr, *yP = nullptr, *cbP = nullptr, *crP = nullptr, *t1 = nullptr, *wsP = nullptr;
    std::vector<uint32_t*> slots;
    std::vector<float*> hdrW;
    uint8_t *lumA = nullptr, *lumB = nullptr;
    int bxCount = 0;
    std::vector<int8_t> offX, offY;

    ~Pipe() {
        for (float* p : {rP, gP, bP, yP, cbP, crP, t1, wsP}) free(p);
        for (auto* p : slots) free(p);
        for (auto* p : hdrW) free(p);
        free(lumA);
        free(lumB);
    }

    void sample(int slot, const uint32_t* src, int srcRows, int yTop, float dx, float dy, int r0, int nr);
    void mergeAll(int kind, int nr, int arg);
    void post(int r0, int nr);
    void finish(int r0, int y0, int y1, uint32_t* out);
    void blockOffsets(int nr);
    void mergeStack(int nr);
    void mergeHdr(int nr);
    void bilateralWide(const float* srcA, const float* guide, float* dst, int nr, int st, float sigR);
    float estimateNoise(const float* yv, int nr);
};

namespace {

inline void unpackPlanes(const uint32_t* RESTRICT s, float* RESTRICT r, float* RESTRICT g, float* RESTRICT b, size_t n) {
    for (size_t i = 0; i < n; i++) {
        uint32_t p = s[i];
        r[i] = (float)((p >> 16) & 255u);
        g[i] = (float)((p >> 8) & 255u);
        b[i] = (float)(p & 255u);
    }
}

// One run of pixels of the "current" frame merged into the accumulators.
// Weight = Gaussian of the colour difference to the reference: luma difference plus a chroma term, so a moving
// object that happens to have the same brightness as the background (but a different colour) is still rejected.
inline void accRun(int len, const uint32_t* RESTRICT pc, const uint32_t* RESTRICT pr, float* RESTRICT R, float* RESTRICT G,
                   float* RESTRICT B, float* RESTRICT W, float inv2s2, float fwt, float kappa) {
    UC_VEC
for (int i = 0; i < len; i++) {
        const uint32_t p = pc[i], q = pr[i];
        const float dr = (float)((int)((p >> 16) & 255u) - (int)((q >> 16) & 255u));
        const float dg = (float)((int)((p >> 8) & 255u) - (int)((q >> 8) & 255u));
        const float db = (float)((int)(p & 255u) - (int)(q & 255u));
        const float dy = 0.299f * dr + 0.587f * dg + 0.114f * db;
        const float cr = dr - dy, cb = db - dy;
        const float d2 = dy * dy + kappa * (cr * cr + cb * cb);
        const float wt = fast_exp2(-1.44269504f * d2 * inv2s2) * fwt;
        R[i] += wt * (float)((p >> 16) & 255u);
        G[i] += wt * (float)((p >> 8) & 255u);
        B[i] += wt * (float)(p & 255u);
        W[i] += wt;
    }
}

}  // namespace

// ====================================================================== resampling
void Pipe::sample(int slot, const uint32_t* src, int srcRows, int yTop, float dx, float dy, int r0, int nr) {
    uint32_t* dst = slots[slot];
    if (s == 1.0f) {
        const int idx = (int)std::floor(dx + 0.5f);
        prows(0, nr, w, [&](int a, int b) {
            for (int row = a; row < b; row++) {
                const uint32_t* sr = src + (size_t)std::min(row, srcRows - 1) * w;
                uint32_t* d = dst + (size_t)row * wo;
                const int xs = std::max(0, -idx);               // first x whose source is in range
                const int xe = std::min(wo, w - idx);           // one past last
                if (xe > xs) {
                    for (int x = 0; x < xs && x < wo; x++) d[x] = sr[0];
                    std::memcpy(d + xs, sr + xs + idx, (size_t)(xe - xs) * 4);
                    for (int x = xe; x < wo; x++) d[x] = sr[w - 1];
                } else {
                    for (int x = 0; x < wo; x++) d[x] = sr[clampi(x + idx, 0, w - 1)];
                }
            }
        });
        return;
    }
    // Catmull-Rom bicubic (sharper than bilinear when the sub-pixel shifts of several frames are merged)
    const float invS = 1.f / s;
    std::vector<int> xi((size_t)wo * 4);
    std::vector<float> xw((size_t)wo * 4);
    for (int x = 0; x < wo; x++) {
        float sx = x * invS + dx;
        int x0 = (int)std::floor(sx);
        catmull(sx - (float)x0, &xw[(size_t)x * 4]);
        for (int j = 0; j < 4; j++) xi[(size_t)x * 4 + j] = clampi(x0 - 1 + j, 0, w - 1);
    }
    prows(0, nr, w, [&](int a, int b) {
        std::vector<float> ring((size_t)4 * 3 * wo);
        int have[4] = {-1, -1, -1, -1};
        auto getRow = [&](int li) -> const float* {
            const int sl = li & 3;
            float* rr = ring.data() + (size_t)sl * 3 * wo;
            if (have[sl] != li) {
                const uint32_t* sr = src + (size_t)li * w;
                float* R = rr;
                float* G = rr + wo;
                float* B = rr + 2 * (size_t)wo;
                for (int x = 0; x < wo; x++) {
                    const int* ix = &xi[(size_t)x * 4];
                    const float* wx = &xw[(size_t)x * 4];
                    uint32_t p0 = sr[ix[0]], p1 = sr[ix[1]], p2 = sr[ix[2]], p3 = sr[ix[3]];
                    R[x] = wx[0] * (float)((p0 >> 16) & 255u) + wx[1] * (float)((p1 >> 16) & 255u) +
                           wx[2] * (float)((p2 >> 16) & 255u) + wx[3] * (float)((p3 >> 16) & 255u);
                    G[x] = wx[0] * (float)((p0 >> 8) & 255u) + wx[1] * (float)((p1 >> 8) & 255u) +
                           wx[2] * (float)((p2 >> 8) & 255u) + wx[3] * (float)((p3 >> 8) & 255u);
                    B[x] = wx[0] * (float)(p0 & 255u) + wx[1] * (float)(p1 & 255u) +
                           wx[2] * (float)(p2 & 255u) + wx[3] * (float)(p3 & 255u);
                }
                have[sl] = li;
            }
            return rr;
        };
        for (int row = a; row < b; row++) {
            float sy = (float)(r0 + row) * invS + dy;
            int yy = (int)std::floor(sy);
            float wy[4];
            catmull(sy - (float)yy, wy);
            const float* rows[4];
            for (int j = 0; j < 4; j++) rows[j] = getRow(clampi(yy - 1 + j - yTop, 0, srcRows - 1));
            const float *r0p = rows[0], *r1p = rows[1], *r2p = rows[2], *r3p = rows[3];
            uint32_t* d = dst + (size_t)row * wo;
            const float w0 = wy[0], w1 = wy[1], w2 = wy[2], w3 = wy[3];
            const size_t o1 = wo, o2 = 2 * (size_t)wo;
            for (int x = 0; x < wo; x++) {
                float r = w0 * r0p[x] + w1 * r1p[x] + w2 * r2p[x] + w3 * r3p[x];
                float g = w0 * r0p[o1 + x] + w1 * r1p[o1 + x] + w2 * r2p[o1 + x] + w3 * r3p[o1 + x];
                float bl = w0 * r0p[o2 + x] + w1 * r1p[o2 + x] + w2 * r2p[o2 + x] + w3 * r3p[o2 + x];
                r = clampf(r, 0.f, 255.f);
                g = clampf(g, 0.f, 255.f);
                bl = clampf(bl, 0.f, 255.f);
                d[x] = 0xFF000000u | ((uint32_t)(r + 0.5f) << 16) | ((uint32_t)(g + 0.5f) << 8) | (uint32_t)(bl + 0.5f);
            }
        }
    });
}

// ====================================================================== merging
void Pipe::blockOffsets(int nr) {
    const int byCount = (nr + BS - 1) / BS;
    prows(0, byCount, BS * wo, [&](int a, int b) {
        for (int by = a; by < b; by++) {
            const int y0 = by * BS, y1 = std::min(nr, y0 + BS);
            for (int bx = 0; bx < bxCount; bx++) {
                const int x0 = bx * BS, x1 = std::min(wo, x0 + BS);
                const int len = x1 - x0;
                const int rowsS = (y1 - y0 + 1) / 2;
                const unsigned pen = (unsigned)std::max(1, len * rowsS / 2);
                unsigned best = UINT_MAX;
                int bo = 0, bp = 0;
                for (int pass = 0; pass < 2; pass++) {
                    for (int oy = -SRCH; oy <= SRCH; oy++) {
                        for (int ox = -SRCH; ox <= SRCH; ox++) {
                            const bool center = (ox == 0 && oy == 0);
                            if ((pass == 0) != center) continue;   // evaluate the zero offset first (seeds early-exit)
                            unsigned sad = (unsigned)(std::abs(ox) + std::abs(oy)) * pen;
                            const bool xin = x0 + ox >= 0 && x1 + ox <= wo;
                            for (int y = y0; y < y1 && sad < best; y += 2) {
                                const int yc = clampi(y + oy, 0, nr - 1);
                                const uint8_t* ra = lumA + (size_t)y * wo + x0;
                                if (xin) {
                                    sad += sad8(ra, lumB + (size_t)yc * wo + x0 + ox, len);
                                } else {
                                    const uint8_t* cr = lumB + (size_t)yc * wo;
                                    for (int i = 0; i < len; i++) sad += (unsigned)std::abs((int)ra[i] - (int)cr[clampi(x0 + i + ox, 0, wo - 1)]);
                                }
                            }
                            if (sad < best) { best = sad; bo = ox; bp = oy; }
                        }
                    }
                }
                offX[(size_t)by * bxCount + bx] = (int8_t)bo;
                offY[(size_t)by * bxCount + bx] = (int8_t)bp;
            }
        }
    });
}

void Pipe::mergeStack(int nr) {
    const size_t npx = (size_t)nr * wo;
    const uint32_t* refBuf = slots[ref];
    prows(0, nr, wo, [&](int a, int b) {
        const size_t i0 = (size_t)a * wo, cnt = (size_t)(b - a) * wo;
        unpackPlanes(refBuf + i0, rP + i0, gP + i0, bP + i0, cnt);
        for (size_t i = 0; i < cnt; i++) wsP[i0 + i] = 1.f;
    });
    luma8(refBuf, lumA, wo, nr);
    for (int f = 0; f < n; f++) {
        if (f == ref) continue;
        const uint32_t* cur = slots[f];
        const float fwt = fw[f];
        const float sg = sigma[f];
        // chroma noise adds variance to the difference; widen sigma so static (noise-only) areas keep the same weights
        const float kappa = g_chromaK;
        const float sgE = sg * std::sqrt(1.f + 4.63f * kappa);
        const float inv2s2 = 1.f / (2.f * sgE * sgE);
        luma8(cur, lumB, wo, nr);
        if (local) blockOffsets(nr);
        prows(0, nr, wo, [&](int a, int b) {
            for (int row = a; row < b; row++) {
                const size_t ro = (size_t)row * wo;
                if (!local) {
                    accRun(wo, cur + ro, refBuf + ro, rP + ro, gP + ro, bP + ro, wsP + ro, inv2s2, fwt, kappa);
                    continue;
                }
                const size_t byo = (size_t)(row / BS) * bxCount;
                for (int bx = 0; bx < bxCount; bx++) {
                    const int x0 = bx * BS, x1 = std::min(wo, x0 + BS);
                    const int ox = offX[byo + bx], oy = offY[byo + bx];
                    const int yy = clampi(row + oy, 0, nr - 1);
                    const size_t co = (size_t)yy * wo;
                    if (x0 + ox >= 0 && x1 + ox <= wo) {
                        const size_t c0 = co + x0 + ox;
                        accRun(x1 - x0, cur + c0, refBuf + ro + x0, rP + ro + x0, gP + ro + x0,
                               bP + ro + x0, wsP + ro + x0, inv2s2, fwt, kappa);
                    } else {
                        for (int x = x0; x < x1; x++) {
                            const size_t c0 = co + clampi(x + ox, 0, wo - 1);
                            accRun(1, cur + c0, refBuf + ro + x, rP + ro + x, gP + ro + x,
                                   bP + ro + x, wsP + ro + x, inv2s2, fwt, kappa);
                        }
                    }
                }
            }
        });
    }
    (void)npx;
    prows(0, nr, wo, [&](int a, int b) {
        for (size_t i = (size_t)a * wo; i < (size_t)b * wo; i++) {
            float inv = 1.f / wsP[i];
            rP[i] *= inv; gP[i] *= inv; bP[i] *= inv;
        }
    });
}

void Pipe::mergeHdr(int nr) {
    for (int f = 0; f < n; f++) {
        const uint32_t* bf = slots[f];
        float* wf = hdrW[f];
        prows(0, nr, wo, [&](int a, int b) {
            for (size_t i = (size_t)a * wo; i < (size_t)b * wo; i++) {
                uint32_t px = bf[i];
                float r = (float)((px >> 16) & 255u), g = (float)((px >> 8) & 255u), bl = (float)(px & 255u);
                float lum = (0.299f * r + 0.587f * g + 0.114f * bl) * (1.f / 255.f);
                float d = lum - 0.5f;
                float we = fast_exp2(-d * d * 12.5f * 1.44269504f);
                float sat = (std::max(r, std::max(g, bl)) - std::min(r, std::min(g, bl))) * (1.f / 255.f);
                wf[i] = we * (0.15f + sat) + 1e-4f;
            }
        });
        boxBlur(wf, wf, t1, wo, nr, 5);
    }
    prows(0, nr, wo, [&](int a, int b) {
        for (size_t i = (size_t)a * wo; i < (size_t)b * wo; i++) {
            float sr = 0.f, sg = 0.f, sb = 0.f, sw = 0.f;
            for (int f = 0; f < n; f++) {
                uint32_t px = slots[f][i];
                float wt = hdrW[f][i];
                sr += wt * (float)((px >> 16) & 255u);
                sg += wt * (float)((px >> 8) & 255u);
                sb += wt * (float)(px & 255u);
                sw += wt;
            }
            float inv = 1.f / sw;
            rP[i] = sr * inv; gP[i] = sg * inv; bP[i] = sb * inv;
        }
    });
}

void Pipe::mergeAll(int kind, int nr, int arg) {
    if (kind == 0) {
        const uint32_t* s0 = slots[clampi(arg, 0, nSlots - 1)];
        prows(0, nr, wo, [&](int a, int b) {
            size_t i0 = (size_t)a * wo;
            unpackPlanes(s0 + i0, rP + i0, gP + i0, bP + i0, (size_t)(b - a) * wo);
        });
    } else if (kind == 3) {
        const uint32_t* s0 = slots[0];
        const bool first = arg != 0;
        prows(0, nr, wo, [&](int a, int b) {
            for (size_t i = (size_t)a * wo; i < (size_t)b * wo; i++) {
                uint32_t p = s0[i];
                float r = (float)((p >> 16) & 255u), g = (float)((p >> 8) & 255u), bl = (float)(p & 255u);
                if (first) { rP[i] = r; gP[i] = g; bP[i] = bl; }
                else { rP[i] = std::max(rP[i], r); gP[i] = std::max(gP[i], g); bP[i] = std::max(bP[i], bl); }
            }
        });
    } else if (kind == 1) {
        mergeStack(nr);
    } else if (kind == 2) {
        mergeHdr(nr);
    }
}

// ====================================================================== post processing
float Pipe::estimateNoise(const float* yv, int nr) {
    const int bsz = 16;
    const int bxn = wo / bsz, byn = nr / bsz;
    if (bxn < 2 || byn < 2) return 4.f;
    const int stepB = std::max(1, (bxn * byn) / 600);
    std::vector<float> vals((size_t)(bxn * byn / stepB + 2));
    int cntV = 0, idx = 0;
    for (int by = 0; by < byn; by++) {
        for (int bx = 0; bx < bxn; bx++) {
            idx++;
            if (idx % stepB != 0) continue;
            const int x0 = bx * bsz, y0 = by * bsz;
            float acc = 0.f;
            int cnt = 0;
            for (int y = y0 + 1; y < y0 + bsz - 1; y++) {
                const size_t o = (size_t)y * wo;
                for (int x = x0 + 1; x < x0 + bsz - 1; x++) {
                    const size_t i = o + x;
                    float v = 4.f * yv[i] - 2.f * (yv[i - 1] + yv[i + 1] + yv[i - wo] + yv[i + wo]) +
                              (yv[i - wo - 1] + yv[i - wo + 1] + yv[i + wo - 1] + yv[i + wo + 1]);
                    acc += std::fabs(v);
                    cnt++;
                }
            }
            if (cnt > 0 && cntV < (int)vals.size()) { vals[cntV++] = acc / (float)cnt * 0.20888f; }
        }
    }
    if (cntV == 0) return 4.f;
    int k = clampi((int)(cntV * 0.2f), 0, cntV - 1);
    std::nth_element(vals.begin(), vals.begin() + k, vals.begin() + cntV);
    return clampf(vals[k] * 1.15f, 1.2f, 30.f);
}

// Edge-preserving 12-tap denoise; range weights come from a pre-smoothed guide and grow with darkness.
void Pipe::bilateralWide(const float* srcA, const float* guide, float* dst, int nr, int st, float sigR) {
    const int w = wo;
    const float invBase = 1.f / (sigR * sigR);
    const int m = 2 * st;
    prows(0, nr, w, [&](int a, int b) {
        for (int y = a; y < b; y++) {
            const size_t o = (size_t)y * w;
            if (y < m || y >= nr - m || w <= 2 * m) {
                std::memcpy(dst + o, srcA + o, (size_t)w * 4);
                continue;
            }
            for (int x = 0; x < m; x++) dst[o + x] = srcA[o + x];
            for (int x = w - m; x < w; x++) dst[o + x] = srcA[o + x];
            const float* RESTRICT g0 = guide + o;
            const float* RESTRICT s0 = srcA + o;
            float* RESTRICT dd = dst + o;
            const ptrdiff_t W = w, S = st;
#define TAPG(off) (g0 + (off))
#define TAPS(off) (s0 + (off))
            const float *g1 = TAPG(-S), *g2 = TAPG(S), *g3 = TAPG(-S * W), *g4 = TAPG(S * W);
            const float *g5 = TAPG(-S * W - S), *g6 = TAPG(-S * W + S), *g7 = TAPG(S * W - S), *g8 = TAPG(S * W + S);
            const float *g9 = TAPG(-2 * S), *g10 = TAPG(2 * S), *g11 = TAPG(-2 * S * W), *g12 = TAPG(2 * S * W);
            const float *s1 = TAPS(-S), *s2 = TAPS(S), *s3 = TAPS(-S * W), *s4 = TAPS(S * W);
            const float *s5 = TAPS(-S * W - S), *s6 = TAPS(-S * W + S), *s7 = TAPS(S * W - S), *s8 = TAPS(S * W + S);
            const float *s9 = TAPS(-2 * S), *s10 = TAPS(2 * S), *s11 = TAPS(-2 * S * W), *s12 = TAPS(2 * S * W);
#undef TAPG
#undef TAPS
            UC_VEC
for (int x = m; x < w - m; x++) {
                const float c = g0[x];
                float dk = 1.f - c * (1.f / 255.f);
                dk = dk < 0.f ? 0.f : (dk > 1.f ? 1.f : dk);
                const float f = 1.f + 1.4f * dk * dk;
                const float inv = invBase / (f * f);
                float acc = s0[x] * 2.f, ws = 2.f, d, wt;
#define TAP(g, s, W_)                 \
    d = g[x] - c;                     \
    wt = (W_) / (1.f + d * d * inv);  \
    acc += s[x] * wt;                 \
    ws += wt;
                TAP(g1, s1, 1.f) TAP(g2, s2, 1.f) TAP(g3, s3, 1.f) TAP(g4, s4, 1.f)
                TAP(g5, s5, 0.7f) TAP(g6, s6, 0.7f) TAP(g7, s7, 0.7f) TAP(g8, s8, 0.7f)
                TAP(g9, s9, 0.5f) TAP(g10, s10, 0.5f) TAP(g11, s11, 0.5f) TAP(g12, s12, 0.5f)
#undef TAP
                dd[x] = acc / ws;
            }
        }
    });
}

void Pipe::post(int r0, int nr) {
    const int w = wo;
    const size_t npx = (size_t)nr * w;
    (void)npx;
    // 1) luma / chroma split
    prows(0, nr, w, [&](int a, int b) {
        for (size_t i = (size_t)a * w; i < (size_t)b * w; i++) {
            float r = rP[i], g = gP[i], bl = bP[i];
            float yv = 0.299f * r + 0.587f * g + 0.114f * bl;
            yP[i] = yv; cbP[i] = bl - yv; crP[i] = r - yv;
        }
    });
    // 2) noise-adaptive denoise; real detail above the noise floor is re-injected
    if (noiseSigma < 0.f) noiseSigma = estimateNoise(yP, nr);
    const float ns = noiseSigma;
    const float* yArr = yP;
    const float* cbF = cbP;
    const float* crF = crP;
    if (dn >= 0.05f) {
        const float sigR = ns * (1.1f + 2.4f * dn);
        const bool heavy = ns >= 4.f;
        boxBlur(yP, wsP, t1, w, nr, 1);
        bilateralWide(yP, wsP, t1, nr, 1, sigR);
        const float* dS = t1;
        if (heavy) {
            boxBlur(t1, wsP, gP, w, nr, 1);
            bilateralWide(t1, wsP, rP, nr, 2, sigR * 1.15f);
            dS = rP;
        }
        const float th = ns * 1.4f;
        const float th2 = th * th + 1e-6f;
        const float keep = 0.18f + 0.22f * (1.f - std::min(1.f, dn));
        prows(0, nr, w, [&](int a, int b) {
            for (size_t i = (size_t)a * w; i < (size_t)b * w; i++) {
                float d2 = dS[i];
                float r = yP[i] - d2;
                float k = r * r / (r * r + th2);
                t1[i] = d2 + r * (keep + (1.f - keep) * k);
            }
        });
        yArr = t1;
        const float sc2 = ns * (2.5f + 3.f * dn);
        const int stc = s > 1.f ? 3 : 2;
        const float* guide = dS;   // (non-heavy: dS aliases t1 == detail-restored luma, as in the original design)
        if (heavy) {
            bilateralWide(cbP, guide, gP, nr, stc, sc2);
            bilateralWide(gP, guide, bP, nr, stc * 2, sc2 * 1.2f);
            bilateralWide(crP, guide, yP, nr, stc, sc2);
            bilateralWide(yP, guide, wsP, nr, stc * 2, sc2 * 1.2f);
            const int br = clampi((int)std::lround(ns * 0.25f * (s > 1.f ? s : 1.f)), 1, 6);
            boxBlur(bP, bP, gP, w, nr, br);
            boxBlur(wsP, wsP, yP, w, nr, br);
        } else {
            bilateralWide(cbP, guide, bP, nr, stc, sc2);
            bilateralWide(crP, guide, wsP, nr, stc, sc2);
        }
        cbF = bP;
        crF = wsP;
    }
    // noise-aware tone/detail strength: don't boost what is mostly noise
    const float nk = 1.f / (1.f + ns / 8.f);
    const float detB = 1.f + (detailB - 1.f) * nk;
    const float midA = midAmt * (0.5f + 0.5f * nk);
    const float coreFine = std::max(coreT, ns * 1.2f);
    const float scMax = 2.2f + 3.8f / (1.f + ns / 10.f);
    const float nsq = ns * 0.04f;
    prows(0, nr, w, [&](int a, int b) {
        for (size_t i = (size_t)a * w; i < (size_t)b * w; i++) {
            float yv = yArr[i];
            float r = yv + crF[i];
            float bl = yv + cbF[i];
            float g = (yv - 0.299f * r - 0.114f * bl) * (1.f / 0.587f);
            rP[i] = r; gP[i] = g; bP[i] = bl;
        }
    });
    // 3) local tone mapping (shadow lift, highlight roll-off, local contrast)
    const float lg = 1.f / (1.f - 0.5f * lift);   // unused; kept for clarity of the LUT form
    (void)lg;
    prows(0, nr, w, [&](int a, int b) {
        std::vector<float> bsvRow(w), nbRow(w);
        for (int row = a; row < b; row++) {
            const int yy = r0 + row;
            const int ya = by0[yy];
            const float fy = byf[yy];
            const float* ba = base.data() + (size_t)ya * bw;
            const float* bb = base.data() + (size_t)(ya + 1) * bw;
            for (int x = 0; x < w; x++) {
                const int xa = bx0[x];
                const float fx = bxf[x];
                float top = ba[xa] * (1.f - fx) + ba[xa + 1] * fx;
                float bot = bb[xa] * (1.f - fx) + bb[xa + 1] * fx;
                float bsv = top * (1.f - fy) + bot * fy;
                float ti = bsv * (1023.f / 255.f);
                ti = ti < 0.f ? 0.f : (ti > 1022.99f ? 1022.99f : ti);
                int i0 = (int)ti;
                bsvRow[x] = bsv;
                nbRow[x] = toneLut[i0] + (toneLut[i0 + 1] - toneLut[i0]) * (ti - (float)i0);
            }
            const size_t o = (size_t)row * w;
            float* RESTRICT R = rP + o;
            float* RESTRICT G = gP + o;
            float* RESTRICT B = bP + o;
            float* RESTRICT Y = yP + o;
            float* RESTRICT SC = wsP + o;
            const float* RESTRICT bsvp = bsvRow.data();
            const float* RESTRICT nbp = nbRow.data();
            const float wbr = wbR, wbb = wbB;
            if (isDoc) {
                UC_VEC
for (int x = 0; x < w; x++) {
                    float r1 = R[x] * wbr, g1 = G[x], b1 = B[x] * wbb;
                    float yv = 0.299f * r1 + 0.587f * g1 + 0.114f * b1;
                    float v = (yv + 3.f) / (bsvp[x] + 3.f) * 246.f;
                    v = v > 255.f ? 255.f : v;
                    float xx = v * (1.f / 255.f);
                    float newY = xx * xx * (3.f - 2.f * xx) * 255.f;
                    float sc = (newY + 3.f) / (yv + 3.f);
                    sc = sc < 0.25f ? 0.25f : (sc > scMax ? scMax : sc);
                    SC[x] = sc;
                    float rs = r1 * sc, gs = g1 * sc, bs2 = b1 * sc;
                    float ys = 0.299f * rs + 0.587f * gs + 0.114f * bs2;
                    float sk = 1.f / (1.f + nsq * (sc > 1.f ? sc - 1.f : 0.f));
                    float r2 = shoulder(ys + (rs - ys) * sk);
                    float g2 = shoulder(ys + (gs - ys) * sk);
                    float b2 = shoulder(ys + (bs2 - ys) * sk);
                    R[x] = r2; G[x] = g2; B[x] = b2;
                    Y[x] = 0.299f * r2 + 0.587f * g2 + 0.114f * b2;
                }
            } else {
                const bool unit = (detB == 1.f);
                UC_VEC
for (int x = 0; x < w; x++) {
                    float r1 = R[x] * wbr, g1 = G[x], b1 = B[x] * wbb;
                    float yv = 0.299f * r1 + 0.587f * g1 + 0.114f * b1;
                    float ratio = (yv + 3.f) / (bsvp[x] + 3.f);
                    ratio = ratio < 0.15f ? 0.15f : (ratio > 6.f ? 6.f : ratio);
                    float dr = unit ? ratio : fast_exp2(detB * fast_log2(ratio));
                    float newY = (nbp[x] + 3.f) * dr - 3.f;
                    float sc = (newY + 3.f) / (yv + 3.f);
                    sc = sc < 0.25f ? 0.25f : (sc > scMax ? scMax : sc);
                    SC[x] = sc;
                    float rs = r1 * sc, gs = g1 * sc, bs2 = b1 * sc;
                    float ys = 0.299f * rs + 0.587f * gs + 0.114f * bs2;
                    float sk = 1.f / (1.f + nsq * (sc > 1.f ? sc - 1.f : 0.f));
                    float r2 = shoulder(ys + (rs - ys) * sk);
                    float g2 = shoulder(ys + (gs - ys) * sk);
                    float b2 = shoulder(ys + (bs2 - ys) * sk);
                    R[x] = r2; G[x] = g2; B[x] = b2;
                    Y[x] = 0.299f * r2 + 0.587f * g2 + 0.114f * b2;
                }
            }
        }
    });
    // 4) detail + sharpen (coring so noise is not sharpened, soft limiter so strong edges don't get halos)
    blurTwice(yP, t1, cbP, w, nr, sharpR);
    blurTwice(yP, crP, cbP, w, nr, midR);
    const float sA = sharpAmt, mA = midA;
    const float sharpLimInv = g_sharpLimInv;
    prows(0, nr, w, [&](int a, int b) {
        for (size_t i = (size_t)a * w; i < (size_t)b * w; i++) {
            float y = yP[i];
            float df = y - t1[i];
            float dm = y - crP[i];
            float scl = wsP[i];
            float th = coreFine * (scl > 1.f ? scl : 1.f);
            float tF = th * th;
            float tM = tF * 6.25f;
            float cf = df * df / (df * df + tF);
            float cm = dm * dm / (dm * dm + tM);
            float add = sA * df * cf + mA * dm * cm;
            add = add / (1.f + std::fabs(add) * sharpLimInv);
            rP[i] += add; gP[i] += add; bP[i] += add;
        }
    });
}

// ====================================================================== look + output
void Pipe::finish(int r0, int y0, int y1, uint32_t* out) {
    prows(y0, y1, wo, [&](int a, int b) {
        // lambda-local copies: lets the compiler keep them in registers and prove the loop trip count
        const int w = wo;
        const Look L = lk;
        const float invW = 1.f / (float)w, invH = 1.f / (float)ho;
        for (int y = a; y < b; y++) {
            const size_t o = (size_t)(y - r0) * w;
            const size_t so = (size_t)(y - y0) * w;
            const float* RESTRICT R = rP + o;
            const float* RESTRICT G = gP + o;
            const float* RESTRICT B = bP + o;
            uint32_t* RESTRICT D = out + so;
            const float ny = ((float)y * invH - 0.5f) * 2.f;
            const uint32_t yh = (uint32_t)y;
            UC_VEC
for (int x = 0; x < w; x++) {
                float r = R[x] * L.wr, g = G[x] * L.wg, b = B[x] * L.wb;
                // tone curve (analytic form of the old 256-entry LUT)
#define TONE(v)                                                                   \
    {                                                                             \
        float c_ = ((v) - L.lo) * L.invr;                                         \
        c_ = c_ < 0.f ? 0.f : (c_ > 255.f ? 255.f : c_);                          \
        float x_ = c_ * (1.f / 255.f) * L.ev;                                     \
        x_ = x_ > 1.f ? 1.f : x_;                                                 \
        float s_ = x_ * x_ * (3.f - 2.f * x_);                                    \
        float y_ = x_ + L.k * (s_ - x_);                                          \
        y_ = y_ < 0.f ? 0.f : (y_ > 1.f ? 1.f : y_);                              \
        (v) = (L.fade + y_ * (1.f - L.fade)) * 255.f;                             \
    }
                TONE(r) TONE(g) TONE(b)
#undef TONE
                const float lum = 0.299f * r + 0.587f * g + 0.114f * b;
                r += (lum - r) * L.mono;
                g += (lum - g) * L.mono;
                b += (lum - b) * L.mono;
                const float mx = std::max(r, std::max(g, b));
                const float mn = std::min(r, std::min(g, b));
                const float s0 = (mx - mn) / (mx + 1.f);
                const float sf = L.sat + L.vib * (1.f - s0);
                r = lum + (r - lum) * sf;
                g = lum + (g - lum) * sf;
                b = lum + (b - lum) * sf;
                float ln = lum * (1.f / 255.f);
                ln = ln < 0.f ? 0.f : (ln > 1.f ? 1.f : ln);
                const float wsh = (1.f - ln) * (1.f - ln);
                const float whi = ln * ln;
                r += L.shR * wsh + L.hiR * whi;
                g += L.shG * wsh + L.hiG * whi;
                b += L.shB * wsh + L.hiB * whi;
                if (L.vign > 0.f) {
                    const float nx = ((float)x * invW - 0.5f) * 2.f;
                    const float d = (nx * nx + ny * ny) * 0.5f;
                    const float f = 1.f - L.vign * d * d * 1.6f;
                    r *= f; g *= f; b *= f;
                }
                if (L.grain > 0.f) {
                    uint32_t hh = (uint32_t)x * 374761393u + yh * 668265263u;
                    hh = (hh ^ (hh >> 13)) * 1274126177u;
                    hh = hh ^ (hh >> 16);
                    const float nz = ((float)(hh & 0xFFFFu) * (1.f / 32768.f) - 1.f) * L.grain * 9.f;
                    r += nz; g += nz; b += nz;
                }
                // stochastic rounding (dither): kills banding in smooth gradients, removes the old truncation bias
                uint32_t h2 = (uint32_t)x * 0x9E3779B1u ^ (yh * 0x85EBCA77u + 0x165667B1u);
                h2 ^= h2 >> 15; h2 *= 0x2C1B3C6Du; h2 ^= h2 >> 12; h2 *= 0x297A2D39u; h2 ^= h2 >> 15;
                const float u = (float)(h2 >> 8) * (1.f / 16777216.f);
                r = r < 0.f ? 0.f : (r > 255.f ? 255.f : r);
                g = g < 0.f ? 0.f : (g > 255.f ? 255.f : g);
                b = b < 0.f ? 0.f : (b > 255.f ? 255.f : b);
                float ug = u + 0.3333f, ub = u + 0.6667f;     // three decorrelated uniform thresholds
                ug -= ug >= 1.f ? 1.f : 0.f;
                ub -= ub >= 1.f ? 1.f : 0.f;
                uint32_t ri = (uint32_t)(r + u), gi = (uint32_t)(g + ug), bi = (uint32_t)(b + ub);
                ri = ri > 255u ? 255u : ri; gi = gi > 255u ? 255u : gi; bi = bi > 255u ? 255u : bi;
                D[x] = 0xFF000000u | (ri << 16) | (gi << 8) | bi;
            }
        }
    });
}

// ====================================================================== lifecycle / C API
Pipe* pipe_create(const int* ci, int nci, const float* cf, int ncf, const float* base, int nbase,
                  const float* look, int nlook, const float* sigma, const float* fw, int n) {
    if (nci < 13 || ncf < 11 || nlook < 19 || n < 1 || !ci || !cf || !base || !look || !sigma || !fw) return nullptr;
    std::unique_ptr<Pipe> pp(new Pipe());
    Pipe& p = *pp;
    p.w = ci[0]; p.h = ci[1]; p.wo = ci[2]; p.ho = ci[3]; p.n = ci[4]; p.ref = ci[5]; p.capRows = ci[6];
    const int flags = ci[7];
    p.sharpR = ci[8]; p.midR = ci[9]; p.bw = ci[10]; p.bh = ci[11]; p.nSlots = ci[12];
    p.isHdr = flags & 1; p.isTrails = flags & 2; p.isDoc = flags & 4; p.merge = flags & 8; p.local = flags & 16;
    if (p.w < 8 || p.wo < 8 || p.ho < 8 || p.capRows < 1 || p.bw < 2 || p.bh < 2 || p.nSlots < 1 || p.n != n) return nullptr;
    if (p.s == 1.0f && p.wo != p.w) return nullptr;
    if (p.ref < 0 || p.ref >= p.n || p.nSlots > 64 || (int64_t)nbase < (int64_t)p.bw * p.bh) return nullptr;
    if ((p.merge && !p.isTrails && !p.isHdr && p.nSlots < p.n) || (p.isHdr && p.nSlots < p.n)) return nullptr;
    p.s = cf[0]; p.dn = cf[1]; p.sharpAmt = cf[2]; p.coreT = cf[3]; p.midAmt = cf[4]; p.detailB = cf[5]; p.lift = cf[6];
    p.wbR = cf[7]; p.wbB = cf[8]; p.gain = cf[9];   // cf[10] reserved
    p.base.assign(base, base + (size_t)p.bw * p.bh);
    p.sigma.assign(sigma, sigma + n);
    p.fw.assign(fw, fw + n);
    for (int i = 0; i < n; i++) p.sigma[i] = std::max(1.f, p.sigma[i]);
    float* L = &p.lk.sat;
    for (int i = 0; i < 19; i++) L[i] = look[i];

    p.cap = (size_t)p.capRows * p.wo;
    float** planes[] = {&p.rP, &p.gP, &p.bP, &p.yP, &p.cbP, &p.crP, &p.t1, &p.wsP};
    for (float** pl : planes) { *pl = falloc(p.cap); if (!*pl) return nullptr; }
    for (int i = 0; i < p.nSlots; i++) {
        uint32_t* s = talloc<uint32_t>(p.cap);
        if (!s) return nullptr;
        p.slots.push_back(s);
    }
    if (p.isHdr) {
        for (int i = 0; i < p.n; i++) { float* f = falloc(p.cap); if (!f) return nullptr; p.hdrW.push_back(f); }
    }
    if (p.merge && !p.isTrails && !p.isHdr) {
        p.lumA = talloc<uint8_t>(p.cap);
        p.lumB = talloc<uint8_t>(p.cap);
        if (!p.lumA || !p.lumB) return nullptr;
    }
    p.bxCount = (p.wo + BS - 1) / BS;
    p.offX.assign((size_t)p.bxCount * ((p.capRows + BS - 1) / BS), 0);
    p.offY.assign(p.offX.size(), 0);

    // tone LUT for the local tone-mapper
    const float expo = 1.f - 0.5f * p.lift;
    for (int i = 0; i < 1024; i++) {
        float v = (float)i / 1023.f;
        float v1 = v * p.gain;
        v1 = std::pow(v1, expo);
        if (v1 > 0.75f) v1 = 0.75f + 0.25f * (1.f - std::exp(-(v1 - 0.75f) / 0.25f));
        p.toneLut[i] = v1 * 255.f;
    }
    // base-map sampling tables (base is 1/4 scale of the source)
    p.bx0.resize(p.wo); p.bxf.resize(p.wo); p.by0.resize(p.ho); p.byf.resize(p.ho);
    for (int x = 0; x < p.wo; x++) {
        float u = ((float)x / p.s - 2.f) / 4.f;
        float uc = clampf(u, 0.f, (float)(p.bw - 1));
        int i = std::max(0, std::min(p.bw - 2, (int)uc));
        p.bx0[x] = i; p.bxf[x] = clampf(uc - (float)i, 0.f, 1.f);
    }
    for (int y = 0; y < p.ho; y++) {
        float v = ((float)y / p.s - 2.f) / 4.f;
        float vc = clampf(v, 0.f, (float)(p.bh - 1));
        int i = std::max(0, std::min(p.bh - 2, (int)vc));
        p.by0[y] = i; p.byf[y] = clampf(vc - (float)i, 0.f, 1.f);
    }
    return pp.release();
}

void pipe_destroy(Pipe* p) { delete p; }

void pipe_sample(Pipe* p, int slot, const uint32_t* src, long long srcLen, int srcRows, int yTop, float dx, float dy, int r0, int nr) {
    if (!p || !src || slot < 0 || slot >= p->nSlots || nr < 1 || nr > p->capRows || srcRows < 1) return;
    if ((long long)srcRows * p->w > srcLen || r0 < 0 || r0 + nr > p->ho) return;
    p->sample(slot, src, srcRows, yTop, dx, dy, r0, nr);
}
void pipe_merge(Pipe* p, int kind, int nr, int arg) {
    if (!p || nr < 1 || nr > p->capRows) return;
    p->mergeAll(kind, nr, arg);
}
void pipe_post(Pipe* p, int r0, int nr) {
    if (!p || nr < 1 || nr > p->capRows || r0 < 0 || r0 + nr > p->ho) return;
    p->post(r0, nr);
}
void pipe_finish(Pipe* p, int r0, int y0, int y1, uint32_t* out, long long outLen) {
    if (!p || !out || (long long)(y1 - y0) * p->wo > outLen || y0 < r0 || y1 - r0 > p->capRows || y1 > p->ho || y1 <= y0) return;
    p->finish(r0, y0, y1, out);
}

// ====================================================================== alignment helper
void ncc_search(const float* a, const float* b, int w, int h, const int* win, int cx, int cy, int rad, int step, int* outXY) {
    const int wx = win[0], wy = win[1], ww = win[2], wh = win[3];
    if (step < 1) step = 1;
    // statistics of the reference window do not depend on the candidate shift: compute once
    double sa = 0, saa = 0;
    long long n = 0;
    for (int y = wy; y < wy + wh; y += step) {
        const float* ra = a + (size_t)y * w;
        float ps = 0.f, pss = 0.f;
        int cnt = 0;
        for (int x = wx; x < wx + ww; x += step) { float p = ra[x]; ps += p; pss += p * p; cnt++; }
        sa += ps; saa += pss; n += cnt;
    }
    double bestS = -2.0;
    int bx = cx, by = cy;
    for (int dy = cy - rad; dy <= cy + rad; dy++) {
        for (int dx = cx - rad; dx <= cx + rad; dx++) {
            if (!(wx + dx >= 0 && wy + dy >= 0 && wx + ww + dx <= w && wy + wh + dy <= h)) continue;
            double sb = 0, sbb = 0, sab = 0;
            for (int y = wy; y < wy + wh; y += step) {
                const float* RESTRICT ra = a + (size_t)y * w;
                const float* RESTRICT rb = b + (size_t)(y + dy) * w + dx;
                float ps = 0.f, pss = 0.f, pab = 0.f;
                if (step == 1) {
                    for (int x = wx; x < wx + ww; x++) { float q = rb[x]; ps += q; pss += q * q; pab += ra[x] * q; }
                } else {
                    for (int x = wx; x < wx + ww; x += step) { float q = rb[x]; ps += q; pss += q * q; pab += ra[x] * q; }
                }
                sb += ps; sbb += pss; sab += pab;
            }
            double dn = (double)n;
            double num = dn * sab - sa * sb;
            double den = std::sqrt(std::max(1e-9, (dn * saa - sa * sa) * (dn * sbb - sb * sb)));
            double s = num / den;
            if (s > bestS) { bestS = s; bx = dx; by = dy; }
        }
    }
    outXY[0] = bx;
    outXY[1] = by;
}

}  // namespace uc

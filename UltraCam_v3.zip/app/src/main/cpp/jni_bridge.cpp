// JNI glue: com.ultracam.app.NativeEngine
#include <jni.h>

#include "engine.hpp"

using namespace uc;

#define JFN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_ultracam_app_NativeEngine_##name

namespace {
struct IntArr {
    JNIEnv* e; jintArray a; jint* p; jsize n;
    IntArr(JNIEnv* env, jintArray arr) : e(env), a(arr), p(nullptr), n(0) { if (a) { n = e->GetArrayLength(a); p = e->GetIntArrayElements(a, nullptr); } }
    ~IntArr() { if (p) e->ReleaseIntArrayElements(a, p, JNI_ABORT); }
};
struct FloatArr {
    JNIEnv* e; jfloatArray a; jfloat* p; jsize n;
    FloatArr(JNIEnv* env, jfloatArray arr) : e(env), a(arr), p(nullptr), n(0) { if (a) { n = e->GetArrayLength(a); p = e->GetFloatArrayElements(a, nullptr); } }
    ~FloatArr() { if (p) e->ReleaseFloatArrayElements(a, p, JNI_ABORT); }
};
}  // namespace

JFN(jlong, create)(JNIEnv* env, jobject, jintArray ci, jfloatArray cf, jfloatArray base, jfloatArray look, jfloatArray sigma, jfloatArray fw) {
    IntArr I(env, ci);
    FloatArr F(env, cf), B(env, base), L(env, look), S(env, sigma), W(env, fw);
    if (!I.p || !F.p || !B.p || !L.p || !S.p || !W.p) return 0;
    if (S.n < 1 || W.n < S.n) return 0;
    Pipe* p = pipe_create(I.p, I.n, F.p, F.n, B.p, B.n, L.p, L.n, S.p, W.p, S.n);
    return (jlong)(intptr_t)p;
}

JFN(void, destroy)(JNIEnv*, jobject, jlong h) { pipe_destroy((Pipe*)(intptr_t)h); }

JFN(void, sample)(JNIEnv* env, jobject, jlong h, jint slot, jintArray src, jint rows, jint yTop, jfloat dx, jfloat dy, jint r0, jint nr) {
    if (!h || !src) return;
    jint* p = (jint*)env->GetPrimitiveArrayCritical(src, nullptr);
    if (!p) return;
    pipe_sample((Pipe*)(intptr_t)h, slot, (const uint32_t*)p, (long long)env->GetArrayLength(src), rows, yTop, dx, dy, r0, nr);
    env->ReleasePrimitiveArrayCritical(src, p, JNI_ABORT);
}

JFN(void, merge)(JNIEnv*, jobject, jlong h, jint kind, jint nr, jint arg) {
    if (h) pipe_merge((Pipe*)(intptr_t)h, kind, nr, arg);
}

JFN(void, post)(JNIEnv*, jobject, jlong h, jint r0, jint nr) {
    if (h) pipe_post((Pipe*)(intptr_t)h, r0, nr);
}

JFN(void, finish)(JNIEnv* env, jobject, jlong h, jint r0, jint y0, jint y1, jintArray out) {
    if (!h || !out) return;
    jint* p = (jint*)env->GetPrimitiveArrayCritical(out, nullptr);
    if (!p) return;
    pipe_finish((Pipe*)(intptr_t)h, r0, y0, y1, (uint32_t*)p, (long long)env->GetArrayLength(out));
    env->ReleasePrimitiveArrayCritical(out, p, 0);
}

JFN(jintArray, search)(JNIEnv* env, jobject, jfloatArray a, jfloatArray b, jint w, jint h, jintArray win, jint cx, jint cy, jint rad, jint step) {
    jint res[2] = {cx, cy};
    if (a && b && win && w > 0 && h > 0 && env->GetArrayLength(win) >= 4 && env->GetArrayLength(a) >= w * h && env->GetArrayLength(b) >= w * h) {
        jint wn[4];
        env->GetIntArrayRegion(win, 0, 4, wn);
        if (wn[0] >= 0 && wn[1] >= 0 && wn[2] > 0 && wn[3] > 0 && wn[0] + wn[2] <= w && wn[1] + wn[3] <= h) {
            jfloat* pa = (jfloat*)env->GetPrimitiveArrayCritical(a, nullptr);
            jfloat* pb = (jfloat*)env->GetPrimitiveArrayCritical(b, nullptr);
            if (pa && pb) ncc_search(pa, pb, w, h, wn, cx, cy, rad, step, res);
            if (pb) env->ReleasePrimitiveArrayCritical(b, pb, JNI_ABORT);
            if (pa) env->ReleasePrimitiveArrayCritical(a, pa, JNI_ABORT);
        }
    }
    jintArray out = env->NewIntArray(2);
    if (out) env->SetIntArrayRegion(out, 0, 2, res);
    return out;
}

// JNI glue: com.ultracam.app.NativeEngine
#include <jni.h>

#include "engine.hpp"

using namespace uc;

#define JFN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_ultracam_app_NativeEngine_##name

namespace {
struct IntArr {
    JNIEnv* e; jintArray a; jint* p; jsize n;
    IntArr(JNIEnv* env, jintArray arr) : e(env), a(arr), p(nullptr), n(0) { if (a) { n = e->GetArrayLength(a); p = e->GetIntArrayElements(a, nullptr); } }
    ~IntArr() { if (p) e->ReleaseIntArrayElements(a, p, JNI_ABORT); }
};
struct FloatArr {
    JNIEnv* e; jfloatArray a; jfloat* p; jsize n;
    FloatArr(JNIEnv* env, jfloatArray arr) : e(env), a(arr), p(nullptr), n(0) { if (a) { n = e->GetArrayLength(a); p = e->GetFloatArrayElements(a, nullptr); } }
    ~FloatArr() { if (p) e->ReleaseFloatArrayElements(a, p, JNI_ABORT); }
};
}  // namespace

JFN(jlong, create)(JNIEnv* env, jobject, jintArray ci, jfloatArray cf, jfloatArray base, jfloatArray look, jfloatArray sigma, jfloatArray fw) {
    IntArr I(env, ci);
    FloatArr F(env, cf), B(env, base), L(env, look), S(env, sigma), W(env, fw);
    if (!I.p || !F.p || !B.p || !L.p || !S.p || !W.p) return 0;
    if (S.n < 1 || W.n < S.n) return 0;
    Pipe* p = pipe_create(I.p, I.n, F.p, F.n, B.p, B.n, L.p, L.n, S.p, W.p, S.n);
    return (jlong)(intptr_t)p;
}

JFN(void, destroy)(JNIEnv*, jobject, jlong h) { pipe_destroy((Pipe*)(intptr_t)h); }

JFN(void, sample)(JNIEnv* env, jobject, jlong h, jint slot, jintArray src, jint rows, jint yTop, jfloat dx, jfloat dy, jint r0, jint nr) {
    if (!h || !src) return;
    jint* p = (jint*)env->GetPrimitiveArrayCritical(src, nullptr);
    if (!p) return;
    pipe_sample((Pipe*)(intptr_t)h, slot, (const uint32_t*)p, (long long)env->GetArrayLength(src), rows, yTop, dx, dy, r0, nr);
    env->ReleasePrimitiveArrayCritical(src, p, JNI_ABORT);
}

JFN(void, merge)(JNIEnv*, jobject, jlong h, jint kind, jint nr, jint arg) {
    if (h) pipe_merge((Pipe*)(intptr_t)h, kind, nr, arg);
}

JFN(void, post)(JNIEnv*, jobject, jlong h, jint r0, jint nr) {
    if (h) pipe_post((Pipe*)(intptr_t)h, r0, nr);
}

JFN(void, finish)(JNIEnv* env, jobject, jlong h, jint r0, jint y0, jint y1, jintArray out) {
    if (!h || !out) return;
    jint* p = (jint*)env->GetPrimitiveArrayCritical(out, nullptr);
    if (!p) return;
    pipe_finish((Pipe*)(intptr_t)h, r0, y0, y1, (uint32_t*)p, (long long)env->GetArrayLength(out));
    env->ReleasePrimitiveArrayCritical(out, p, 0);
}

JFN(jintArray, search)(JNIEnv* env, jobject, jfloatArray a, jfloatArray b, jint w, jint h, jintArray win, jint cx, jint cy, jint rad, jint step) {
    jint res[2] = {cx, cy};
    if (a && b && win && w > 0 && h > 0 && env->GetArrayLength(win) >= 4 && env->GetArrayLength(a) >= w * h && env->GetArrayLength(b) >= w * h) {
        jint wn[4];
        env->GetIntArrayRegion(win, 0, 4, wn);
        if (wn[0] >= 0 && wn[1] >= 0 && wn[2] > 0 && wn[3] > 0 && wn[0] + wn[2] <= w && wn[1] + wn[3] <= h) {
            jfloat* pa = (jfloat*)env->GetPrimitiveArrayCritical(a, nullptr);
            jfloat* pb = (jfloat*)env->GetPrimitiveArrayCritical(b, nullptr);
            if (pa && pb) ncc_search(pa, pb, w, h, wn, cx, cy, rad, step, res);
            if (pb) env->ReleasePrimitiveArrayCritical(b, pb, JNI_ABORT);
            if (pa) env->ReleasePrimitiveArrayCritical(a, pa, JNI_ABORT);
        }
    }
    jintArray out = env->NewIntArray(2);
    if (out) env->SetIntArrayRegion(out, 0, 2, res);
    return out;
}

// ====================================================================== RAW engine (com.ultracam.app.NativeRaw)
#include "raw.hpp"
#include <cstring>

#define RFN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_ultracam_app_NativeRaw_##name

// ci: 0 w, 1 h, 2 cfa, 3 cropX, 4 cropY, 5 outW, 6 outH
// cf: 0..3 black, 4 white, 5..7 wb, 8..16 ccm, 17 noiseS, 18 noiseO
RFN(jlong, create)(JNIEnv* env, jobject, jintArray ci, jfloatArray cf) {
    IntArr I(env, ci);
    FloatArr F(env, cf);
    if (!I.p || !F.p || I.n < 7 || F.n < 19) return 0;
    uc::RawInit in{};
    in.w = I.p[0]; in.h = I.p[1]; in.cfa = I.p[2]; in.cropX = I.p[3]; in.cropY = I.p[4]; in.outW = I.p[5]; in.outH = I.p[6];
    for (int k = 0; k < 4; k++) in.black[k] = F.p[k];
    in.white = F.p[4];
    for (int k = 0; k < 3; k++) in.wb[k] = F.p[5 + k];
    for (int k = 0; k < 9; k++) in.ccm[k] = F.p[8 + k];
    in.noiseS = F.p[17]; in.noiseO = F.p[18];
    return (jlong)(intptr_t)uc::raw_create(in);
}

RFN(void, destroy)(JNIEnv*, jobject, jlong h) { uc::raw_destroy((uc::RawPipe*)(intptr_t)h); }

RFN(void, enableSr)(JNIEnv*, jobject, jlong h, jint on) { if (h) uc::raw_enable_sr((uc::RawPipe*)(intptr_t)h, on); }

RFN(void, shading)(JNIEnv* env, jobject, jlong h, jfloatArray gains, jint mw, jint mh) {
    FloatArr G(env, gains);
    if (!h || !G.p || G.n < 4 * mw * mh) return;
    uc::raw_set_shading((uc::RawPipe*)(intptr_t)h, G.p, mw, mh);
}

// data = direct ByteBuffer holding RAW16 samples
RFN(jint, addFrame)(JNIEnv* env, jobject, jlong h, jobject data, jint strideBytes, jfloat expGain, jfloat motionW, jfloatArray black4) {
    if (!h || !data) return -9;
    const uint16_t* p = (const uint16_t*)env->GetDirectBufferAddress(data);
    if (!p) return -8;
    FloatArr B(env, black4);
    return uc::raw_add_frame((uc::RawPipe*)(intptr_t)h, p, strideBytes, expGain, motionW, (B.p && B.n >= 4) ? B.p : nullptr);
}

RFN(jint, prepare)(JNIEnv* env, jobject, jlong h, jfloatArray prm) {
    FloatArr P(env, prm);
    if (!h || !P.p) return -9;
    return uc::raw_prepare((uc::RawPipe*)(intptr_t)h, P.p, P.n);
}

RFN(void, strip)(JNIEnv* env, jobject, jlong h, jint y0, jint y1, jintArray out) {
    if (!h || !out) return;
    jint* p = env->GetIntArrayElements(out, nullptr);
    if (!p) return;
    uc::raw_strip((const uc::RawPipe*)(intptr_t)h, y0, y1, (uint32_t*)p);
    env->ReleaseIntArrayElements(out, p, 0);
}

RFN(jfloat, info)(JNIEnv*, jobject, jlong h, jint what) { return uc::raw_info((const uc::RawPipe*)(intptr_t)h, what); }
RFN(jint, frames)(JNIEnv*, jobject, jlong h) { return uc::raw_frames((const uc::RawPipe*)(intptr_t)h); }

// matrices may be null. out: 0..2 wb, 3..11 ccm, 12 cct, 13 usedForwardMatrix
RFN(jfloatArray, calib)(JNIEnv* env, jobject, jfloatArray fm1, jfloatArray fm2, jfloatArray cm1, jfloatArray cm2, jfloatArray cc1, jfloatArray cc2,
                        jint ill1, jint ill2, jfloatArray neutral) {
    FloatArr F1(env, fm1), F2(env, fm2), C1(env, cm1), C2(env, cm2), K1(env, cc1), K2(env, cc2), N(env, neutral);
    float out[14] = {1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 5000.f, 0.f};
    if (N.p && N.n >= 3) {
        float cct = 5000.f;
        int used = uc::raw_color_calib((F1.p && F1.n >= 9) ? F1.p : nullptr, (F2.p && F2.n >= 9) ? F2.p : nullptr,
                                       (C1.p && C1.n >= 9) ? C1.p : nullptr, (C2.p && C2.n >= 9) ? C2.p : nullptr,
                                       (K1.p && K1.n >= 9) ? K1.p : nullptr, (K2.p && K2.n >= 9) ? K2.p : nullptr,
                                       ill1, ill2, N.p, out, out + 3, &cct);
        out[12] = cct; out[13] = (float)used;
    }
    jfloatArray r = env->NewFloatArray(14);
    if (r) env->SetFloatArrayRegion(r, 0, 14, out);
    return r;
}

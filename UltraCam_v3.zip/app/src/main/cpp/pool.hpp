// Small persistent thread pool (no JNI, no Java objects). One parallel job at a time;
// if the pool is busy the caller just runs the work inline, so nested / concurrent
// callers can never deadlock.
#pragma once
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>
#if defined(__linux__) || defined(__ANDROID__)
#include <sys/resource.h>
#include <sys/syscall.h>
#include <unistd.h>
#endif

namespace uc {

class Pool {
public:
    static Pool& get() {
        static Pool* p = new Pool();   // intentionally leaked: no join hang at process exit
        return *p;
    }
    int threads() const { return (int)workers_.size() + 1; }

    void run(int from, int to, int minChunk, const std::function<void(int, int)>& fn) {
        const int n = to - from;
        if (n <= 0) return;
        if (minChunk < 1) minChunk = 1;
        if (workers_.empty() || n < 2 * minChunk || !call_.try_lock()) { fn(from, to); return; }
        std::lock_guard<std::mutex> cg(call_, std::adopt_lock);
        Job j;
        j.fn = &fn; j.to = to;
        int chunk = (n + threads() * 3 - 1) / (threads() * 3);
        if (chunk < minChunk) chunk = minChunk;
        j.chunk = chunk;
        j.next.store(from);
        {
            std::lock_guard<std::mutex> lk(m_);
            job_ = &j; ++gen_; working_ = (int)workers_.size();
        }
        cv_.notify_all();
        work(j);
        std::unique_lock<std::mutex> lk(m_);
        done_.wait(lk, [&] { return working_ == 0; });
        job_ = nullptr;
    }

private:
    struct Job {
        const std::function<void(int, int)>* fn = nullptr;
        int to = 0, chunk = 1;
        std::atomic<int> next{0};
    };

    Pool() {
        unsigned hw = std::thread::hardware_concurrency();
        int total = hw == 0 ? 4 : (int)hw;
        if (total > 8) total = 8;
        for (int i = 0; i < total - 1; i++) workers_.emplace_back([this] { loop(); });
        for (auto& t : workers_) t.detach();
    }

    static void work(Job& j) {
        for (;;) {
            int a = j.next.fetch_add(j.chunk);
            if (a >= j.to) break;
            int b = a + j.chunk;
            if (b > j.to) b = j.to;
            (*j.fn)(a, b);
        }
    }

    void loop() {
#if defined(__ANDROID__)
        // slightly lower priority: camera preview / UI stay smooth while processing
        setpriority(PRIO_PROCESS, (id_t)syscall(SYS_gettid), 4);
#endif
        uint64_t seen = 0;
        for (;;) {
            Job* j;
            {
                std::unique_lock<std::mutex> lk(m_);
                cv_.wait(lk, [&] { return gen_ != seen; });
                seen = gen_;
                j = job_;
            }
            work(*j);
            {
                std::lock_guard<std::mutex> lk(m_);
                if (--working_ == 0) done_.notify_one();
            }
        }
    }

    std::vector<std::thread> workers_;
    std::mutex m_, call_;
    std::condition_variable cv_, done_;
    uint64_t gen_ = 0;
    int working_ = 0;
    Job* job_ = nullptr;
};

}  // namespace uc

// UltraCam RAW engine (see raw.hpp)
#include "raw.hpp"
#include "demosaic.hpp"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <vector>

namespace uc {
namespace {

inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

int hwThreads() {
    unsigned n = std::thread::hardware_concurrency();
    if (n == 0) n = 2;
    return (int)std::min(n, 6u);
}

template <class F>
void par_for(int n, F&& f) {
    int t = std::min(hwThreads(), n);
    if (t <= 1) { for (int i = 0; i < n; i++) f(i); return; }
    std::atomic<int> next(0);
    auto work = [&]() { for (;;) { int i = next.fetch_add(1); if (i >= n) break; f(i); } };
    std::vector<std::thread> th;
    for (int k = 1; k < t; k++) th.emplace_back(work);
    work();
    for (auto& x : th) x.join();
}

// ---------------------------------------------------------------- box blur (edge-clamped mean), in place allowed
void boxblur(const float* src, float* dst, int w, int h, int r) {
    if (r <= 0) { if (src != dst) std::memcpy(dst, src, sizeof(float) * (size_t)w * h); return; }
    std::vector<float> tmp((size_t)w * h);
    for (int y = 0; y < h; y++) {
        const float* a = src + (size_t)y * w;
        float* b = tmp.data() + (size_t)y * w;
        double acc = 0;
        int hi = std::min(r, w - 1);
        for (int x = 0; x <= hi; x++) acc += a[x];
        for (int x = 0; x < w; x++) {
            int l = std::max(0, x - r), rr = std::min(w - 1, x + r);
            b[x] = (float)(acc / (rr - l + 1));
            if (x + r + 1 < w) acc += a[x + r + 1];
            if (x - r >= 0) acc -= a[x - r];
        }
    }
    std::vector<double> col(w, 0.0);
    int hi = std::min(r, h - 1);
    for (int y = 0; y <= hi; y++) { const float* a = tmp.data() + (size_t)y * w; for (int x = 0; x < w; x++) col[x] += a[x]; }
    for (int y = 0; y < h; y++) {
        int l = std::max(0, y - r), rr = std::min(h - 1, y + r);
        double inv = 1.0 / (rr - l + 1);
        float* o = dst + (size_t)y * w;
        for (int x = 0; x < w; x++) o[x] = (float)(col[x] * inv);
        if (y + r + 1 < h) { const float* a = tmp.data() + (size_t)(y + r + 1) * w; for (int x = 0; x < w; x++) col[x] += a[x]; }
        if (y - r >= 0) { const float* a = tmp.data() + (size_t)(y - r) * w; for (int x = 0; x < w; x++) col[x] -= a[x]; }
    }
}

// Guided filter (He et al.) with a per-pixel eps. I = guide, P = input. out may alias P.
void guided(const float* I, const float* P, const float* eps, float* out, int w, int h, int r) {
    const size_t n = (size_t)w * h;
    std::vector<float> mI(n), mP(n), cI(n), cIP(n), tmp(n);
    boxblur(I, mI.data(), w, h, r);
    boxblur(P, mP.data(), w, h, r);
    for (size_t i = 0; i < n; i++) tmp[i] = I[i] * I[i];
    boxblur(tmp.data(), cI.data(), w, h, r);
    for (size_t i = 0; i < n; i++) tmp[i] = I[i] * P[i];
    boxblur(tmp.data(), cIP.data(), w, h, r);
    // a -> cI, b -> cIP
    for (size_t i = 0; i < n; i++) {
        float var = std::max(0.f, cI[i] - mI[i] * mI[i]);
        float cov = cIP[i] - mI[i] * mP[i];
        float a = cov / (var + eps[i] + 1e-12f);
        cI[i] = a;
        cIP[i] = mP[i] - a * mI[i];
    }
    boxblur(cI.data(), mI.data(), w, h, r);
    boxblur(cIP.data(), mP.data(), w, h, r);
    for (size_t i = 0; i < n; i++) out[i] = mI[i] * I[i] + mP[i];
}

// ---------------------------------------------------------------- CFA helpers
// colour index (0 R, 1 G, 2 B) for raster position k = (y&1)*2 + (x&1)
const int kCfa[4][4] = {
    {0, 1, 1, 2},  // RGGB
    {1, 0, 2, 1},  // GRBG
    {1, 2, 0, 1},  // GBRG
    {2, 1, 1, 0},  // BGGR
};

constexpr int LEVELS = 4;
constexpr int TILE = 16;
constexpr int MARGIN = 40;

}  // namespace

// ======================================================================== pipe
struct RawPipe {
    RawInit in;
    int w = 0, h = 0, qw = 0, qh = 0;
    std::vector<float> acc;        // merged mosaic (normalised, ref exposure)
    std::vector<float> wsum;       // per quad weight sum
    // reference candidates (first frames are staged; the sharpest + steadiest one becomes the reference)
    struct Cand { std::vector<uint16_t> data; float gain, mw; float black[4]; };
    std::vector<Cand> cand;
    bool refChosen = false;
    std::vector<uint8_t> refClip;  // reference quad was clipped (accept any frame there)
    std::vector<float> pyr[LEVELS];
    int pw[LEVELS], ph[LEVELS];
    int nFrames = 0;
    bool prepared = false;
    std::vector<float> shade;
    int sw = 0, sh = 0;
    // develop state
    float prm[RAW_P_COUNT];
    float neff = 1.f;
    float g0 = 1.f;
    float awb[3] = {1.f, 1.f, 1.f};
    int lw = 0, lh = 0;            // low-res grid (8x8 raw pixels per cell)
    std::vector<float> lowLog;     // log2 luma of the cell (after g0)
    std::vector<float> lowGain;    // log2 local gain
    float lvlLo = 0.f, lvlHi = 1.f;
    float srgbLut[4097];
    // sub-pixel super-resolution: green samples of every aligned frame, splatted on the raw-pixel grid
    bool srOn = false;
    std::vector<float> srNum, srDen;
};

namespace {

// ---- alignment ----------------------------------------------------------------
void buildPyramid(RawPipe& p, const std::vector<float>& l0, std::vector<float>* dst /*[LEVELS]*/) {
    dst[0] = l0;
    for (int l = 1; l < LEVELS; l++) {
        int w0 = p.pw[l - 1], h0 = p.ph[l - 1], w1 = p.pw[l], h1 = p.ph[l];
        dst[l].assign((size_t)w1 * h1, 0.f);
        const float* s = dst[l - 1].data();
        float* d = dst[l].data();
        for (int y = 0; y < h1; y++) {
            int y0 = std::min(2 * y, h0 - 1), y1 = std::min(2 * y + 1, h0 - 1);
            for (int x = 0; x < w1; x++) {
                int x0 = std::min(2 * x, w0 - 1), x1 = std::min(2 * x + 1, w0 - 1);
                d[(size_t)y * w1 + x] = 0.25f * (s[(size_t)y0 * w0 + x0] + s[(size_t)y0 * w0 + x1] + s[(size_t)y1 * w0 + x0] + s[(size_t)y1 * w0 + x1]);
            }
        }
    }
}

float tileSad(const float* ref, const float* cur, int w, int h, int x0, int y0, int ox, int oy, float best) {
    int x1 = std::min(x0 + TILE, w), y1 = std::min(y0 + TILE, h);
    float s = 0.f;
    const bool fast = (x0 + ox >= 0) && (x1 + ox <= w);
    for (int y = y0; y < y1; y++) {
        int yy = clampi(y + oy, 0, h - 1);
        const float* r = ref + (size_t)y * w;
        const float* c = cur + (size_t)yy * w;
        if (fast) {
            for (int x = x0; x < x1; x++) s += std::fabs(r[x] - c[x + ox]);
        } else {
            for (int x = x0; x < x1; x++) s += std::fabs(r[x] - c[clampi(x + ox, 0, w - 1)]);
        }
        if (s >= best) return s;
    }
    return s;
}

struct Field { int tw = 0, th = 0; std::vector<int> ox, oy; };

void alignLevels(const RawPipe& p, const std::vector<float>* cur, Field* fld /*[LEVELS]*/) {
    for (int l = LEVELS - 1; l >= 0; l--) {
        Field& f = fld[l];
        const int w = p.pw[l], h = p.ph[l];
        f.tw = (w + TILE - 1) / TILE; f.th = (h + TILE - 1) / TILE;
        f.ox.assign((size_t)f.tw * f.th, 0); f.oy.assign((size_t)f.tw * f.th, 0);
        const int rad = (l == LEVELS - 1) ? 4 : 2;
        const float* R = p.pyr[l].data();
        const float* C = cur[l].data();
        par_for(f.th, [&](int ty) {
            for (int tx = 0; tx < f.tw; tx++) {
                int cx = 0, cy = 0;
                if (l < LEVELS - 1) {
                    const Field& up = fld[l + 1];
                    int px = std::min(tx / 2, up.tw - 1), py = std::min(ty / 2, up.th - 1);
                    int nx = clampi(px + ((tx & 1) ? 1 : -1), 0, up.tw - 1);
                    int ny = clampi(py + ((ty & 1) ? 1 : -1), 0, up.th - 1);
                    int cand[3][2] = {{up.ox[(size_t)py * up.tw + px] * 2, up.oy[(size_t)py * up.tw + px] * 2},
                                      {up.ox[(size_t)py * up.tw + nx] * 2, up.oy[(size_t)py * up.tw + nx] * 2},
                                      {up.ox[(size_t)ny * up.tw + px] * 2, up.oy[(size_t)ny * up.tw + px] * 2}};
                    float best = 1e30f;
                    for (auto& c : cand) {
                        float s = tileSad(R, C, w, h, tx * TILE, ty * TILE, c[0], c[1], best);
                        if (s < best) { best = s; cx = c[0]; cy = c[1]; }
                    }
                }
                float best = 1e30f;
                int bx = cx, by = cy;
                for (int dy = -rad; dy <= rad; dy++)
                    for (int dx = -rad; dx <= rad; dx++) {
                        int ox = cx + dx, oy = cy + dy;
                        float s = tileSad(R, C, w, h, tx * TILE, ty * TILE, ox, oy, best);
                        s += 1e-6f * (float)(std::abs(dx) + std::abs(dy));
                        if (s < best) { best = s; bx = ox; by = oy; }
                    }
                f.ox[(size_t)ty * f.tw + tx] = bx;
                f.oy[(size_t)ty * f.tw + tx] = by;
            }
        });
    }
}

inline float satThresh(const RawInit& in, const float* black, int k) { return black[k] + 0.985f * (in.white - black[k]); }

// normalised quad luma of a frame at ref-exposure units; clip flag per quad
void quadLuma(const RawPipe& p, const uint16_t* d, size_t strideEl, const float* black, float gain, std::vector<float>& L, std::vector<uint8_t>* clip) {
    const int qw = p.qw, qh = p.qh;
    L.assign((size_t)qw * qh, 0.f);
    if (clip) clip->assign((size_t)qw * qh, 0);
    float inv[4], th[4];
    for (int k = 0; k < 4; k++) { inv[k] = 1.f / std::max(1.f, p.in.white - black[k]); th[k] = satThresh(p.in, black, k); }
    par_for(qh, [&](int qy) {
        const uint16_t* r0 = d + (size_t)(2 * qy) * strideEl;
        const uint16_t* r1 = r0 + strideEl;
        for (int qx = 0; qx < qw; qx++) {
            float a = r0[2 * qx], b = r0[2 * qx + 1], c = r1[2 * qx], e = r1[2 * qx + 1];
            if (clip && (a >= th[0] || b >= th[1] || c >= th[2] || e >= th[3])) (*clip)[(size_t)qy * qw + qx] = 1;
            float v = ((a - black[0]) * inv[0] + (b - black[1]) * inv[1] + (c - black[2]) * inv[2] + (e - black[3]) * inv[3]) * 0.25f * gain;
            L[(size_t)qy * qw + qx] = v < 0.f ? 0.f : v;
        }
    });
}

// ---- sub-pixel super-resolution helpers ----------------------------------------
// One Lucas-Kanade step per tile on the quad luma. Result: sub-quad residual d with ref(q) ~= cur(q + o + d).
void tileResidual(const RawPipe& p, const std::vector<float>& cur, const Field& f, std::vector<float>& rdx, std::vector<float>& rdy) {
    const int qw = p.qw, qh = p.qh;
    rdx.assign((size_t)f.tw * f.th, 0.f);
    rdy.assign((size_t)f.tw * f.th, 0.f);
    const float* R = p.pyr[0].data();
    par_for(f.th, [&](int ty) {
        for (int tx = 0; tx < f.tw; tx++) {
            const int ox = f.ox[(size_t)ty * f.tw + tx], oy = f.oy[(size_t)ty * f.tw + tx];
            const int xa = tx * TILE, ya = ty * TILE, xb = std::min(xa + TILE, qw), yb = std::min(ya + TILE, qh);
            double a00 = 0, a01 = 0, a11 = 0, b0 = 0, b1 = 0;
            int n = 0;
            for (int y = ya; y < yb; y++) {
                const int sy = y + oy;
                if (sy < 1 || sy >= qh - 1) continue;
                for (int x = xa; x < xb; x++) {
                    const int sx = x + ox;
                    if (sx < 1 || sx >= qw - 1) continue;
                    const size_t si = (size_t)sy * qw + sx;
                    const float gx = 0.5f * (cur[si + 1] - cur[si - 1]);
                    const float gy = 0.5f * (cur[si + qw] - cur[si - qw]);
                    const float e = R[(size_t)y * qw + x] - cur[si];
                    a00 += gx * gx; a01 += gx * gy; a11 += gy * gy; b0 += gx * e; b1 += gy * e;
                    n++;
                }
            }
            if (n < 64) continue;
            a00 += 0.03; a11 += 0.03;                       // regularisation: flat tiles stay at 0
            const double det = a00 * a11 - a01 * a01;
            if (det < 1e-9) continue;
            const double dx = (a11 * b0 - a01 * b1) / det, dy = (a00 * b1 - a01 * b0) / det;
            rdx[(size_t)ty * f.tw + tx] = clampf((float)dx, -0.7f, 0.7f);
            rdy[(size_t)ty * f.tw + tx] = clampf((float)dy, -0.7f, 0.7f);
        }
    });
}

// Gaussian kernel (sigma ~0.41 raw px, exp(-3 r^2)) lookup, r2 in [0, 2.25]
struct SrLut {
    float v[257];
    SrLut() { for (int i = 0; i <= 256; i++) v[i] = std::exp(-(2.25f * (float)i / 256.f) * 3.0f); }
};
inline float srKernel(float r2) {
    static const SrLut lut;
    return lut.v[(int)(r2 * (256.f / 2.25f))];
}

// Gather the green samples of one frame around (cx, cy) (position inside that frame, raw pixels) into the accumulators at ref pixel (x, y).
inline void srAccum(RawPipe* p, const uint16_t* d, size_t strideEl, const float* black, const float* inv, const float* th, float gain,
                    const int* cfa, int x, int y, float cx, float cy, float wgt) {
    const int w = p->w, h = p->h;
    const int i0 = (int)std::floor(cx) - 1, j0 = (int)std::floor(cy) - 1;
    float num = 0.f, den = 0.f;
    for (int j = j0; j < j0 + 4; j++) {
        if (j < 0 || j >= h) continue;
        for (int i = i0; i < i0 + 4; i++) {
            if (i < 0 || i >= w) continue;
            const int k = ((j & 1) << 1) | (i & 1);
            if (cfa[k] != 1) continue;
            const float dx = (float)i - cx, dy = (float)j - cy;
            const float r2 = dx * dx + dy * dy;
            if (r2 >= 2.25f) continue;
            const float raw = (float)d[(size_t)j * strideEl + i];
            if (raw >= th[k]) continue;                      // clipped sample
            const float kw = srKernel(r2);
            num += kw * (raw - black[k]) * inv[k] * gain;
            den += kw;
        }
    }
    const size_t idx = (size_t)y * w + x;
    p->srNum[idx] += wgt * num;
    p->srDen[idx] += wgt * den;
}

}  // namespace

RawPipe* raw_create(const RawInit& in) {
    if (in.w < 64 || in.h < 64 || (in.w & 1) || (in.h & 1)) return nullptr;
    if (in.outW < 16 || in.outH < 16 || in.cropX < 0 || in.cropY < 0 || in.cropX + in.outW > in.w || in.cropY + in.outH > in.h) return nullptr;
    if ((in.cropX & 1) || (in.cropY & 1) || in.cfa < 0 || in.cfa > 3) return nullptr;
    RawPipe* p = new RawPipe();
    p->in = in;
    p->w = in.w; p->h = in.h; p->qw = in.w / 2; p->qh = in.h / 2;
    p->acc.assign((size_t)in.w * in.h, 0.f);
    p->wsum.assign((size_t)p->qw * p->qh, 0.f);
    p->pw[0] = p->qw; p->ph[0] = p->qh;
    for (int l = 1; l < LEVELS; l++) { p->pw[l] = (p->pw[l - 1] + 1) / 2; p->ph[l] = (p->ph[l - 1] + 1) / 2; }
    for (int i = 0; i < RAW_P_COUNT; i++) p->prm[i] = 0.f;
    return p;
}

void raw_destroy(RawPipe* p) { delete p; }
void raw_enable_sr(RawPipe* p, int on) {
    if (p && !p->prepared && p->nFrames == 0 && p->cand.empty()) p->srOn = on != 0;
}
int raw_frames(const RawPipe* p) { return p ? (p->nFrames + (int)p->cand.size()) : 0; }

void raw_set_shading(RawPipe* p, const float* g, int mw, int mh) {
    if (!p || !g || mw < 2 || mh < 2) return;
    p->shade.assign(g, g + (size_t)4 * mw * mh);
    p->sw = mw; p->sh = mh;
}

static int addFrameImpl(RawPipe* p, const uint16_t* data, int strideBytes, float expGain, float motionW, const float* black4) {
    if (!p || !data || p->prepared) return -1;
    if (strideBytes < p->w * 2) return -2;
    const size_t strideEl = (size_t)strideBytes / 2;
    const int w = p->w, qw = p->qw, qh = p->qh;
    float black[4];
    for (int k = 0; k < 4; k++) black[k] = black4 ? black4[k] : p->in.black[k];
    float inv[4];
    for (int k = 0; k < 4; k++) inv[k] = 1.f / std::max(1.f, p->in.white - black[k]);

    if (p->nFrames == 0) {
        // reference: initialise accumulators, build luma pyramid
        std::vector<float> L0;
        std::vector<uint8_t> clip;
        quadLuma(*p, data, strideEl, black, 1.f, L0, &clip);
        buildPyramid(*p, L0, p->pyr);
        p->refClip = clip;
        par_for(qh, [&](int qy) {
            const uint16_t* r0 = data + (size_t)(2 * qy) * strideEl;
            const uint16_t* r1 = r0 + strideEl;
            for (int qx = 0; qx < qw; qx++) {
                bool c = clip[(size_t)qy * qw + qx] != 0;
                float wt = c ? 0.f : 1.f;
                float* a0 = &p->acc[(size_t)(2 * qy) * w + 2 * qx];
                float* a1 = a0 + w;
                a0[0] = wt * (r0[2 * qx] - black[0]) * inv[0];
                a0[1] = wt * (r0[2 * qx + 1] - black[1]) * inv[1];
                a1[0] = wt * (r1[2 * qx] - black[2]) * inv[2];
                a1[1] = wt * (r1[2 * qx + 1] - black[3]) * inv[3];
                p->wsum[(size_t)qy * qw + qx] = wt;
            }
        });
        if (p->srOn) {
            p->srNum.assign((size_t)p->w * p->h, 0.f);
            p->srDen.assign((size_t)p->w * p->h, 0.f);
            float th0[4];
            for (int k = 0; k < 4; k++) th0[k] = satThresh(p->in, black, k);
            const int* cfa0 = kCfa[p->in.cfa];
            par_for(p->h, [&](int y) {
                for (int x = 0; x < p->w; x++) srAccum(p, data, strideEl, black, inv, th0, 1.f, cfa0, x, y, (float)x, (float)y, 1.f);
            });
        }
        p->nFrames = 1;
        return 0;
    }

    // ---- align to the reference
    std::vector<float> L0;
    std::vector<uint8_t> clip;
    quadLuma(*p, data, strideEl, black, expGain, L0, &clip);
    // bright / bracketed frames: keep the alignment luma bounded so clipped highlights do not dominate
    for (auto& v : L0) v = std::min(v, 1.2f);
    std::vector<float> cur[LEVELS];
    buildPyramid(*p, L0, cur);
    Field fld[LEVELS];
    alignLevels(*p, cur, fld);
    const Field& f0 = fld[0];

    // per-quad offsets from the tile field (bilinear, rounded)
    std::vector<int> cx0(qw), cx1(qw), ry0(qh), ry1(qh);
    std::vector<float> fxv(qw), fyv(qh);
    for (int x = 0; x < qw; x++) {
        float u = ((float)x - TILE * 0.5f + 0.5f) / TILE;
        int i = (int)std::floor(u);
        fxv[x] = u - i;
        cx0[x] = clampi(i, 0, f0.tw - 1); cx1[x] = clampi(i + 1, 0, f0.tw - 1);
    }
    for (int y = 0; y < qh; y++) {
        float v = ((float)y - TILE * 0.5f + 0.5f) / TILE;
        int i = (int)std::floor(v);
        fyv[y] = v - i;
        ry0[y] = clampi(i, 0, f0.th - 1); ry1[y] = clampi(i + 1, 0, f0.th - 1);
    }
    auto offAt = [&](int qx, int qy, int& ox, int& oy) {
        const float fx = fxv[qx], fy = fyv[qy];
        const size_t a = (size_t)ry0[qy] * f0.tw + cx0[qx], b = (size_t)ry0[qy] * f0.tw + cx1[qx];
        const size_t c = (size_t)ry1[qy] * f0.tw + cx0[qx], d = (size_t)ry1[qy] * f0.tw + cx1[qx];
        float vx = (1 - fy) * ((1 - fx) * f0.ox[a] + fx * f0.ox[b]) + fy * ((1 - fx) * f0.ox[c] + fx * f0.ox[d]);
        float vy = (1 - fy) * ((1 - fx) * f0.oy[a] + fx * f0.oy[b]) + fy * ((1 - fx) * f0.oy[c] + fx * f0.oy[d]);
        ox = (int)std::lround(vx); oy = (int)std::lround(vy);
    };
    // sub-pixel registration (tile residuals) for the super-resolution plane
    std::vector<float> rdx, rdy;
    if (p->srOn && !p->srNum.empty()) tileResidual(*p, L0, f0, rdx, rdy);
    auto offF = [&](int qx, int qy, float& vx, float& vy) {
        const float fx = fxv[qx], fy = fyv[qy];
        const size_t a = (size_t)ry0[qy] * f0.tw + cx0[qx], b = (size_t)ry0[qy] * f0.tw + cx1[qx];
        const size_t c = (size_t)ry1[qy] * f0.tw + cx0[qx], d = (size_t)ry1[qy] * f0.tw + cx1[qx];
        const float ax = f0.ox[a] + rdx[a], bx = f0.ox[b] + rdx[b], cxx = f0.ox[c] + rdx[c], dxx = f0.ox[d] + rdx[d];
        const float ay = f0.oy[a] + rdy[a], by = f0.oy[b] + rdy[b], cyy = f0.oy[c] + rdy[c], dyy = f0.oy[d] + rdy[d];
        vx = (1 - fy) * ((1 - fx) * ax + fx * bx) + fy * ((1 - fx) * cxx + fx * dxx);
        vy = (1 - fy) * ((1 - fx) * ay + fx * by) + fy * ((1 - fx) * cyy + fx * dyy);
    };

    // pass A: aligned luma + validity -> diff map
    std::vector<float> D2((size_t)qw * qh, 0.f);
    std::vector<uint8_t> valid((size_t)qw * qh, 0);
    float th[4];
    for (int k = 0; k < 4; k++) th[k] = satThresh(p->in, black, k);
    par_for(qh, [&](int qy) {
        for (int qx = 0; qx < qw; qx++) {
            int ox, oy; offAt(qx, qy, ox, oy);
            int sx = qx + ox, sy = qy + oy;
            const size_t q = (size_t)qy * qw + qx;
            if (sx < 0 || sy < 0 || sx >= qw || sy >= qh) continue;
            if (clip[(size_t)sy * qw + sx]) continue;
            valid[q] = 1;
            float lk = L0[(size_t)sy * qw + sx];
            float dd = lk - p->pyr[0][q];
            D2[q] = dd * dd;
        }
    });
    {
        std::vector<float> sm((size_t)qw * qh);
        boxblur(D2.data(), sm.data(), qw, qh, 1);
        D2.swap(sm);
    }
    // pass B: merge
    const float S = std::max(1e-7f, p->in.noiseS), O = std::max(1e-9f, p->in.noiseO);
    const float g = std::max(0.05f, expGain);
    const float mw = clampf(motionW, 0.f, 1.f);
    par_for(qh, [&](int qy) {
        for (int qx = 0; qx < qw; qx++) {
            const size_t q = (size_t)qy * qw + qx;
            if (!valid[q]) continue;
            int ox, oy; offAt(qx, qy, ox, oy);
            const int sx = qx + ox, sy = qy + oy;
            const float x = std::max(p->pyr[0][q], 1e-4f);
            const float varRef = (S * x + O) * 0.25f;
            const float varK = (g * S * x + g * g * O) * 0.25f;
            const float t = D2[q] / ((varRef + varK) * 2.5f + 1e-9f);
            float wgt = (t <= 1.f || p->refClip[q]) ? 1.f : std::exp(-(t - 1.f) * 0.9f);
            wgt *= (varRef / varK) * mw;
            if (wgt < 1e-4f) continue;
            const uint16_t* r0 = data + (size_t)(2 * sy) * strideEl + 2 * sx;
            const uint16_t* r1 = r0 + strideEl;
            float* a0 = &p->acc[(size_t)(2 * qy) * w + 2 * qx];
            float* a1 = a0 + w;
            a0[0] += wgt * g * (r0[0] - black[0]) * inv[0];
            a0[1] += wgt * g * (r0[1] - black[1]) * inv[1];
            a1[0] += wgt * g * (r1[0] - black[2]) * inv[2];
            a1[1] += wgt * g * (r1[1] - black[3]) * inv[3];
            p->wsum[q] += wgt;
            if (p->srOn && !p->srNum.empty() && !rdx.empty()) {
                float vx, vy;
                offF(qx, qy, vx, vy);
                const int* cfaS = kCfa[p->in.cfa];
                for (int j = 0; j < 2; j++)
                    for (int i = 0; i < 2; i++) {
                        const int x = 2 * qx + i, y = 2 * qy + j;
                        srAccum(p, data, strideEl, black, inv, th, g, cfaS, x, y, (float)x + 2.f * vx, (float)y + 2.f * vy, wgt);
                    }
            }
        }
    });
    p->nFrames++;
    return 0;
}


// ---- reference selection: sharpness (mean abs gradient of the quad luma) x gyro weight, exposure must match the first frame
static float frameSharpness(RawPipe* p, const uint16_t* d, float gain, const float* black) {
    std::vector<float> L;
    quadLuma(*p, d, (size_t)p->w, black, gain, L, nullptr);
    const int qw = p->qw, qh = p->qh;
    double g = 0, m = 0; size_t c = 0;
    for (int y = 0; y + 2 < qh; y += 2)
        for (int x = 0; x + 2 < qw; x += 2) {
            float v = L[(size_t)y * qw + x];
            g += std::fabs(L[(size_t)y * qw + x + 2] - v) + std::fabs(L[(size_t)(y + 2) * qw + x] - v);
            m += v; c++;
        }
    if (!c) return 0.f;
    return (float)(g / (m + 1e-6));
}

static void resolveRef(RawPipe* p) {
    if (p->refChosen || p->cand.empty()) return;
    int best = 0; float bestScore = -1.f;
    for (size_t i = 0; i < p->cand.size(); i++) {
        auto& c = p->cand[i];
        float rel = c.gain / p->cand[0].gain;
        if (rel < 0.7f || rel > 1.4f) continue;           // never pick an under/over exposed bracket frame as reference
        float sc = frameSharpness(p, c.data.data(), 1.f, c.black) * (0.25f + 0.75f * clampf(c.mw, 0.f, 1.f));
        if (sc > bestScore) { bestScore = sc; best = (int)i; }
    }
    p->refChosen = true;
    const float g0 = p->cand[best].gain;
    // reference first, then the rest with exposure gains relative to the reference
    addFrameImpl(p, p->cand[best].data.data(), p->w * 2, 1.f, 1.f, p->cand[best].black);
    for (size_t i = 0; i < p->cand.size(); i++) {
        if ((int)i == best) continue;
        auto& c = p->cand[i];
        addFrameImpl(p, c.data.data(), p->w * 2, c.gain / g0, c.mw, c.black);
    }
    p->cand.clear(); p->cand.shrink_to_fit();
}

int raw_add_frame(RawPipe* p, const uint16_t* data, int strideBytes, float expGain, float motionW, const float* black4) {
    if (!p || !data || p->prepared) return -1;
    if (strideBytes < p->w * 2) return -2;
    if (p->refChosen) return addFrameImpl(p, data, strideBytes, expGain, motionW, black4);
    RawPipe::Cand c;
    c.data.resize((size_t)p->w * p->h);
    const size_t strideEl = (size_t)strideBytes / 2;
    for (int y = 0; y < p->h; y++) std::memcpy(&c.data[(size_t)y * p->w], data + (size_t)y * strideEl, sizeof(uint16_t) * (size_t)p->w);
    c.gain = expGain; c.mw = motionW;
    for (int k = 0; k < 4; k++) c.black[k] = black4 ? black4[k] : p->in.black[k];
    p->cand.push_back(std::move(c));
    if (p->cand.size() >= 3) resolveRef(p);
    return 0;
}

// ======================================================================== finalise + scene analysis
namespace {

inline float shadeGainAt(const RawPipe& p, int k, float u, float v) {
    // u,v in grid units [0, sw-1] / [0, sh-1]
    const int mw = p.sw, mh = p.sh;
    int i = clampi((int)u, 0, mw - 2), j = clampi((int)v, 0, mh - 2);
    float fx = clampf(u - i, 0.f, 1.f), fy = clampf(v - j, 0.f, 1.f);
    const float* c = p.shade.data() + (size_t)k * mw * mh;
    float a = c[(size_t)j * mw + i] * (1 - fx) + c[(size_t)j * mw + i + 1] * fx;
    float b = c[(size_t)(j + 1) * mw + i] * (1 - fx) + c[(size_t)(j + 1) * mw + i + 1] * fx;
    return a * (1 - fy) + b * fy;
}

inline float acesFilm(float x) {
    float y = (x * (2.51f * x + 0.03f)) / (x * (2.43f * x + 0.59f) + 0.14f);
    return clampf(y, 0.f, 1.f);
}

inline float encodeSrgb(const RawPipe& p, float v) {
    v = clampf(v, 0.f, 1.f) * 4096.f;
    int i = std::min(4095, (int)v);
    float f = v - (float)i;
    return p.srgbLut[i] + (p.srgbLut[i + 1] - p.srgbLut[i]) * f;
}

inline int mirror(int i, int n) {
    if (i < 0) i = -i;
    if (i >= n) i = 2 * (n - 1) - i;
    return clampi(i, 0, n - 1);
}

void matMul(const float* a, const float* b, float* o) {
    float t[9];
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < 3; c++) t[r * 3 + c] = a[r * 3] * b[c] + a[r * 3 + 1] * b[3 + c] + a[r * 3 + 2] * b[6 + c];
    std::memcpy(o, t, sizeof(t));
}
bool matInv(const float* m, float* o) {
    double a = m[0], b = m[1], c = m[2], d = m[3], e = m[4], f = m[5], g = m[6], h = m[7], i = m[8];
    double A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
    double det = a * A + b * B + c * C;
    if (std::fabs(det) < 1e-12) return false;
    double id = 1.0 / det;
    o[0] = (float)(A * id); o[1] = (float)(-(b * i - c * h) * id); o[2] = (float)((b * f - c * e) * id);
    o[3] = (float)(B * id); o[4] = (float)((a * i - c * g) * id); o[5] = (float)(-(a * f - c * d) * id);
    o[6] = (float)(C * id); o[7] = (float)(-(a * h - b * g) * id); o[8] = (float)((a * e - b * d) * id);
    return true;
}
void matVec(const float* m, const float* v, float* o) {
    float t0 = m[0] * v[0] + m[1] * v[1] + m[2] * v[2];
    float t1 = m[3] * v[0] + m[4] * v[1] + m[5] * v[2];
    float t2 = m[6] * v[0] + m[7] * v[1] + m[8] * v[2];
    o[0] = t0; o[1] = t1; o[2] = t2;
}
float illuminantCct(int e) {
    switch (e) {
        case 17: return 2856.f;  case 18: return 4874.f;  case 19: return 6774.f;  case 20: return 5503.f;
        case 21: return 6504.f;  case 22: return 7504.f;  case 23: return 5003.f;  case 24: return 3200.f;
        case 1: case 4: case 9: return 5500.f;  case 2: return 4200.f;  case 3: return 2850.f;
        case 10: return 6500.f;  case 11: return 7500.f;  case 12: return 6400.f;  case 13: return 5000.f;
        case 14: return 4150.f;  case 15: return 3500.f;
        default: return 5000.f;
    }
}
void lerpMat(const float* m1, const float* m2, float a, float* o) { for (int i = 0; i < 9; i++) o[i] = a * m1[i] + (1.f - a) * m2[i]; }

const float kXyzD50ToSrgb[9] = {3.1338561f, -1.6168667f, -0.4906146f, -0.9787684f, 1.9161415f, 0.0334540f, 0.0719453f, -0.2289914f, 1.4052427f};

}  // namespace

int raw_color_calib(const float* fm1, const float* fm2, const float* cm1, const float* cm2, const float* cc1, const float* cc2,
                    int ill1, int ill2, const float* neutral, float* wb, float* ccm, float* cctOut) {
    const float I3[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
    float n[3] = {neutral ? neutral[0] : 1.f, neutral ? neutral[1] : 1.f, neutral ? neutral[2] : 1.f};
    for (int i = 0; i < 3; i++) if (!(n[i] > 1e-4f)) n[i] = 1.f;
    float ng = n[1];
    n[0] /= ng; n[2] /= ng; n[1] = 1.f;
    wb[0] = 1.f / n[0]; wb[1] = 1.f; wb[2] = 1.f / n[2];

    float T1 = illuminantCct(ill1), T2 = illuminantCct(ill2);
    const float *F1 = fm1, *F2 = fm2, *C1 = cm1, *C2 = cm2, *K1 = cc1, *K2 = cc2;
    if (!F2) F2 = F1;
    if (!C2) C2 = C1;
    if (!K2) K2 = K1;
    if (T1 > T2) { std::swap(T1, T2); std::swap(F1, F2); std::swap(C1, C2); std::swap(K1, K2); }
    float cm1e[9], cm2e[9];
    if (C1) { if (K1) matMul(K1, C1, cm1e); else std::memcpy(cm1e, C1, sizeof(cm1e)); }
    if (C2) { if (K2) matMul(K2, C2, cm2e); else std::memcpy(cm2e, C2, sizeof(cm2e)); }

    float T = 5000.f;
    auto alphaFor = [&](float t) {
        if (T2 - T1 < 1.f) return 1.f;
        return clampf((1.f / t - 1.f / T2) / (1.f / T1 - 1.f / T2), 0.f, 1.f);
    };
    if (C1) {
        for (int it = 0; it < 12; it++) {
            float cm[9], inv[9], xyz[3];
            lerpMat(cm1e, C2 ? cm2e : cm1e, alphaFor(T), cm);
            if (!matInv(cm, inv)) break;
            matVec(inv, n, xyz);
            float s = xyz[0] + xyz[1] + xyz[2];
            if (!(s > 1e-8f)) break;
            float x = xyz[0] / s, y = xyz[1] / s;
            float nn = (x - 0.3320f) / (0.1858f - y);
            float t = 449.f * nn * nn * nn + 3525.f * nn * nn + 6823.3f * nn + 5520.33f;
            if (!(t > 1500.f && t < 12000.f)) break;
            if (std::fabs(t - T) < 5.f) { T = t; break; }
            T = t;
        }
    }
    if (cctOut) *cctOut = T;
    const float a = alphaFor(T);
    if (F1) {
        float fm[9];
        lerpMat(F1, F2 ? F2 : F1, a, fm);
        matMul(kXyzD50ToSrgb, fm, ccm);
        return 1;
    }
    if (C1) {
        float cm[9], inv[9], xyzw[3];
        lerpMat(cm1e, C2 ? cm2e : cm1e, a, cm);
        if (matInv(cm, inv)) {
            // camera(wb) = diag(n)^-1 * camera;  XYZ = inv(CM) * diag(n) * camera_wb, then scale white to D50
            float dn[9] = {n[0], 0, 0, 0, n[1], 0, 0, 0, n[2]};
            float tmp[9];
            matMul(inv, dn, tmp);
            matVec(inv, n, xyzw);
            const float d50[3] = {0.9642f, 1.f, 0.8249f};
            for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) tmp[r * 3 + c] *= d50[r] / std::max(1e-6f, xyzw[r]);
            matMul(kXyzD50ToSrgb, tmp, ccm);
            return 0;
        }
    }
    std::memcpy(ccm, I3, sizeof(I3));
    return 0;
}

float raw_info(const RawPipe* p, int what) {
    if (!p) return 0.f;
    switch (what) {
        case 0: return p->neff;
        case 1: return p->g0;
        case 2: return p->awb[0];
        case 3: return p->awb[2];
        default: return 0.f;
    }
}

int raw_prepare(RawPipe* p, const float* params, int np) {
    if (!p) return -1;
    resolveRef(p);
    if (p->nFrames < 1) return -1;
    for (int i = 0; i < RAW_P_COUNT; i++) p->prm[i] = (params && i < np) ? params[i] : 0.f;
    const float* P = p->prm;
    const RawInit& in = p->in;
    const int w = p->w, qw = p->qw, qh = p->qh;

    if (!p->prepared) {
        double sw = 0;
        for (size_t q = 0; q < (size_t)qw * qh; q += 7) sw += p->wsum[q];
        p->neff = (float)std::max(1.0, sw / (double)(((size_t)qw * qh + 6) / 7));
        par_for(qh, [&](int qy) {
            for (int qx = 0; qx < qw; qx++) {
                float ws = p->wsum[(size_t)qy * qw + qx];
                float* a0 = &p->acc[(size_t)(2 * qy) * w + 2 * qx];
                float* a1 = a0 + w;
                if (ws <= 1e-5f) { a0[0] = a0[1] = a1[0] = a1[1] = 1.f; }
                else { float iv = 1.f / ws; a0[0] *= iv; a0[1] *= iv; a1[0] *= iv; a1[1] *= iv; }
            }
        });
        for (int l = 0; l < LEVELS; l++) { std::vector<float>().swap(p->pyr[l]); }
        std::vector<float>().swap(p->wsum);
        for (int i = 0; i <= 4096; i++) {
            float v = (float)i / 4096.f;
            p->srgbLut[i] = v <= 0.0031308f ? 12.92f * v : 1.055f * std::pow(v, 1.f / 2.4f) - 0.055f;
        }
        p->prepared = true;
    }

    // ---- low-res cells (8x8 raw px): linear sRGB means
    const int CELL = 8;
    p->lw = (in.outW + CELL - 1) / CELL; p->lh = (in.outH + CELL - 1) / CELL;
    const int lw = p->lw, lh = p->lh;
    const size_t nc = (size_t)lw * lh;
    std::vector<float> cr(nc), cg(nc), cb(nc), cy(nc);
    par_for(lh, [&](int cyi) {
        for (int cxi = 0; cxi < lw; cxi++) {
            double s[3] = {0, 0, 0}; int cnt[3] = {0, 0, 0};
            const int x0 = cxi * CELL, y0 = cyi * CELL, x1 = std::min(in.outW, x0 + CELL), y1 = std::min(in.outH, y0 + CELL);
            float sg[4] = {1, 1, 1, 1};
            if (p->sw > 1) {
                float u = ((x0 + x1) * 0.5f + in.cropX) / (float)(p->w - 1) * (p->sw - 1);
                float v = ((y0 + y1) * 0.5f + in.cropY) / (float)(p->h - 1) * (p->sh - 1);
                for (int k = 0; k < 4; k++) sg[k] = shadeGainAt(*p, k, u, v);
            }
            for (int y = y0; y < y1; y++) {
                const int ry = in.cropY + y;
                for (int x = x0; x < x1; x++) {
                    const int rx = in.cropX + x;
                    const int k = (ry & 1) * 2 + (rx & 1);
                    const int c = kCfa[in.cfa][k];
                    s[c] += p->acc[(size_t)ry * w + rx] * sg[k] * in.wb[c];
                    cnt[c]++;
                }
            }
            float v[3];
            for (int c = 0; c < 3; c++) v[c] = (float)(s[c] / std::max(1, cnt[c]));
            float o[3];
            matVec(in.ccm, v, o);
            const size_t i = (size_t)cyi * lw + cxi;
            cr[i] = std::max(0.f, o[0]); cg[i] = std::max(0.f, o[1]); cb[i] = std::max(0.f, o[2]);
        }
    });

    // ---- colour cast (conservative grey-edge style on near-neutral cells)
    p->awb[0] = p->awb[1] = p->awb[2] = 1.f;
    if (P[RAW_P_AWB] > 0.01f) {
        double sr = 0, sg2 = 0, sb = 0; size_t cntN = 0;
        for (size_t i = 0; i < nc; i++) {
            float mx = std::max(cr[i], std::max(cg[i], cb[i])), mn = std::min(cr[i], std::min(cg[i], cb[i]));
            if (mx > 0.02f && mx < 0.85f && mn > 0.62f * mx) { sr += cr[i]; sg2 += cg[i]; sb += cb[i]; cntN++; }
        }
        if (cntN > nc / 40 + 3 && sr > 0 && sb > 0) {
            float gr = (float)(sg2 / sr), gb = (float)(sg2 / sb);
            const float s = P[RAW_P_AWB] * 0.6f;
            // P_AWB > 0.6 (night / ultra night) = low-light cast correction: allow a much wider range
            const float wide = clampf((P[RAW_P_AWB] - 0.6f) / 0.4f, 0.f, 1.f);
            const float lo = 0.9f - 0.2f * wide, hi = 1.12f + 0.3f * wide;
            p->awb[0] = clampf(std::pow(gr, s), lo, hi);
            p->awb[2] = clampf(std::pow(gb, s), lo, hi);
        }
    }
    const float wm = 1.f + 0.07f * clampf(P[RAW_P_WARMTH], -1.f, 1.f);
    p->awb[0] *= wm; p->awb[2] /= wm;
    double lsum = 0;
    for (size_t i = 0; i < nc; i++) {
        cr[i] *= p->awb[0]; cb[i] *= p->awb[2];
        cy[i] = 0.2126f * cr[i] + 0.7152f * cg[i] + 0.0722f * cb[i];
        lsum += std::log((double)cy[i] + 2e-3);
    }
    // ---- auto exposure (partial: the camera already metered the scene)
    const float gmean = (float)std::exp(lsum / (double)nc);
    const float target = 0.135f;
    p->g0 = clampf(std::pow(target / std::max(gmean, 1e-4f), 0.85f), 0.5f, 6.f) * std::exp2(P[RAW_P_EV]);

    // ---- local tone: edge-aware base of log luma
    p->lowLog.assign(nc, 0.f);
    for (size_t i = 0; i < nc; i++) p->lowLog[i] = std::log2(cy[i] * p->g0 + 1e-4f);
    std::vector<float> base(p->lowLog), eps(nc, 0.16f);
    guided(p->lowLog.data(), base.data(), eps.data(), base.data(), lw, lh, 3);
    std::vector<float> g2(base);
    guided(base.data(), g2.data(), eps.data(), base.data(), lw, lh, 6);
    const float pivot = std::log2(0.135f);
    p->lowGain.assign(nc, 0.f);
    const float shd = clampf(P[RAW_P_SHADOWS], 0.f, 1.f), hil = clampf(P[RAW_P_HIGHLIGHTS], 0.f, 1.f);
    for (size_t i = 0; i < nc; i++) {
        float b = base[i], gl = 0.f;
        if (b < pivot) gl = std::min(2.4f, shd * 0.6f * (pivot - b));
        else gl = -std::min(2.0f, hil * 0.55f * (b - pivot));
        p->lowGain[i] = gl;
    }
    // ---- auto levels (dehaze) from the tone-mapped low-res luma
    int hist[256] = {0};
    for (size_t i = 0; i < nc; i++) {
        float y = cy[i] * p->g0 * std::exp2(p->lowGain[i]);
        float e = encodeSrgb(*p, acesFilm(y));
        hist[clampi((int)(e * 255.f), 0, 255)]++;
    }
    size_t acc2 = 0; float lo = 0.f, hi = 1.f; bool gotLo = false;
    for (int i = 0; i < 256; i++) {
        acc2 += hist[i];
        if (!gotLo && acc2 >= nc * 0.004) { lo = i / 255.f; gotLo = true; }
        if (acc2 >= nc * 0.997) { hi = i / 255.f; break; }
    }
    const float dh = clampf(P[RAW_P_DEHAZE], 0.f, 1.f);
    p->lvlLo = clampf(lo, 0.f, 0.14f) * dh;
    p->lvlHi = 1.f - clampf(1.f - hi, 0.f, 0.12f) * dh * 0.8f;
    if (p->lvlHi - p->lvlLo < 0.5f) { p->lvlLo = 0.f; p->lvlHi = 1.f; }
    return 0;
}

// ======================================================================== develop one strip
namespace {

struct Kern { int r; float k[17]; };
Kern makeGauss(float sigma) {
    Kern g; g.r = std::min(8, (int)std::ceil(sigma * 3.f));
    float s = 0.f;
    for (int i = -g.r; i <= g.r; i++) { g.k[i + g.r] = std::exp(-(float)(i * i) / (2.f * sigma * sigma)); s += g.k[i + g.r]; }
    for (int i = 0; i < 2 * g.r + 1; i++) g.k[i] /= s;
    return g;
}
void gconv(const float* src, float* dst, float* tmp, int W, int H, const Kern& g) {
    const int r = g.r;
    for (int y = 0; y < H; y++) {
        const float* a = src + (size_t)y * W; float* b = tmp + (size_t)y * W;
        for (int x = 0; x < W; x++) {
            float s = 0.f;
            if (x >= r && x < W - r) { for (int i = -r; i <= r; i++) s += g.k[i + r] * a[x + i]; }
            else { for (int i = -r; i <= r; i++) s += g.k[i + r] * a[clampi(x + i, 0, W - 1)]; }
            b[x] = s;
        }
    }
    for (int y = 0; y < H; y++) {
        float* o = dst + (size_t)y * W;
        for (int x = 0; x < W; x++) o[x] = 0.f;
        for (int i = -r; i <= r; i++) {
            const float* b = tmp + (size_t)clampi(y + i, 0, H - 1) * W;
            const float kk = g.k[i + r];
            for (int x = 0; x < W; x++) o[x] += kk * b[x];
        }
    }
}

inline uint32_t hash32(uint32_t x) { x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x; }

}  // namespace

void raw_strip(const RawPipe* pp, int y0, int y1, uint32_t* out) {
    if (!pp || !out || !pp->prepared) return;
    const RawPipe& p = *pp;
    const RawInit& in = p.in;
    const float* P = p.prm;
    y0 = clampi(y0, 0, in.outH); y1 = clampi(y1, y0, in.outH);
    if (y1 <= y0) return;
    const int W = in.outW;
    const int oy0 = std::max(0, y0 - MARGIN), oy1 = std::min(in.outH, y1 + MARGIN);
    const int H = oy1 - oy0;
    const size_t NP = (size_t)W * H;
    const int PAD = 16, PW = W + 2 * PAD, PH = H + 2 * PAD;   // 16 = support of the residual-interpolation demosaic
    const int* cfa = kCfa[in.cfa];

    // ---- padded, shading-corrected, white-balanced mosaic
    std::vector<float> M((size_t)PW * PH);
    {
        std::vector<int> rxs(PW);
        std::vector<float> us(PW);
        for (int px = 0; px < PW; px++) { rxs[px] = mirror(in.cropX + px - PAD, p.w); us[px] = (float)rxs[px] / (float)(p.w - 1) * (float)(p.sw - 1); }
        for (int py = 0; py < PH; py++) {
            const int ry = mirror(in.cropY + oy0 + py - PAD, p.h);
            const float v = (float)ry / (float)(p.h - 1) * (float)(p.sh - 1);
            const float* src = p.acc.data() + (size_t)ry * p.w;
            float* d = M.data() + (size_t)py * PW;
            for (int px = 0; px < PW; px++) {
                const int rx = rxs[px];
                const int k = (ry & 1) * 2 + (rx & 1);
                float val = src[rx] * in.wb[cfa[k]];
                if (p.sw > 1) val *= shadeGainAt(p, k, us[px], v);
                d[px] = val;
            }
        }
    }
    // hot pixel cleanup: a pixel far above all four same-colour neighbours is a sensor defect (merging keeps it, so fix it here)
    {
        std::vector<float> fix;
        for (int py = 2; py < PH - 2; py++)
            for (int px = 2; px < PW - 2; px++) {
                const float v = M[(size_t)py * PW + px];
                const float a = M[(size_t)py * PW + px - 2], b = M[(size_t)py * PW + px + 2];
                const float c = M[(size_t)(py - 2) * PW + px], d = M[(size_t)(py + 2) * PW + px];
                const float mx = std::max(std::max(a, b), std::max(c, d));
                if (v > mx * 1.6f + 0.04f) M[(size_t)py * PW + px] = 0.25f * (a + b + c + d);
            }
    }
    // ---- demosaic: soft-weighted directional green + guided-filter residual interpolation for R/B + one green refinement
    //      (demosaic.hpp; +2.8 dB CPSNR over Hamilton-Adams on real photos, also better on noisy data — see native_test/demosaic_test.cpp)
    std::vector<float> R(NP), G(NP), B(NP);
    {
        std::vector<uint8_t> col((size_t)PW * PH);
        for (int py = 0; py < PH; py++)
            for (int px = 0; px < PW; px++)
                col[(size_t)py * PW + px] = (uint8_t)cfa[(((oy0 + py - PAD) & 1) << 1) | ((px - PAD) & 1)];
        std::function<void(std::vector<float>&)> hook;
        // sub-pixel super-resolution: replace the interpolated green by the multi-frame green plane where enough frames agree
        if (!p.srNum.empty() && P[RAW_P_SR] > 0.01f) {
            hook = [&](std::vector<float>& Gp) {
                const float sstr = clampf(P[RAW_P_SR], 0.f, 1.f);
                for (int py = 0; py < PH; py++) {
                    const int ry = mirror(in.cropY + oy0 + py - PAD, p.h);
                    const float v = (float)ry / (float)(p.h - 1) * (float)(p.sh - 1);
                    for (int px = 0; px < PW; px++) {
                        const int rx = mirror(in.cropX + px - PAD, p.w);
                        const size_t si = (size_t)ry * p.w + rx;
                        const float den = p.srDen[si];
                        const float conf = sstr * clampf((den - 0.9f) / 1.5f, 0.f, 1.f);
                        if (conf <= 0.f) continue;
                        float gs = p.srNum[si] / den * in.wb[1];
                        if (p.sw > 1) {
                            int kk = ((ry & 1) << 1) | (rx & 1);
                            if (cfa[kk] != 1) kk ^= 1;
                            gs *= shadeGainAt(p, kk, (float)rx / (float)(p.w - 1) * (float)(p.sw - 1), v);
                        }
                        float& g0 = Gp[(size_t)py * PW + px];
                        const float lim = 0.35f * g0 + 0.02f;      // never stray far from the demosaic (ghost / hot pixel safety)
                        gs = clampf(gs, g0 - lim, g0 + lim);
                        g0 += conf * (gs - g0);
                    }
                }
            };
        }
        std::vector<float> Rp, Gp, Bp;
        dm::demosaic(M.data(), PW, PH, col.data(), Rp, Gp, Bp, hook, 1);
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                const size_t si = (size_t)(y + PAD) * PW + (x + PAD), i = (size_t)y * W + x;
                R[i] = std::max(0.f, Rp[si]); G[i] = std::max(0.f, Gp[si]); B[i] = std::max(0.f, Bp[si]);
            }
    }
    std::vector<float>().swap(M);

    // ---- camera -> linear sRGB, exposure + local tone gain (joint-bilateral upsampled from the low-res base)
    std::vector<float> Gt(NP);
    {
        const float* cc = in.ccm;
        const int lw = p.lw, lh = p.lh;
        par_for(H, [&](int y) {
            const float fy = ((float)(oy0 + y) + 0.5f) / 8.f - 0.5f;
            const int j0 = (int)std::floor(fy); const float wy = fy - (float)j0;
            const int jj[2] = {clampi(j0, 0, lh - 1), clampi(j0 + 1, 0, lh - 1)};
            const float wyv[2] = {1.f - wy, wy};
            for (int x = 0; x < W; x++) {
                const size_t i = (size_t)y * W + x;
                float r = cc[0] * R[i] + cc[1] * G[i] + cc[2] * B[i];
                float g = cc[3] * R[i] + cc[4] * G[i] + cc[5] * B[i];
                float b = cc[6] * R[i] + cc[7] * G[i] + cc[8] * B[i];
                r = std::max(0.f, r) * p.awb[0]; g = std::max(0.f, g); b = std::max(0.f, b) * p.awb[2];
                const float Y = 0.2126f * r + 0.7152f * g + 0.0722f * b;
                const float L = std::log2(Y * p.g0 + 1e-4f);
                const float fx = ((float)x + 0.5f) / 8.f - 0.5f;
                const int i0 = (int)std::floor(fx); const float wx = fx - (float)i0;
                const int ii[2] = {clampi(i0, 0, lw - 1), clampi(i0 + 1, 0, lw - 1)};
                const float wxv[2] = {1.f - wx, wx};
                float sw = 0.f, sg = 0.f, pg = 0.f, ps = 0.f;
                for (int a = 0; a < 2; a++)
                    for (int c2 = 0; c2 < 2; c2++) {
                        const size_t ci = (size_t)jj[a] * lw + ii[c2];
                        const float sp = wyv[a] * wxv[c2];
                        const float d = L - p.lowLog[ci];
                        const float wt = sp * std::exp(-d * d * 2.5f);
                        sw += wt; sg += wt * p.lowGain[ci];
                        ps += sp; pg += sp * p.lowGain[ci];
                    }
                const float gl = sw > 1e-4f ? sg / sw : pg / std::max(ps, 1e-6f);
                const float gain = p.g0 * std::exp2(gl);
                Gt[i] = gain;
                R[i] = r * gain; G[i] = g * gain; B[i] = b * gain;
            }
        });
    }

    // ---- noise reduction in the sqrt domain (variance stabilised): luma + chroma guided filters
    const float nrY = clampf(P[RAW_P_NR_LUMA], 0.f, 1.f), nrC = clampf(P[RAW_P_NR_CHROMA], 0.f, 1.f);
    if (nrY > 0.01f || nrC > 0.01f) {
        std::vector<float> Yu(NP), Cb(NP), Cr(NP), eps(NP), Yf(NP);
        const float S = std::max(1e-7f, in.noiseS), O = std::max(1e-9f, in.noiseO);
        const float inv4n = 2.2f / (4.f * std::max(1.f, p.neff));
        for (size_t i = 0; i < NP; i++) {
            const float ru = std::sqrt(R[i]), gu = std::sqrt(G[i]), bu = std::sqrt(B[i]);
            const float yu = 0.2126f * ru + 0.7152f * gu + 0.0722f * bu;
            Yu[i] = yu; Cb[i] = bu - yu; Cr[i] = ru - yu;
            const float Yl = 0.2126f * R[i] + 0.7152f * G[i] + 0.0722f * B[i];
            const float gt = Gt[i];
            float v = (gt * S + gt * gt * O / std::max(Yl, 1e-5f)) * inv4n;
            eps[i] = std::min(v, 0.04f);
        }
        std::vector<float> e2(NP);
        for (size_t i = 0; i < NP; i++) e2[i] = eps[i] * (nrY * 2.5f) * (nrY * 2.5f);
        guided(Yu.data(), Yu.data(), e2.data(), Yf.data(), W, H, 2);
        for (size_t i = 0; i < NP; i++) Yf[i] = Yf[i] + 0.2f * (Yu[i] - Yf[i]);
        for (size_t i = 0; i < NP; i++) e2[i] = eps[i] * (nrC * 3.5f) * (nrC * 3.5f) + 1e-7f;
        guided(Yf.data(), Cb.data(), e2.data(), Cb.data(), W, H, 5);
        guided(Yf.data(), Cr.data(), e2.data(), Cr.data(), W, H, 5);
        if (nrC > 0.01f) {
            // defringe: purple/magenta chroma sitting on a strong luma edge is lateral CA / purple fringing -> pull it back
            for (int y = 1; y < H - 1; y++)
                for (int x = 1; x < W - 1; x++) {
                    const size_t i = (size_t)y * W + x;
                    const float gx = Yf[i + 1] - Yf[i - 1], gy = Yf[i + W] - Yf[i - W];
                    const float edge = std::sqrt(gx * gx + gy * gy);
                    if (edge > 0.10f && Cb[i] > 0.01f && Cr[i] > -0.01f) {
                        const float f = 1.f - 0.65f * clampf((edge - 0.10f) / 0.25f, 0.f, 1.f) * nrC;
                        Cb[i] *= f; Cr[i] *= f;
                    }
                }
        }
        for (size_t i = 0; i < NP; i++) {
            const float yo = Yf[i];
            const float ru = std::max(0.f, yo + Cr[i]), bu = std::max(0.f, yo + Cb[i]);
            const float gu = std::max(0.f, (yo - 0.2126f * ru - 0.0722f * bu) / 0.7152f);
            R[i] = ru * ru; G[i] = gu * gu; B[i] = bu * bu;
        }
    }
    std::vector<float>().swap(Gt);

    // ---- global filmic tone, levels, contrast, colour (per pixel)
    const float sat = P[RAW_P_SATURATION] > 0.01f ? P[RAW_P_SATURATION] : 1.f;
    const float vib = clampf(P[RAW_P_VIBRANCE], 0.f, 1.f), hb = clampf(P[RAW_P_HUEBOOST], 0.f, 1.f);
    const float con = clampf(P[RAW_P_CONTRAST], 0.f, 1.f);
    const float lvLo = p.lvlLo, lvInv = 1.f / std::max(0.2f, p.lvlHi - p.lvlLo);
    std::vector<float> Yo(NP);
    par_for(H, [&](int y) {
        for (int x = 0; x < W; x++) {
            const size_t i = (size_t)y * W + x;
            float r = R[i], g = G[i], b = B[i];
            const float Y = 0.2126f * r + 0.7152f * g + 0.0722f * b;
            const float Yt = acesFilm(Y);
            const float ratio = Yt / (Y + 1e-6f);
            r *= ratio; g *= ratio; b *= ratio;
            const float m = std::max(r, std::max(g, b));
            if (m > 1.f) {
                const float k = (m - 1.f) / (m - 1.f + 0.35f);
                r += (Yt - r) * k; g += (Yt - g) * k; b += (Yt - b) * k;
                const float m2 = std::max(r, std::max(g, b));
                if (m2 > 1.f) { const float s = 1.f / m2; r *= s; g *= s; b *= s; }
            }
            r = encodeSrgb(p, r); g = encodeSrgb(p, g); b = encodeSrgb(p, b);
            r = clampf((r - lvLo) * lvInv, 0.f, 1.f); g = clampf((g - lvLo) * lvInv, 0.f, 1.f); b = clampf((b - lvLo) * lvInv, 0.f, 1.f);
            if (con > 0.001f) {
                r += con * 0.5f * (r * r * (3.f - 2.f * r) - r);
                g += con * 0.5f * (g * g * (3.f - 2.f * g) - g);
                b += con * 0.5f * (b * b * (3.f - 2.f * b) - b);
            }
            // colour: vibrance (low-chroma boost) + hue-selective pop (skies, foliage) with skin kept natural
            const float Ye = 0.2126f * r + 0.7152f * g + 0.0722f * b;
            const float mx = std::max(r, std::max(g, b)), mn = std::min(r, std::min(g, b));
            const float rel = (mx - mn) / (mx + 1e-3f);
            float mul = sat * (1.f + vib * 0.8f * (1.f - clampf(rel * 2.2f, 0.f, 1.f)));
            if (hb > 0.01f) {
                const float a = r - g, bb = 0.5f * (r + g) - b;
                const float len = std::sqrt(a * a + bb * bb);
                if (len > 0.015f) {
                    const float ca = a / len, sb = bb / len;
                    const float wB = std::exp(-3.4f * (1.f - (ca * -0.342f + sb * -0.940f)));
                    const float wG = std::exp(-3.4f * (1.f - (ca * -0.643f + sb * 0.766f)));
                    const float wS = std::exp(-3.4f * (1.f - (ca * 0.766f + sb * 0.643f)));
                    const float wR = std::exp(-3.4f * (1.f - (ca * 0.996f + sb * 0.087f)));
                    const float cw = clampf(len * 6.f, 0.f, 1.f);
                    mul *= 1.f + hb * cw * (0.30f * wB + 0.22f * wG - 0.12f * wS + 0.08f * wR);
                }
            }
            const float ym = 0.35f + 0.65f * std::sin(3.14159265f * clampf(Ye, 0.f, 1.f));
            mul = 1.f + (mul - 1.f) * ym;
            R[i] = clampf(Ye + (r - Ye) * mul, 0.f, 1.f);
            G[i] = clampf(Ye + (g - Ye) * mul, 0.f, 1.f);
            B[i] = clampf(Ye + (b - Ye) * mul, 0.f, 1.f);
            Yo[i] = 0.2126f * R[i] + 0.7152f * G[i] + 0.0722f * B[i];
        }
    });

    // ---- detail: light Richardson-Lucy deconvolution + cored unsharp + clarity (all on luma, added to RGB)
    const float dec = clampf(P[RAW_P_DECONV], 0.f, 1.f), shp = clampf(P[RAW_P_SHARPEN], 0.f, 1.f), cla = clampf(P[RAW_P_CLARITY], 0.f, 1.f);
    if (dec > 0.01f || shp > 0.01f || cla > 0.01f) {
        std::vector<float> Yd(Yo), A(NP), Bf(NP), T(NP);
        if (dec > 0.01f) {
            const Kern g1 = makeGauss(1.0f);
            std::vector<float> est(Yo);
            for (int it = 0; it < 2; it++) {
                gconv(est.data(), A.data(), T.data(), W, H, g1);
                for (size_t i = 0; i < NP; i++) A[i] = Yo[i] / (A[i] + 0.003f);
                gconv(A.data(), Bf.data(), T.data(), W, H, g1);
                for (size_t i = 0; i < NP; i++) est[i] = clampf(est[i] * clampf(Bf[i], 0.7f, 1.4f), 0.f, 1.1f);
            }
            for (size_t i = 0; i < NP; i++) {
                const float mask = clampf((Yo[i] - 0.03f) * 12.f, 0.f, 1.f);
                Yd[i] = Yo[i] + dec * mask * (est[i] - Yo[i]);
            }
        }
        std::vector<float> Ys(Yd);
        if (shp > 0.01f) {
            const Kern g2 = makeGauss(1.6f);
            gconv(Yd.data(), A.data(), T.data(), W, H, g2);
            const float amount = 0.4f + 1.6f * shp;
            const float t2 = 0.004f * 0.004f;
            for (size_t i = 0; i < NP; i++) {
                const float d = Yd[i] - A[i];
                const float dc = d * (d * d / (d * d + t2));
                float add = amount * dc;
                add = add / (1.f + std::fabs(add) * 6.f);
                Ys[i] = Yd[i] + add;
            }
        }
        if (cla > 0.01f) {
            std::vector<float> big(Ys);
            for (int k = 0; k < 3; k++) boxblur(big.data(), big.data(), W, H, 6);
            for (size_t i = 0; i < NP; i++) {
                float d = clampf(Ys[i] - big[i], -0.25f, 0.25f);
                const float mm = 1.f - (2.f * Ys[i] - 1.f) * (2.f * Ys[i] - 1.f);
                Ys[i] += cla * 0.6f * d * mm;
            }
        }
        for (size_t i = 0; i < NP; i++) {
            const float dlt = Ys[i] - Yo[i];
            R[i] = clampf(R[i] + dlt, 0.f, 1.f); G[i] = clampf(G[i] + dlt, 0.f, 1.f); B[i] = clampf(B[i] + dlt, 0.f, 1.f);
        }
    }

    // ---- pack (triangular dither)
    for (int y = y0; y < y1; y++) {
        const int ly = y - oy0;
        uint32_t* o = out + (size_t)(y - y0) * W;
        for (int x = 0; x < W; x++) {
            const size_t i = (size_t)ly * W + x;
            const uint32_t h1 = hash32((uint32_t)(x * 73856093u) ^ (uint32_t)(y * 19349663u));
            const float dn = ((float)(h1 & 255u) + (float)((h1 >> 8) & 255u)) * (1.f / 256.f) - 1.f;   // ~ -1..1 triangular
            const float rr = R[i] * 255.f + dn * 0.5f, gg = G[i] * 255.f + dn * 0.5f, bb = B[i] * 255.f + dn * 0.5f;
            const uint32_t ri = (uint32_t)clampi((int)(rr + 0.5f), 0, 255), gi = (uint32_t)clampi((int)(gg + 0.5f), 0, 255), bi = (uint32_t)clampi((int)(bb + 0.5f), 0, 255);
            o[x] = 0xFF000000u | (ri << 16) | (gi << 8) | bi;
        }
    }
}
}  // namespace uc

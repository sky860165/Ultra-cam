// UltraCam native image engine (merge + denoise + tone-map + look). JNI-free so it can be unit tested on a PC.
#pragma once
#include <cstdint>

namespace uc {

struct Pipe;

// ci (ints):   0 w, 1 h, 2 wo, 3 ho, 4 n, 5 ref, 6 capRows, 7 flags, 8 sharpR, 9 midR, 10 bw, 11 bh, 12 nSlots
//   flags: 1 hdr, 2 trails, 4 doc, 8 merge, 16 local-align
// cf (floats): 0 s, 1 dn, 2 sharpAmt, 3 coreT, 4 midAmt, 5 detailB, 6 lift, 7 wbR, 8 wbB, 9 gain, 10 mergeBlurMix
// look (19):   sat vib vignette grain mono shR shG shB hiR hiG hiB wr wg wb k ev fade lo invRange(255/(hi-lo))
// Returns nullptr on invalid input.
Pipe* pipe_create(const int* ci, int nci, const float* cf, int ncf, const float* base, int nbase,
                  const float* look, int nlook, const float* sigma, const float* fw, int n);
void pipe_destroy(Pipe* p);

// Resample decoded source rows into frame slot `slot` (thread-safe for distinct slots).
// srcLen = number of uint32 elements actually available in src (bounds check).
void pipe_sample(Pipe* p, int slot, const uint32_t* src, long long srcLen, int srcRows, int yTop, float dx, float dy, int r0, int nr);
// kind: 0 single(slot=arg) 1 stack 2 hdr 3 trails(arg=1 -> first frame)
void pipe_merge(Pipe* p, int kind, int nr, int arg);
void pipe_post(Pipe* p, int r0, int nr);
void pipe_finish(Pipe* p, int r0, int y0, int y1, uint32_t* out, long long outLen);

// Windowed normalised cross-correlation search (returns best dx,dy in outXY).
void ncc_search(const float* a, const float* b, int w, int h, const int* win, int cx, int cy, int rad, int step, int* outXY);

}  // namespace uc

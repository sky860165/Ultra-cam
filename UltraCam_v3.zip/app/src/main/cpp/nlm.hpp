// UltraCam final-photo luma denoiser: non-local means (5x5 patches, (2R+1)^2 search) on luma, edge-adaptive detail re-injection,
// applied to ARGB pixels in place. Header-only, JNI-free (PC-testable: native_test/nlm_test.cpp).
//
// Why: after the merge the remaining grain is low-amplitude luma noise (sigma ~2-3 / 255) that a box / guided filter cannot remove
// without smearing hair, beard and skin texture. NLM averages only pixels whose *neighbourhood* matches, so edges and texture survive.
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <thread>
#include <vector>

namespace uc {
namespace nlm {

// Immerkaer fast noise estimate (luma, 0..255 scale). Samples every `step` rows.
inline float estimateSigma(const uint32_t* argb, int w, int h, int step = 4) {
    if (w < 8 || h < 8) return 0.f;
    double acc = 0; long long n = 0;
    auto Y = [&](int x, int y) -> float {
        const uint32_t p = argb[(size_t)y * w + x];
        return 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
    };
    for (int y = 1; y < h - 1; y += step)
        for (int x = 1; x < w - 1; x += 2) {
            const float v = 4.f * Y(x, y) - 2.f * (Y(x - 1, y) + Y(x + 1, y) + Y(x, y - 1) + Y(x, y + 1)) +
                            (Y(x - 1, y - 1) + Y(x + 1, y - 1) + Y(x - 1, y + 1) + Y(x + 1, y + 1));
            acc += std::fabs(v); n++;
        }
    if (n == 0) return 0.f;
    return (float)(acc * 1.2533141 / (6.0 * (double)n));      // sqrt(pi/2) / 6
}

// Patch-distance noise level: the 10th percentile of the 5x5 mean squared difference between a pixel and a nearby pixel is what pure noise
// produces (2*sigma_eff^2), whatever the spatial correlation of the grain is (a plain Immerkaer sigma under-estimates correlated grain).
inline float patchNoiseC(const std::vector<float>& Y, int w, int h, int R) {
    std::vector<float> ds;
    uint32_t rs = 12345u;
    for (int y = 6; y < h - 6; y += 5)
        for (int x = 6; x < w - 6; x += 5) {
            rs = rs * 1664525u + 1013904223u;
            int dx = (int)((rs >> 8) % (uint32_t)(2 * R + 1)) - R, dy = (int)((rs >> 18) % (uint32_t)(2 * R + 1)) - R;
            if (dx == 0 && dy == 0) dx = 1;
            const int qx = std::min(w - 3, std::max(2, x + dx)), qy = std::min(h - 3, std::max(2, y + dy));
            float s = 0.f;
            for (int j = -2; j <= 2; j++)
                for (int i = -2; i <= 2; i++) { const float t = Y[(size_t)(y + j) * w + x + i] - Y[(size_t)(qy + j) * w + qx + i]; s += t * t; }
            ds.push_back(s * (1.f / 25.f));
        }
    if (ds.size() < 50) return 0.f;
    const size_t k = ds.size() / 10;
    std::nth_element(ds.begin(), ds.begin() + k, ds.end());
    return ds[k];
}

// noise level (c2) of an ARGB region, to be shared by all strips of one photo
inline float noiseC2(const uint32_t* argb, int w, int h, int R) {
    std::vector<float> Y((size_t)w * h);
    for (size_t i = 0; i < Y.size(); i++) {
        const uint32_t p = argb[i];
        Y[i] = 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
    }
    return patchNoiseC(Y, w, h, R);
}

// strength: 0..1. searchR: 2 or 3. keepDetail: 0..1, how much of the removed high-amplitude (real detail) is put back.
inline void denoiseArgb(uint32_t* argb, int w, int h, float strength, int searchR, float keepDetail, float c2Override = 0.f) {
    if (w < 16 || h < 16 || strength < 0.02f) return;
    const size_t N = (size_t)w * h;
    std::vector<float> Y(N), Cbs, Crs;                  // Y 0..255
    for (size_t i = 0; i < N; i++) {
        const uint32_t p = argb[i];
        Y[i] = 0.299f * ((p >> 16) & 255) + 0.587f * ((p >> 8) & 255) + 0.114f * (p & 255);
    }
    std::vector<float> out(N);
    const int R = searchR, PR = 2, M = R + PR + 1;
    const float c2 = c2Override > 0.f ? c2Override : patchNoiseC(Y, w, h, R);   // = 2 * sigma_eff^2 (strips of one photo share one value)
    if (c2 < 1.2f) return;                                  // clean photo: nothing to do
    const float sigma = std::sqrt(0.5f * c2);
    const float inv_h2 = 1.f / (c2 * (0.10f + 0.75f * strength));
    static float lut[1025]; static std::atomic<int> lutInit(0);
    if (!lutInit.load()) { for (int i = 0; i < 1024; i++) lut[i] = std::exp(-(float)i / 128.f); lut[1024] = 0.f; lutInit.store(1); }

    const int BR = 48;                                   // rows per block
    const int nb = (h + BR - 1) / BR;
    std::atomic<int> next(0);
    auto worker = [&]() {
        std::vector<float> d2, tmp, acc, ws, mx;
        for (;;) {
            const int b = next.fetch_add(1);
            if (b >= nb) break;
            const int y0 = b * BR, y1 = std::min(h, y0 + BR);
            const int ya = std::max(0, y0 - M), yb = std::min(h, y1 + M);
            const int hs = yb - ya;
            d2.assign((size_t)w * hs, 0.f); tmp.assign((size_t)w * hs, 0.f);
            acc.assign((size_t)w * (y1 - y0), 0.f); ws.assign((size_t)w * (y1 - y0), 0.f); mx.assign((size_t)w * (y1 - y0), 0.f);
            for (int dy = -R; dy <= R; dy++)
                for (int dx = -R; dx <= R; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    // squared difference of Y(x,y) and Y(x+dx,y+dy) on the strip (clamped coordinates)
                    for (int y = ya; y < yb; y++) {
                        const int qy = std::min(h - 1, std::max(0, y + dy));
                        const float* a = &Y[(size_t)y * w];
                        const float* q = &Y[(size_t)qy * w];
                        float* d = &d2[(size_t)(y - ya) * w];
                        for (int x = 0; x < w; x++) {
                            const int qx = std::min(w - 1, std::max(0, x + dx));
                            const float t = a[x] - q[qx];
                            d[x] = t * t;
                        }
                    }
                    // box (2*PR+1)^2 mean, separable
                    for (int y = 0; y < hs; y++) {
                        const float* d = &d2[(size_t)y * w];
                        float* t = &tmp[(size_t)y * w];
                        float run = 0.f;
                        for (int x = 0; x <= PR && x < w; x++) run += d[x];
                        for (int x = 0; x < w; x++) {
                            t[x] = run;
                            const int add = x + PR + 1, sub = x - PR;
                            if (add < w) run += d[add];
                            if (sub >= 0) run -= d[sub];
                        }
                    }
                    const float norm = 1.f / (float)((2 * PR + 1) * (2 * PR + 1));
                    for (int y = y0; y < y1; y++) {
                        const int ly = y - ya;
                        for (int x = 0; x < w; x++) {
                            float s = 0.f;
                            for (int k = -PR; k <= PR; k++) {
                                const int yy = std::min(hs - 1, std::max(0, ly + k));
                                s += tmp[(size_t)yy * w + x];
                            }
                            const float D = s * norm;
                            const float t = std::max(0.f, D - c2) * inv_h2;
                            const int li = (int)std::min(1024.f, t * 128.f);
                            const float wt = lut[li];
                            const size_t o = (size_t)(y - y0) * w + x;
                            const int qx = std::min(w - 1, std::max(0, x + dx)), qy = std::min(h - 1, std::max(0, y + dy));
                            acc[o] += wt * Y[(size_t)qy * w + qx];
                            ws[o] += wt;
                            if (wt > mx[o]) mx[o] = wt;
                        }
                    }
                }
            for (int y = y0; y < y1; y++)
                for (int x = 0; x < w; x++) {
                    const size_t o = (size_t)(y - y0) * w + x, i = (size_t)y * w + x;
                    const float c = std::max(mx[o], 0.05f);
                    out[i] = (acc[o] + c * Y[i]) / (ws[o] + c);
                }
        }
    };
    int nt = (int)std::min(6u, std::max(2u, std::thread::hardware_concurrency()));
    std::vector<std::thread> th;
    for (int k = 1; k < nt; k++) th.emplace_back(worker);
    worker();
    for (auto& t : th) t.join();

    // detail re-injection: differences well above the noise are real texture -> give part of them back
    const float t0 = 1.6f * sigma, t1 = 4.5f * sigma;
    for (size_t i = 0; i < N; i++) {
        const float d = Y[i] - out[i];
        const float a = std::fabs(d);
        float m = (a - t0) / (t1 - t0);
        m = m < 0.f ? 0.f : (m > 1.f ? 1.f : m);
        const float yn = out[i] + d * (m * m * (3.f - 2.f * m)) * keepDetail;
        const float dl = yn - Y[i];
        const uint32_t p = argb[i];
        int r = (int)(((p >> 16) & 255) + dl + 0.5f), g = (int)(((p >> 8) & 255) + dl + 0.5f), bl = (int)((p & 255) + dl + 0.5f);
        r = r < 0 ? 0 : (r > 255 ? 255 : r); g = g < 0 ? 0 : (g > 255 ? 255 : g); bl = bl < 0 ? 0 : (bl > 255 ? 255 : bl);
        argb[i] = (p & 0xFF000000u) | ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)bl;
    }
}

}  // namespace nlm
}  // namespace uc

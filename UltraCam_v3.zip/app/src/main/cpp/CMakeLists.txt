cmake_minimum_required(VERSION 3.18.1)
project(ultracam_native CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(ultracam_native SHARED jni_bridge.cpp engine.cpp)

# -O3 + fast-math lets clang auto-vectorise the per-pixel loops to NEON (4 pixels per instruction)
target_compile_options(ultracam_native PRIVATE
    -O3 -ffast-math -fno-exceptions -fno-rtti -fvisibility=hidden -Wall)
set_target_properties(ultracam_native PROPERTIES CXX_VISIBILITY_PRESET hidden)
target_compile_definitions(ultracam_native PRIVATE)
# JNI entry points are exported through JNIEXPORT
target_link_options(ultracam_native PRIVATE -Wl,-z,max-page-size=16384 -Wl,--gc-sections)

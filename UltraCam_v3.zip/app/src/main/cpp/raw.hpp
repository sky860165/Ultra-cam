// UltraCam RAW engine: Bayer-domain burst merge (pyramid tile alignment) + develop (demosaic, colour, local tone, NR, deconvolution).
// JNI-free so it can be tested on a PC.
#pragma once
#include <cstdint>

namespace uc {

struct RawPipe;

struct RawInit {
    int w, h;                 // raw buffer size (even)
    int cfa;                  // 0 RGGB, 1 GRBG, 2 GBRG, 3 BGGR  (android.sensor.info.colorFilterArrangement)
    int cropX, cropY;         // output window inside the raw buffer (even)
    int outW, outH;           // output size (even)
    float black[4];           // black level per 2x2 position, raster order (x fast)
    float white;              // white level
    float wb[3];              // R,G,B gains (G == 1) applied before demosaic
    float ccm[9];             // white-balanced camera RGB -> linear sRGB (row major)
    float noiseS, noiseO;     // noise model var = S*x + O (x normalised 0..1)
};

RawPipe* raw_create(const RawInit& in);
void raw_destroy(RawPipe* p);

// Lens shading gain map, 4 channels (raster position order) x mh x mw, row-major per channel: gains[(c*mh + y)*mw + x]
void raw_set_shading(RawPipe* p, const float* gains, int mw, int mh);

// Add one raw frame. First frame becomes the reference.
//   expGain  = (refExposure*refISO) / (thisExposure*thisISO)
//   motionW  = 0..1 (1 = steady) weight from the gyro
//   black4   = dynamic black level of this frame (nullable -> RawInit.black)
// returns 0 ok, <0 error
int raw_add_frame(RawPipe* p, const uint16_t* data, int strideBytes, float expGain, float motionW, const float* black4);

// params (see RAW_PARAM_* below). Finishes the merge, measures the scene and builds the tone map.
int raw_prepare(RawPipe* p, const float* params, int np);

// Render output rows [y0,y1) as ARGB (out has (y1-y0)*outW entries). Thread-safe after raw_prepare.
void raw_strip(const RawPipe* p, int y0, int y1, uint32_t* out);

int raw_frames(const RawPipe* p);
// 0 = effective frame count (mean merge weight), 1 = auto exposure gain, 2 = awb R gain, 3 = awb B gain
float raw_info(const RawPipe* p, int what);

// DNG-style colour calibration. Inputs are row-major 3x3 matrices (nullable when the device does not provide them).
//   neutral = as-shot neutral (camera RGB of a white surface)
//   ill1/ill2 = android reference illuminant enums
// Outputs: wb[3] (R,G,B gains with G == 1), ccm[9] (white-balanced camera RGB -> linear sRGB). Returns 1 when a forward matrix was used.
int raw_color_calib(const float* fm1, const float* fm2, const float* cm1, const float* cm2, const float* cc1, const float* cc2,
                    int ill1, int ill2, const float* neutral, float* wb, float* ccm, float* cctOut);

enum {
    RAW_P_EV = 0,         // exposure bias in stops
    RAW_P_SHADOWS,        // 0..1 local shadow lift
    RAW_P_HIGHLIGHTS,     // 0..1 local highlight recovery
    RAW_P_CONTRAST,       // 0..1
    RAW_P_VIBRANCE,       // 0..1
    RAW_P_SATURATION,     // 1 = neutral
    RAW_P_HUEBOOST,       // 0..1 "eye catching" blues / greens
    RAW_P_AWB,            // 0..1 strength of colour-cast correction
    RAW_P_NR_LUMA,        // 0..1
    RAW_P_NR_CHROMA,      // 0..1
    RAW_P_SHARPEN,        // 0..1
    RAW_P_DECONV,         // 0..1
    RAW_P_CLARITY,        // 0..1
    RAW_P_DEHAZE,         // 0..1 auto levels
    RAW_P_WARMTH,         // -1..1
    RAW_P_COUNT
};

}  // namespace uc

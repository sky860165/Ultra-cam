// UltraCam demosaic: soft-weighted directional green + guided-filter residual interpolation (RI) for R/B,
// with one green-refinement pass. Header-only so it can be unit-tested on the PC (native_test/demosaic_test.cpp).
//
// Input: a padded Bayer mosaic (white-balanced, linear). col[i] = 0 R / 1 G / 2 B for every pixel.
// Measured on 4 real photos (re-mosaiced, noise-free, CPSNR in sRGB): Hamilton-Adams 32.1 dB -> this 35.0 dB.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <vector>

namespace uc {
namespace dm {

inline int cl(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

// edge-clamped mean filter (radius r), out may alias in
inline void box(const float* src, float* dst, int w, int h, int r, std::vector<float>& tmp) {
    if (tmp.size() < (size_t)w * h) tmp.resize((size_t)w * h);
    for (int y = 0; y < h; y++) {
        const float* a = src + (size_t)y * w;
        float* b = tmp.data() + (size_t)y * w;
        double acc = 0;
        const int hi = std::min(r, w - 1);
        for (int x = 0; x <= hi; x++) acc += a[x];
        for (int x = 0; x < w; x++) {
            const int l = std::max(0, x - r), rr = std::min(w - 1, x + r);
            b[x] = (float)(acc / (rr - l + 1));
            if (x + r + 1 < w) acc += a[x + r + 1];
            if (x - r >= 0) acc -= a[x - r];
        }
    }
    std::vector<double> col(w, 0.0);
    const int hi = std::min(r, h - 1);
    for (int y = 0; y <= hi; y++) { const float* a = tmp.data() + (size_t)y * w; for (int x = 0; x < w; x++) col[x] += a[x]; }
    for (int y = 0; y < h; y++) {
        const int l = std::max(0, y - r), rr = std::min(h - 1, y + r);
        const double inv = 1.0 / (rr - l + 1);
        float* o = dst + (size_t)y * w;
        for (int x = 0; x < w; x++) o[x] = (float)(col[x] * inv);
        if (y + r + 1 < h) { const float* a = tmp.data() + (size_t)(y + r + 1) * w; for (int x = 0; x < w; x++) col[x] += a[x]; }
        if (y - r >= 0) { const float* a = tmp.data() + (size_t)(y - r) * w; for (int x = 0; x < w; x++) col[x] -= a[x]; }
    }
}

struct Work {
    int w, h; size_t n;
    std::vector<float> tmp, m, n_, mI, mP, cIP, vI, a, b, t1, t2, t3;
    Work(int w_, int h_) : w(w_), h(h_), n((size_t)w_ * h_) {
        tmp.resize(n); m.resize(n); n_.resize(n); mI.resize(n); mP.resize(n); cIP.resize(n); vI.resize(n); a.resize(n); b.resize(n);
        t1.resize(n); t2.resize(n); t3.resize(n);
    }
};

// Residual interpolation of one plane: samples P (valid where col==c), guide = full-res plane.
// out[i] = P[i] at sample sites, guided estimate + interpolated residual elsewhere.
inline void riPlane(Work& k, const float* guide, const float* P, const uint8_t* col, int c, int r, float eps, float* out) {
    const int w = k.w, h = k.h;
    const size_t n = k.n;
    for (size_t i = 0; i < n; i++) k.m[i] = col[i] == c ? 1.f : 0.f;
    box(k.m.data(), k.n_.data(), w, h, r, k.tmp);
    for (size_t i = 0; i < n; i++) { k.t1[i] = guide[i] * k.m[i]; k.t2[i] = P[i] * k.m[i]; }
    box(k.t1.data(), k.mI.data(), w, h, r, k.tmp);
    box(k.t2.data(), k.mP.data(), w, h, r, k.tmp);
    for (size_t i = 0; i < n; i++) k.t3[i] = guide[i] * P[i] * k.m[i];
    box(k.t3.data(), k.cIP.data(), w, h, r, k.tmp);
    for (size_t i = 0; i < n; i++) k.t3[i] = guide[i] * guide[i] * k.m[i];
    box(k.t3.data(), k.vI.data(), w, h, r, k.tmp);
    for (size_t i = 0; i < n; i++) {
        const float nn = k.n_[i] + 1e-8f;
        const float mi = k.mI[i] / nn, mp = k.mP[i] / nn;
        const float cip = k.cIP[i] / nn - mi * mp;
        const float vi = k.vI[i] / nn - mi * mi;
        const float a = cip / (std::max(0.f, vi) + eps);
        k.a[i] = a; k.b[i] = mp - a * mi;
    }
    box(k.a.data(), k.a.data(), w, h, r, k.tmp);
    box(k.b.data(), k.b.data(), w, h, r, k.tmp);
    // tentative estimate and residual at the sample sites
    for (size_t i = 0; i < n; i++) {
        const float tent = k.a[i] * guide[i] + k.b[i];
        k.t1[i] = tent;                                        // tentative plane
        k.t2[i] = k.m[i] > 0.5f ? (P[i] - tent) : 0.f;         // residual (0 elsewhere)
    }
    // normalised 3x3 tent interpolation of the residual
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            float num = 0.f, den = 0.f;
            for (int dy = -1; dy <= 1; dy++) {
                const int yy = cl(y + dy, 0, h - 1);
                const float wy = dy == 0 ? 2.f : 1.f;
                for (int dx = -1; dx <= 1; dx++) {
                    const int xx = cl(x + dx, 0, w - 1);
                    const float wt = wy * (dx == 0 ? 2.f : 1.f);
                    const size_t j = (size_t)yy * w + xx;
                    num += wt * k.t2[j];
                    den += wt * k.m[j];
                }
            }
            const size_t i = (size_t)y * w + x;
            out[i] = k.m[i] > 0.5f ? P[i] : std::max(0.f, k.t1[i] + num / std::max(den, 1e-6f));
        }
    }
}

// M: padded mosaic (w x h). Outputs full R, G, B planes (padded size).
// greenHook (optional) may modify the initial green plane (used for the multi-frame super-resolution green).
inline void demosaic(const float* M, int w, int h, const uint8_t* col, std::vector<float>& R, std::vector<float>& G, std::vector<float>& B,
                     const std::function<void(std::vector<float>&)>& greenHook, int iters = 1, int rad = 3, float eps = 1e-4f) {
    const size_t n = (size_t)w * h;
    auto at = [&](int x, int y) -> float { return M[(size_t)cl(y, 0, h - 1) * w + cl(x, 0, w - 1)]; };
    std::vector<float> gh(n), gv(n), eh(n), ev(n), tmp;
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            const float c = at(x, y);
            const size_t i = (size_t)y * w + x;
            gh[i] = std::fabs(at(x - 1, y) - at(x + 1, y)) + std::fabs(2 * c - at(x - 2, y) - at(x + 2, y));
            gv[i] = std::fabs(at(x, y - 1) - at(x, y + 1)) + std::fabs(2 * c - at(x, y - 2) - at(x, y + 2));
            eh[i] = (at(x - 1, y) + at(x + 1, y)) * 0.5f + (2 * c - at(x - 2, y) - at(x + 2, y)) * 0.25f;
            ev[i] = (at(x, y - 1) + at(x, y + 1)) * 0.5f + (2 * c - at(x, y - 2) - at(x, y + 2)) * 0.25f;
        }
    box(gh.data(), gh.data(), w, h, 1, tmp);
    box(gv.data(), gv.data(), w, h, 1, tmp);
    G.assign(n, 0.f);
    for (size_t i = 0; i < n; i++) {
        if (col[i] == 1) { G[i] = M[i]; continue; }
        const float a = 1e-3f + gh[i], b = 1e-3f + gv[i];
        const float wh = 1.f / (a * a), wv = 1.f / (b * b);
        G[i] = std::max(0.f, (wh * eh[i] + wv * ev[i]) / (wh + wv));
    }
    std::vector<float>().swap(gh); std::vector<float>().swap(gv); std::vector<float>().swap(eh); std::vector<float>().swap(ev);
    if (greenHook) greenHook(G);

    Work k(w, h);
    R.assign(n, 0.f); B.assign(n, 0.f);
    std::vector<float> P(n);
    auto rb = [&](const std::vector<float>& g) {
        for (size_t i = 0; i < n; i++) P[i] = M[i];
        riPlane(k, g.data(), P.data(), col, 0, rad, eps, R.data());
        riPlane(k, g.data(), P.data(), col, 2, rad, eps, B.data());
    };
    rb(G);
    for (int it = 0; it < iters; it++) {
        // refine green at R / B sites: guide = the reconstructed R (B) plane, samples = green at G sites
        std::vector<float> newG(G), Gs(n), tmpG(n);
        for (size_t i = 0; i < n; i++) Gs[i] = col[i] == 1 ? G[i] : 0.f;
        // use colour mask "1" (green sites) with each guide
        riPlane(k, R.data(), Gs.data(), col, 1, rad, eps, tmpG.data());
        for (size_t i = 0; i < n; i++) if (col[i] == 0) newG[i] = tmpG[i];
        riPlane(k, B.data(), Gs.data(), col, 1, rad, eps, tmpG.data());
        for (size_t i = 0; i < n; i++) if (col[i] == 2) newG[i] = tmpG[i];
        for (size_t i = 0; i < n; i++) if (col[i] != 1) G[i] = 0.5f * newG[i] + 0.5f * G[i];
        rb(G);
    }
}

}  // namespace dm
}  // namespace uc
